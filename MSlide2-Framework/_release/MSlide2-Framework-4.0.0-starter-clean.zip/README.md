# MSlide² Framework Starter

MSlide² Framework 4.0.0 Starter is the free public starter version of MSlide².

It provides the minimum structure needed to begin an MSlide² project: a local
Reveal.js runtime, MSlide² brand assets, a minimal `index.html`, and the source
folders required to extend the presentation safely.

This starter is intentionally small. Full demos, layout packs, component
libraries, rich showcase projects, client examples, and production showcase
material are not included in the public starter package.

## Quick Start

Do not open `index.html` with `file://`. Serve the project through localhost:

```bash
cd "MSlide-Framework/MSlide2-Framework"
python3 -m http.server 8080
```

Open:

```text
http://localhost:8080/index.html
```

Hard refresh the browser if cached styles or scripts appear stale.

## Public Starter Contents

- `index.html`: minimal public starter entry point.
- `assets/brand/`: MSlide² identity, icons, and manifest images.
- `css/`: stylesheet source and MSlide-specific extension area.
- `dist/`: bundled Reveal.js runtime and themes.
- `js/`: Reveal.js source files retained for framework development.
- `plugin/`: Reveal.js plugins and optional MSlide runtime extensions.
- `README.md`, `CHANGELOG.md`, `CONTRIBUTING.md`: project documentation.
- `package.json`, `package-lock.json`, `gulpfile.js`: inherited build metadata.
- `config.js`, `constants.js`, `site.webmanifest`, `browserconfig.xml`: runtime and metadata files.

## Not Included In The Public Starter

The public starter does not include the internal rich demo, the full layout
library, component library, showcase projects, audit reports, archived release
noise, duplicate files, vendor folders, or client/showcase material.

The internal rich demo is retained in the working repository as
`index-demo-internal.html` and must be excluded from public starter ZIP builds.

## Version Information

- Framework name: `MSlide²`
- Repository: `MSlide2-Framework`
- Version: `4.0.0`
- Package type: free public starter
- Primary entry point: `index.html`
- Supported preview mode: `localhost`

## Contribution Note

Contributions should preserve the starter boundary. Do not move, rename, delete,
or rewrite protected runtime files without path verification and localhost
preview testing.

See `CONTRIBUTING.md`.
