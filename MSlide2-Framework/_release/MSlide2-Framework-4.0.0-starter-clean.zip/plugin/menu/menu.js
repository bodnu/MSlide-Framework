(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory() :
  typeof define === 'function' && define.amd ? define(factory) :
  (global = typeof globalThis !== 'undefined' ? globalThis : global || self, global.RevealMenu = factory());
})(this, (function () { 'use strict';

  function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
      var info = gen[key](arg);
      var value = info.value;
    } catch (error) {
      reject(error);
      return;
    }
    if (info.done) {
      resolve(value);
    } else {
      Promise.resolve(value).then(_next, _throw);
    }
  }
  function _asyncToGenerator(fn) {
    return function () {
      var self = this,
        args = arguments;
      return new Promise(function (resolve, reject) {
        var gen = fn.apply(self, args);
        function _next(value) {
          asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
        }
        function _throw(err) {
          asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
        }
        _next(undefined);
      });
    };
  }

  var commonjsGlobal = typeof globalThis !== 'undefined' ? globalThis : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};

  var regeneratorRuntime$1 = {exports: {}};

  var _typeof = {exports: {}};

  (function (module) {
  function _typeof(obj) {
    "@babel/helpers - typeof";

    return (module.exports = _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) {
      return typeof obj;
    } : function (obj) {
      return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, module.exports.__esModule = true, module.exports["default"] = module.exports), _typeof(obj);
  }
  module.exports = _typeof, module.exports.__esModule = true, module.exports["default"] = module.exports;
  }(_typeof));

  (function (module) {
  var _typeof$1 = _typeof.exports["default"];
  function _regeneratorRuntime() {
    module.exports = _regeneratorRuntime = function _regeneratorRuntime() {
      return exports;
    }, module.exports.__esModule = true, module.exports["default"] = module.exports;
    var exports = {},
      Op = Object.prototype,
      hasOwn = Op.hasOwnProperty,
      defineProperty = Object.defineProperty || function (obj, key, desc) {
        obj[key] = desc.value;
      },
      $Symbol = "function" == typeof Symbol ? Symbol : {},
      iteratorSymbol = $Symbol.iterator || "@@iterator",
      asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator",
      toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
    function define(obj, key, value) {
      return Object.defineProperty(obj, key, {
        value: value,
        enumerable: !0,
        configurable: !0,
        writable: !0
      }), obj[key];
    }
    try {
      define({}, "");
    } catch (err) {
      define = function define(obj, key, value) {
        return obj[key] = value;
      };
    }
    function wrap(innerFn, outerFn, self, tryLocsList) {
      var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator,
        generator = Object.create(protoGenerator.prototype),
        context = new Context(tryLocsList || []);
      return defineProperty(generator, "_invoke", {
        value: makeInvokeMethod(innerFn, self, context)
      }), generator;
    }
    function tryCatch(fn, obj, arg) {
      try {
        return {
          type: "normal",
          arg: fn.call(obj, arg)
        };
      } catch (err) {
        return {
          type: "throw",
          arg: err
        };
      }
    }
    exports.wrap = wrap;
    var ContinueSentinel = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    var IteratorPrototype = {};
    define(IteratorPrototype, iteratorSymbol, function () {
      return this;
    });
    var getProto = Object.getPrototypeOf,
      NativeIteratorPrototype = getProto && getProto(getProto(values([])));
    NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
    var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
    function defineIteratorMethods(prototype) {
      ["next", "throw", "return"].forEach(function (method) {
        define(prototype, method, function (arg) {
          return this._invoke(method, arg);
        });
      });
    }
    function AsyncIterator(generator, PromiseImpl) {
      function invoke(method, arg, resolve, reject) {
        var record = tryCatch(generator[method], generator, arg);
        if ("throw" !== record.type) {
          var result = record.arg,
            value = result.value;
          return value && "object" == _typeof$1(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) {
            invoke("next", value, resolve, reject);
          }, function (err) {
            invoke("throw", err, resolve, reject);
          }) : PromiseImpl.resolve(value).then(function (unwrapped) {
            result.value = unwrapped, resolve(result);
          }, function (error) {
            return invoke("throw", error, resolve, reject);
          });
        }
        reject(record.arg);
      }
      var previousPromise;
      defineProperty(this, "_invoke", {
        value: function value(method, arg) {
          function callInvokeWithMethodAndArg() {
            return new PromiseImpl(function (resolve, reject) {
              invoke(method, arg, resolve, reject);
            });
          }
          return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
        }
      });
    }
    function makeInvokeMethod(innerFn, self, context) {
      var state = "suspendedStart";
      return function (method, arg) {
        if ("executing" === state) throw new Error("Generator is already running");
        if ("completed" === state) {
          if ("throw" === method) throw arg;
          return doneResult();
        }
        for (context.method = method, context.arg = arg;;) {
          var delegate = context.delegate;
          if (delegate) {
            var delegateResult = maybeInvokeDelegate(delegate, context);
            if (delegateResult) {
              if (delegateResult === ContinueSentinel) continue;
              return delegateResult;
            }
          }
          if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) {
            if ("suspendedStart" === state) throw state = "completed", context.arg;
            context.dispatchException(context.arg);
          } else "return" === context.method && context.abrupt("return", context.arg);
          state = "executing";
          var record = tryCatch(innerFn, self, context);
          if ("normal" === record.type) {
            if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
            return {
              value: record.arg,
              done: context.done
            };
          }
          "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
        }
      };
    }
    function maybeInvokeDelegate(delegate, context) {
      var methodName = context.method,
        method = delegate.iterator[methodName];
      if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel;
      var record = tryCatch(method, delegate.iterator, context.arg);
      if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
      var info = record.arg;
      return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
    }
    function pushTryEntry(locs) {
      var entry = {
        tryLoc: locs[0]
      };
      1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
    }
    function resetTryEntry(entry) {
      var record = entry.completion || {};
      record.type = "normal", delete record.arg, entry.completion = record;
    }
    function Context(tryLocsList) {
      this.tryEntries = [{
        tryLoc: "root"
      }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
    }
    function values(iterable) {
      if (iterable) {
        var iteratorMethod = iterable[iteratorSymbol];
        if (iteratorMethod) return iteratorMethod.call(iterable);
        if ("function" == typeof iterable.next) return iterable;
        if (!isNaN(iterable.length)) {
          var i = -1,
            next = function next() {
              for (; ++i < iterable.length;) if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
              return next.value = undefined, next.done = !0, next;
            };
          return next.next = next;
        }
      }
      return {
        next: doneResult
      };
    }
    function doneResult() {
      return {
        value: undefined,
        done: !0
      };
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", {
      value: GeneratorFunctionPrototype,
      configurable: !0
    }), defineProperty(GeneratorFunctionPrototype, "constructor", {
      value: GeneratorFunction,
      configurable: !0
    }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) {
      var ctor = "function" == typeof genFun && genFun.constructor;
      return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
    }, exports.mark = function (genFun) {
      return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
    }, exports.awrap = function (arg) {
      return {
        __await: arg
      };
    }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () {
      return this;
    }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) {
      void 0 === PromiseImpl && (PromiseImpl = Promise);
      var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
      return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) {
        return result.done ? result.value : iter.next();
      });
    }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () {
      return this;
    }), define(Gp, "toString", function () {
      return "[object Generator]";
    }), exports.keys = function (val) {
      var object = Object(val),
        keys = [];
      for (var key in object) keys.push(key);
      return keys.reverse(), function next() {
        for (; keys.length;) {
          var key = keys.pop();
          if (key in object) return next.value = key, next.done = !1, next;
        }
        return next.done = !0, next;
      };
    }, exports.values = values, Context.prototype = {
      constructor: Context,
      reset: function reset(skipTempReset) {
        if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
      },
      stop: function stop() {
        this.done = !0;
        var rootRecord = this.tryEntries[0].completion;
        if ("throw" === rootRecord.type) throw rootRecord.arg;
        return this.rval;
      },
      dispatchException: function dispatchException(exception) {
        if (this.done) throw exception;
        var context = this;
        function handle(loc, caught) {
          return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
        }
        for (var i = this.tryEntries.length - 1; i >= 0; --i) {
          var entry = this.tryEntries[i],
            record = entry.completion;
          if ("root" === entry.tryLoc) return handle("end");
          if (entry.tryLoc <= this.prev) {
            var hasCatch = hasOwn.call(entry, "catchLoc"),
              hasFinally = hasOwn.call(entry, "finallyLoc");
            if (hasCatch && hasFinally) {
              if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
              if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
            } else if (hasCatch) {
              if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
            } else {
              if (!hasFinally) throw new Error("try statement without catch or finally");
              if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
            }
          }
        }
      },
      abrupt: function abrupt(type, arg) {
        for (var i = this.tryEntries.length - 1; i >= 0; --i) {
          var entry = this.tryEntries[i];
          if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
            var finallyEntry = entry;
            break;
          }
        }
        finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
        var record = finallyEntry ? finallyEntry.completion : {};
        return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
      },
      complete: function complete(record, afterLoc) {
        if ("throw" === record.type) throw record.arg;
        return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
      },
      finish: function finish(finallyLoc) {
        for (var i = this.tryEntries.length - 1; i >= 0; --i) {
          var entry = this.tryEntries[i];
          if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
        }
      },
      "catch": function _catch(tryLoc) {
        for (var i = this.tryEntries.length - 1; i >= 0; --i) {
          var entry = this.tryEntries[i];
          if (entry.tryLoc === tryLoc) {
            var record = entry.completion;
            if ("throw" === record.type) {
              var thrown = record.arg;
              resetTryEntry(entry);
            }
            return thrown;
          }
        }
        throw new Error("illegal catch attempt");
      },
      delegateYield: function delegateYield(iterable, resultName, nextLoc) {
        return this.delegate = {
          iterator: values(iterable),
          resultName: resultName,
          nextLoc: nextLoc
        }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
      }
    }, exports;
  }
  module.exports = _regeneratorRuntime, module.exports.__esModule = true, module.exports["default"] = module.exports;
  }(regeneratorRuntime$1));

  // TODO(Babel 8): Remove this file.

  var runtime = regeneratorRuntime$1.exports();
  var regenerator = runtime;

  // Copied from https://github.com/facebook/regenerator/blob/main/packages/runtime/runtime.js#L736=
  try {
    regeneratorRuntime = runtime;
  } catch (accidentalStrictMode) {
    if (typeof globalThis === "object") {
      globalThis.regeneratorRuntime = runtime;
    } else {
      Function("r", "regeneratorRuntime = r")(runtime);
    }
  }

  var check = function (it) {
    return it && it.Math == Math && it;
  };

  // https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
  var global$l =
    // eslint-disable-next-line es/no-global-this -- safe
    check(typeof globalThis == 'object' && globalThis) ||
    check(typeof window == 'object' && window) ||
    // eslint-disable-next-line no-restricted-globals -- safe
    check(typeof self == 'object' && self) ||
    check(typeof commonjsGlobal == 'object' && commonjsGlobal) ||
    // eslint-disable-next-line no-new-func -- fallback
    (function () { return this; })() || Function('return this')();

  var objectGetOwnPropertyDescriptor = {};

  var fails$n = function (exec) {
    try {
      return !!exec();
    } catch (error) {
      return true;
    }
  };

  var fails$m = fails$n;

  // Detect IE8's incomplete defineProperty implementation
  var descriptors = !fails$m(function () {
    // eslint-disable-next-line es/no-object-defineproperty -- required for testing
    return Object.defineProperty({}, 1, { get: function () { return 7; } })[1] != 7;
  });

  var fails$l = fails$n;

  var functionBindNative = !fails$l(function () {
    // eslint-disable-next-line es/no-function-prototype-bind -- safe
    var test = (function () { /* empty */ }).bind();
    // eslint-disable-next-line no-prototype-builtins -- safe
    return typeof test != 'function' || test.hasOwnProperty('prototype');
  });

  var NATIVE_BIND$3 = functionBindNative;

  var call$h = Function.prototype.call;

  var functionCall = NATIVE_BIND$3 ? call$h.bind(call$h) : function () {
    return call$h.apply(call$h, arguments);
  };

  var objectPropertyIsEnumerable = {};

  var $propertyIsEnumerable = {}.propertyIsEnumerable;
  // eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
  var getOwnPropertyDescriptor$4 = Object.getOwnPropertyDescriptor;

  // Nashorn ~ JDK8 bug
  var NASHORN_BUG = getOwnPropertyDescriptor$4 && !$propertyIsEnumerable.call({ 1: 2 }, 1);

  // `Object.prototype.propertyIsEnumerable` method implementation
  // https://tc39.es/ecma262/#sec-object.prototype.propertyisenumerable
  objectPropertyIsEnumerable.f = NASHORN_BUG ? function propertyIsEnumerable(V) {
    var descriptor = getOwnPropertyDescriptor$4(this, V);
    return !!descriptor && descriptor.enumerable;
  } : $propertyIsEnumerable;

  var createPropertyDescriptor$3 = function (bitmap, value) {
    return {
      enumerable: !(bitmap & 1),
      configurable: !(bitmap & 2),
      writable: !(bitmap & 4),
      value: value
    };
  };

  var NATIVE_BIND$2 = functionBindNative;

  var FunctionPrototype$3 = Function.prototype;
  var call$g = FunctionPrototype$3.call;
  var uncurryThisWithBind = NATIVE_BIND$2 && FunctionPrototype$3.bind.bind(call$g, call$g);

  var functionUncurryThis = NATIVE_BIND$2 ? uncurryThisWithBind : function (fn) {
    return function () {
      return call$g.apply(fn, arguments);
    };
  };

  var uncurryThis$s = functionUncurryThis;

  var toString$d = uncurryThis$s({}.toString);
  var stringSlice$6 = uncurryThis$s(''.slice);

  var classofRaw$2 = function (it) {
    return stringSlice$6(toString$d(it), 8, -1);
  };

  var uncurryThis$r = functionUncurryThis;
  var fails$k = fails$n;
  var classof$c = classofRaw$2;

  var $Object$3 = Object;
  var split = uncurryThis$r(''.split);

  // fallback for non-array-like ES3 and non-enumerable old V8 strings
  var indexedObject = fails$k(function () {
    // throws an error in rhino, see https://github.com/mozilla/rhino/issues/346
    // eslint-disable-next-line no-prototype-builtins -- safe
    return !$Object$3('z').propertyIsEnumerable(0);
  }) ? function (it) {
    return classof$c(it) == 'String' ? split(it, '') : $Object$3(it);
  } : $Object$3;

  // we can't use just `it == null` since of `document.all` special case
  // https://tc39.es/ecma262/#sec-IsHTMLDDA-internal-slot-aec
  var isNullOrUndefined$6 = function (it) {
    return it === null || it === undefined;
  };

  var isNullOrUndefined$5 = isNullOrUndefined$6;

  var $TypeError$g = TypeError;

  // `RequireObjectCoercible` abstract operation
  // https://tc39.es/ecma262/#sec-requireobjectcoercible
  var requireObjectCoercible$8 = function (it) {
    if (isNullOrUndefined$5(it)) throw $TypeError$g("Can't call method on " + it);
    return it;
  };

  // toObject with fallback for non-array-like ES3 strings
  var IndexedObject$2 = indexedObject;
  var requireObjectCoercible$7 = requireObjectCoercible$8;

  var toIndexedObject$7 = function (it) {
    return IndexedObject$2(requireObjectCoercible$7(it));
  };

  var documentAll$2 = typeof document == 'object' && document.all;

  // https://tc39.es/ecma262/#sec-IsHTMLDDA-internal-slot
  // eslint-disable-next-line unicorn/no-typeof-undefined -- required for testing
  var IS_HTMLDDA = typeof documentAll$2 == 'undefined' && documentAll$2 !== undefined;

  var documentAll_1 = {
    all: documentAll$2,
    IS_HTMLDDA: IS_HTMLDDA
  };

  var $documentAll$1 = documentAll_1;

  var documentAll$1 = $documentAll$1.all;

  // `IsCallable` abstract operation
  // https://tc39.es/ecma262/#sec-iscallable
  var isCallable$l = $documentAll$1.IS_HTMLDDA ? function (argument) {
    return typeof argument == 'function' || argument === documentAll$1;
  } : function (argument) {
    return typeof argument == 'function';
  };

  var isCallable$k = isCallable$l;
  var $documentAll = documentAll_1;

  var documentAll = $documentAll.all;

  var isObject$b = $documentAll.IS_HTMLDDA ? function (it) {
    return typeof it == 'object' ? it !== null : isCallable$k(it) || it === documentAll;
  } : function (it) {
    return typeof it == 'object' ? it !== null : isCallable$k(it);
  };

  var global$k = global$l;
  var isCallable$j = isCallable$l;

  var aFunction = function (argument) {
    return isCallable$j(argument) ? argument : undefined;
  };

  var getBuiltIn$8 = function (namespace, method) {
    return arguments.length < 2 ? aFunction(global$k[namespace]) : global$k[namespace] && global$k[namespace][method];
  };

  var uncurryThis$q = functionUncurryThis;

  var objectIsPrototypeOf = uncurryThis$q({}.isPrototypeOf);

  var engineUserAgent = typeof navigator != 'undefined' && String(navigator.userAgent) || '';

  var global$j = global$l;
  var userAgent$3 = engineUserAgent;

  var process$4 = global$j.process;
  var Deno$1 = global$j.Deno;
  var versions = process$4 && process$4.versions || Deno$1 && Deno$1.version;
  var v8 = versions && versions.v8;
  var match, version;

  if (v8) {
    match = v8.split('.');
    // in old Chrome, versions of V8 isn't V8 = Chrome / 10
    // but their correct versions are not interesting for us
    version = match[0] > 0 && match[0] < 4 ? 1 : +(match[0] + match[1]);
  }

  // BrowserFS NodeJS `process` polyfill incorrectly set `.v8` to `0.0`
  // so check `userAgent` even if `.v8` exists, but 0
  if (!version && userAgent$3) {
    match = userAgent$3.match(/Edge\/(\d+)/);
    if (!match || match[1] >= 74) {
      match = userAgent$3.match(/Chrome\/(\d+)/);
      if (match) version = +match[1];
    }
  }

  var engineV8Version = version;

  /* eslint-disable es/no-symbol -- required for testing */

  var V8_VERSION$3 = engineV8Version;
  var fails$j = fails$n;

  // eslint-disable-next-line es/no-object-getownpropertysymbols -- required for testing
  var symbolConstructorDetection = !!Object.getOwnPropertySymbols && !fails$j(function () {
    var symbol = Symbol();
    // Chrome 38 Symbol has incorrect toString conversion
    // `get-own-property-symbols` polyfill symbols converted to object are not Symbol instances
    return !String(symbol) || !(Object(symbol) instanceof Symbol) ||
      // Chrome 38-40 symbols are not inherited from DOM collections prototypes to instances
      !Symbol.sham && V8_VERSION$3 && V8_VERSION$3 < 41;
  });

  /* eslint-disable es/no-symbol -- required for testing */

  var NATIVE_SYMBOL$2 = symbolConstructorDetection;

  var useSymbolAsUid = NATIVE_SYMBOL$2
    && !Symbol.sham
    && typeof Symbol.iterator == 'symbol';

  var getBuiltIn$7 = getBuiltIn$8;
  var isCallable$i = isCallable$l;
  var isPrototypeOf$2 = objectIsPrototypeOf;
  var USE_SYMBOL_AS_UID$1 = useSymbolAsUid;

  var $Object$2 = Object;

  var isSymbol$3 = USE_SYMBOL_AS_UID$1 ? function (it) {
    return typeof it == 'symbol';
  } : function (it) {
    var $Symbol = getBuiltIn$7('Symbol');
    return isCallable$i($Symbol) && isPrototypeOf$2($Symbol.prototype, $Object$2(it));
  };

  var $String$5 = String;

  var tryToString$4 = function (argument) {
    try {
      return $String$5(argument);
    } catch (error) {
      return 'Object';
    }
  };

  var isCallable$h = isCallable$l;
  var tryToString$3 = tryToString$4;

  var $TypeError$f = TypeError;

  // `Assert: IsCallable(argument) is true`
  var aCallable$8 = function (argument) {
    if (isCallable$h(argument)) return argument;
    throw $TypeError$f(tryToString$3(argument) + ' is not a function');
  };

  var aCallable$7 = aCallable$8;
  var isNullOrUndefined$4 = isNullOrUndefined$6;

  // `GetMethod` abstract operation
  // https://tc39.es/ecma262/#sec-getmethod
  var getMethod$5 = function (V, P) {
    var func = V[P];
    return isNullOrUndefined$4(func) ? undefined : aCallable$7(func);
  };

  var call$f = functionCall;
  var isCallable$g = isCallable$l;
  var isObject$a = isObject$b;

  var $TypeError$e = TypeError;

  // `OrdinaryToPrimitive` abstract operation
  // https://tc39.es/ecma262/#sec-ordinarytoprimitive
  var ordinaryToPrimitive$1 = function (input, pref) {
    var fn, val;
    if (pref === 'string' && isCallable$g(fn = input.toString) && !isObject$a(val = call$f(fn, input))) return val;
    if (isCallable$g(fn = input.valueOf) && !isObject$a(val = call$f(fn, input))) return val;
    if (pref !== 'string' && isCallable$g(fn = input.toString) && !isObject$a(val = call$f(fn, input))) return val;
    throw $TypeError$e("Can't convert object to primitive value");
  };

  var shared$4 = {exports: {}};

  var global$i = global$l;

  // eslint-disable-next-line es/no-object-defineproperty -- safe
  var defineProperty$3 = Object.defineProperty;

  var defineGlobalProperty$3 = function (key, value) {
    try {
      defineProperty$3(global$i, key, { value: value, configurable: true, writable: true });
    } catch (error) {
      global$i[key] = value;
    } return value;
  };

  var global$h = global$l;
  var defineGlobalProperty$2 = defineGlobalProperty$3;

  var SHARED = '__core-js_shared__';
  var store$3 = global$h[SHARED] || defineGlobalProperty$2(SHARED, {});

  var sharedStore = store$3;

  var store$2 = sharedStore;

  (shared$4.exports = function (key, value) {
    return store$2[key] || (store$2[key] = value !== undefined ? value : {});
  })('versions', []).push({
    version: '3.30.1',
    mode: 'global',
    copyright: '© 2014-2023 Denis Pushkarev (zloirock.ru)',
    license: 'https://github.com/zloirock/core-js/blob/v3.30.1/LICENSE',
    source: 'https://github.com/zloirock/core-js'
  });

  var requireObjectCoercible$6 = requireObjectCoercible$8;

  var $Object$1 = Object;

  // `ToObject` abstract operation
  // https://tc39.es/ecma262/#sec-toobject
  var toObject$4 = function (argument) {
    return $Object$1(requireObjectCoercible$6(argument));
  };

  var uncurryThis$p = functionUncurryThis;
  var toObject$3 = toObject$4;

  var hasOwnProperty = uncurryThis$p({}.hasOwnProperty);

  // `HasOwnProperty` abstract operation
  // https://tc39.es/ecma262/#sec-hasownproperty
  // eslint-disable-next-line es/no-object-hasown -- safe
  var hasOwnProperty_1 = Object.hasOwn || function hasOwn(it, key) {
    return hasOwnProperty(toObject$3(it), key);
  };

  var uncurryThis$o = functionUncurryThis;

  var id = 0;
  var postfix = Math.random();
  var toString$c = uncurryThis$o(1.0.toString);

  var uid$2 = function (key) {
    return 'Symbol(' + (key === undefined ? '' : key) + ')_' + toString$c(++id + postfix, 36);
  };

  var global$g = global$l;
  var shared$3 = shared$4.exports;
  var hasOwn$8 = hasOwnProperty_1;
  var uid$1 = uid$2;
  var NATIVE_SYMBOL$1 = symbolConstructorDetection;
  var USE_SYMBOL_AS_UID = useSymbolAsUid;

  var Symbol$3 = global$g.Symbol;
  var WellKnownSymbolsStore = shared$3('wks');
  var createWellKnownSymbol = USE_SYMBOL_AS_UID ? Symbol$3['for'] || Symbol$3 : Symbol$3 && Symbol$3.withoutSetter || uid$1;

  var wellKnownSymbol$i = function (name) {
    if (!hasOwn$8(WellKnownSymbolsStore, name)) {
      WellKnownSymbolsStore[name] = NATIVE_SYMBOL$1 && hasOwn$8(Symbol$3, name)
        ? Symbol$3[name]
        : createWellKnownSymbol('Symbol.' + name);
    } return WellKnownSymbolsStore[name];
  };

  var call$e = functionCall;
  var isObject$9 = isObject$b;
  var isSymbol$2 = isSymbol$3;
  var getMethod$4 = getMethod$5;
  var ordinaryToPrimitive = ordinaryToPrimitive$1;
  var wellKnownSymbol$h = wellKnownSymbol$i;

  var $TypeError$d = TypeError;
  var TO_PRIMITIVE = wellKnownSymbol$h('toPrimitive');

  // `ToPrimitive` abstract operation
  // https://tc39.es/ecma262/#sec-toprimitive
  var toPrimitive$1 = function (input, pref) {
    if (!isObject$9(input) || isSymbol$2(input)) return input;
    var exoticToPrim = getMethod$4(input, TO_PRIMITIVE);
    var result;
    if (exoticToPrim) {
      if (pref === undefined) pref = 'default';
      result = call$e(exoticToPrim, input, pref);
      if (!isObject$9(result) || isSymbol$2(result)) return result;
      throw $TypeError$d("Can't convert object to primitive value");
    }
    if (pref === undefined) pref = 'number';
    return ordinaryToPrimitive(input, pref);
  };

  var toPrimitive = toPrimitive$1;
  var isSymbol$1 = isSymbol$3;

  // `ToPropertyKey` abstract operation
  // https://tc39.es/ecma262/#sec-topropertykey
  var toPropertyKey$3 = function (argument) {
    var key = toPrimitive(argument, 'string');
    return isSymbol$1(key) ? key : key + '';
  };

  var global$f = global$l;
  var isObject$8 = isObject$b;

  var document$3 = global$f.document;
  // typeof document.createElement is 'object' in old IE
  var EXISTS$1 = isObject$8(document$3) && isObject$8(document$3.createElement);

  var documentCreateElement$2 = function (it) {
    return EXISTS$1 ? document$3.createElement(it) : {};
  };

  var DESCRIPTORS$a = descriptors;
  var fails$i = fails$n;
  var createElement$1 = documentCreateElement$2;

  // Thanks to IE8 for its funny defineProperty
  var ie8DomDefine = !DESCRIPTORS$a && !fails$i(function () {
    // eslint-disable-next-line es/no-object-defineproperty -- required for testing
    return Object.defineProperty(createElement$1('div'), 'a', {
      get: function () { return 7; }
    }).a != 7;
  });

  var DESCRIPTORS$9 = descriptors;
  var call$d = functionCall;
  var propertyIsEnumerableModule = objectPropertyIsEnumerable;
  var createPropertyDescriptor$2 = createPropertyDescriptor$3;
  var toIndexedObject$6 = toIndexedObject$7;
  var toPropertyKey$2 = toPropertyKey$3;
  var hasOwn$7 = hasOwnProperty_1;
  var IE8_DOM_DEFINE$1 = ie8DomDefine;

  // eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
  var $getOwnPropertyDescriptor$1 = Object.getOwnPropertyDescriptor;

  // `Object.getOwnPropertyDescriptor` method
  // https://tc39.es/ecma262/#sec-object.getownpropertydescriptor
  objectGetOwnPropertyDescriptor.f = DESCRIPTORS$9 ? $getOwnPropertyDescriptor$1 : function getOwnPropertyDescriptor(O, P) {
    O = toIndexedObject$6(O);
    P = toPropertyKey$2(P);
    if (IE8_DOM_DEFINE$1) try {
      return $getOwnPropertyDescriptor$1(O, P);
    } catch (error) { /* empty */ }
    if (hasOwn$7(O, P)) return createPropertyDescriptor$2(!call$d(propertyIsEnumerableModule.f, O, P), O[P]);
  };

  var objectDefineProperty = {};

  var DESCRIPTORS$8 = descriptors;
  var fails$h = fails$n;

  // V8 ~ Chrome 36-
  // https://bugs.chromium.org/p/v8/issues/detail?id=3334
  var v8PrototypeDefineBug = DESCRIPTORS$8 && fails$h(function () {
    // eslint-disable-next-line es/no-object-defineproperty -- required for testing
    return Object.defineProperty(function () { /* empty */ }, 'prototype', {
      value: 42,
      writable: false
    }).prototype != 42;
  });

  var isObject$7 = isObject$b;

  var $String$4 = String;
  var $TypeError$c = TypeError;

  // `Assert: Type(argument) is Object`
  var anObject$e = function (argument) {
    if (isObject$7(argument)) return argument;
    throw $TypeError$c($String$4(argument) + ' is not an object');
  };

  var DESCRIPTORS$7 = descriptors;
  var IE8_DOM_DEFINE = ie8DomDefine;
  var V8_PROTOTYPE_DEFINE_BUG$1 = v8PrototypeDefineBug;
  var anObject$d = anObject$e;
  var toPropertyKey$1 = toPropertyKey$3;

  var $TypeError$b = TypeError;
  // eslint-disable-next-line es/no-object-defineproperty -- safe
  var $defineProperty = Object.defineProperty;
  // eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
  var $getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
  var ENUMERABLE = 'enumerable';
  var CONFIGURABLE$1 = 'configurable';
  var WRITABLE = 'writable';

  // `Object.defineProperty` method
  // https://tc39.es/ecma262/#sec-object.defineproperty
  objectDefineProperty.f = DESCRIPTORS$7 ? V8_PROTOTYPE_DEFINE_BUG$1 ? function defineProperty(O, P, Attributes) {
    anObject$d(O);
    P = toPropertyKey$1(P);
    anObject$d(Attributes);
    if (typeof O === 'function' && P === 'prototype' && 'value' in Attributes && WRITABLE in Attributes && !Attributes[WRITABLE]) {
      var current = $getOwnPropertyDescriptor(O, P);
      if (current && current[WRITABLE]) {
        O[P] = Attributes.value;
        Attributes = {
          configurable: CONFIGURABLE$1 in Attributes ? Attributes[CONFIGURABLE$1] : current[CONFIGURABLE$1],
          enumerable: ENUMERABLE in Attributes ? Attributes[ENUMERABLE] : current[ENUMERABLE],
          writable: false
        };
      }
    } return $defineProperty(O, P, Attributes);
  } : $defineProperty : function defineProperty(O, P, Attributes) {
    anObject$d(O);
    P = toPropertyKey$1(P);
    anObject$d(Attributes);
    if (IE8_DOM_DEFINE) try {
      return $defineProperty(O, P, Attributes);
    } catch (error) { /* empty */ }
    if ('get' in Attributes || 'set' in Attributes) throw $TypeError$b('Accessors not supported');
    if ('value' in Attributes) O[P] = Attributes.value;
    return O;
  };

  var DESCRIPTORS$6 = descriptors;
  var definePropertyModule$4 = objectDefineProperty;
  var createPropertyDescriptor$1 = createPropertyDescriptor$3;

  var createNonEnumerableProperty$4 = DESCRIPTORS$6 ? function (object, key, value) {
    return definePropertyModule$4.f(object, key, createPropertyDescriptor$1(1, value));
  } : function (object, key, value) {
    object[key] = value;
    return object;
  };

  var makeBuiltIn$3 = {exports: {}};

  var DESCRIPTORS$5 = descriptors;
  var hasOwn$6 = hasOwnProperty_1;

  var FunctionPrototype$2 = Function.prototype;
  // eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
  var getDescriptor = DESCRIPTORS$5 && Object.getOwnPropertyDescriptor;

  var EXISTS = hasOwn$6(FunctionPrototype$2, 'name');
  // additional protection from minified / mangled / dropped function names
  var PROPER = EXISTS && (function something() { /* empty */ }).name === 'something';
  var CONFIGURABLE = EXISTS && (!DESCRIPTORS$5 || (DESCRIPTORS$5 && getDescriptor(FunctionPrototype$2, 'name').configurable));

  var functionName = {
    EXISTS: EXISTS,
    PROPER: PROPER,
    CONFIGURABLE: CONFIGURABLE
  };

  var uncurryThis$n = functionUncurryThis;
  var isCallable$f = isCallable$l;
  var store$1 = sharedStore;

  var functionToString$1 = uncurryThis$n(Function.toString);

  // this helper broken in `core-js@3.4.1-3.4.4`, so we can't use `shared` helper
  if (!isCallable$f(store$1.inspectSource)) {
    store$1.inspectSource = function (it) {
      return functionToString$1(it);
    };
  }

  var inspectSource$3 = store$1.inspectSource;

  var global$e = global$l;
  var isCallable$e = isCallable$l;

  var WeakMap$1 = global$e.WeakMap;

  var weakMapBasicDetection = isCallable$e(WeakMap$1) && /native code/.test(String(WeakMap$1));

  var shared$2 = shared$4.exports;
  var uid = uid$2;

  var keys = shared$2('keys');

  var sharedKey$2 = function (key) {
    return keys[key] || (keys[key] = uid(key));
  };

  var hiddenKeys$4 = {};

  var NATIVE_WEAK_MAP = weakMapBasicDetection;
  var global$d = global$l;
  var isObject$6 = isObject$b;
  var createNonEnumerableProperty$3 = createNonEnumerableProperty$4;
  var hasOwn$5 = hasOwnProperty_1;
  var shared$1 = sharedStore;
  var sharedKey$1 = sharedKey$2;
  var hiddenKeys$3 = hiddenKeys$4;

  var OBJECT_ALREADY_INITIALIZED = 'Object already initialized';
  var TypeError$2 = global$d.TypeError;
  var WeakMap = global$d.WeakMap;
  var set$1, get, has;

  var enforce = function (it) {
    return has(it) ? get(it) : set$1(it, {});
  };

  var getterFor = function (TYPE) {
    return function (it) {
      var state;
      if (!isObject$6(it) || (state = get(it)).type !== TYPE) {
        throw TypeError$2('Incompatible receiver, ' + TYPE + ' required');
      } return state;
    };
  };

  if (NATIVE_WEAK_MAP || shared$1.state) {
    var store = shared$1.state || (shared$1.state = new WeakMap());
    /* eslint-disable no-self-assign -- prototype methods protection */
    store.get = store.get;
    store.has = store.has;
    store.set = store.set;
    /* eslint-enable no-self-assign -- prototype methods protection */
    set$1 = function (it, metadata) {
      if (store.has(it)) throw TypeError$2(OBJECT_ALREADY_INITIALIZED);
      metadata.facade = it;
      store.set(it, metadata);
      return metadata;
    };
    get = function (it) {
      return store.get(it) || {};
    };
    has = function (it) {
      return store.has(it);
    };
  } else {
    var STATE = sharedKey$1('state');
    hiddenKeys$3[STATE] = true;
    set$1 = function (it, metadata) {
      if (hasOwn$5(it, STATE)) throw TypeError$2(OBJECT_ALREADY_INITIALIZED);
      metadata.facade = it;
      createNonEnumerableProperty$3(it, STATE, metadata);
      return metadata;
    };
    get = function (it) {
      return hasOwn$5(it, STATE) ? it[STATE] : {};
    };
    has = function (it) {
      return hasOwn$5(it, STATE);
    };
  }

  var internalState = {
    set: set$1,
    get: get,
    has: has,
    enforce: enforce,
    getterFor: getterFor
  };

  var uncurryThis$m = functionUncurryThis;
  var fails$g = fails$n;
  var isCallable$d = isCallable$l;
  var hasOwn$4 = hasOwnProperty_1;
  var DESCRIPTORS$4 = descriptors;
  var CONFIGURABLE_FUNCTION_NAME = functionName.CONFIGURABLE;
  var inspectSource$2 = inspectSource$3;
  var InternalStateModule$1 = internalState;

  var enforceInternalState = InternalStateModule$1.enforce;
  var getInternalState$2 = InternalStateModule$1.get;
  var $String$3 = String;
  // eslint-disable-next-line es/no-object-defineproperty -- safe
  var defineProperty$2 = Object.defineProperty;
  var stringSlice$5 = uncurryThis$m(''.slice);
  var replace$4 = uncurryThis$m(''.replace);
  var join = uncurryThis$m([].join);

  var CONFIGURABLE_LENGTH = DESCRIPTORS$4 && !fails$g(function () {
    return defineProperty$2(function () { /* empty */ }, 'length', { value: 8 }).length !== 8;
  });

  var TEMPLATE = String(String).split('String');

  var makeBuiltIn$2 = makeBuiltIn$3.exports = function (value, name, options) {
    if (stringSlice$5($String$3(name), 0, 7) === 'Symbol(') {
      name = '[' + replace$4($String$3(name), /^Symbol\(([^)]*)\)/, '$1') + ']';
    }
    if (options && options.getter) name = 'get ' + name;
    if (options && options.setter) name = 'set ' + name;
    if (!hasOwn$4(value, 'name') || (CONFIGURABLE_FUNCTION_NAME && value.name !== name)) {
      if (DESCRIPTORS$4) defineProperty$2(value, 'name', { value: name, configurable: true });
      else value.name = name;
    }
    if (CONFIGURABLE_LENGTH && options && hasOwn$4(options, 'arity') && value.length !== options.arity) {
      defineProperty$2(value, 'length', { value: options.arity });
    }
    try {
      if (options && hasOwn$4(options, 'constructor') && options.constructor) {
        if (DESCRIPTORS$4) defineProperty$2(value, 'prototype', { writable: false });
      // in V8 ~ Chrome 53, prototypes of some methods, like `Array.prototype.values`, are non-writable
      } else if (value.prototype) value.prototype = undefined;
    } catch (error) { /* empty */ }
    var state = enforceInternalState(value);
    if (!hasOwn$4(state, 'source')) {
      state.source = join(TEMPLATE, typeof name == 'string' ? name : '');
    } return value;
  };

  // add fake Function#toString for correct work wrapped methods / constructors with methods like LoDash isNative
  // eslint-disable-next-line no-extend-native -- required
  Function.prototype.toString = makeBuiltIn$2(function toString() {
    return isCallable$d(this) && getInternalState$2(this).source || inspectSource$2(this);
  }, 'toString');

  var isCallable$c = isCallable$l;
  var definePropertyModule$3 = objectDefineProperty;
  var makeBuiltIn$1 = makeBuiltIn$3.exports;
  var defineGlobalProperty$1 = defineGlobalProperty$3;

  var defineBuiltIn$5 = function (O, key, value, options) {
    if (!options) options = {};
    var simple = options.enumerable;
    var name = options.name !== undefined ? options.name : key;
    if (isCallable$c(value)) makeBuiltIn$1(value, name, options);
    if (options.global) {
      if (simple) O[key] = value;
      else defineGlobalProperty$1(key, value);
    } else {
      try {
        if (!options.unsafe) delete O[key];
        else if (O[key]) simple = true;
      } catch (error) { /* empty */ }
      if (simple) O[key] = value;
      else definePropertyModule$3.f(O, key, {
        value: value,
        enumerable: false,
        configurable: !options.nonConfigurable,
        writable: !options.nonWritable
      });
    } return O;
  };

  var objectGetOwnPropertyNames = {};

  var ceil = Math.ceil;
  var floor$1 = Math.floor;

  // `Math.trunc` method
  // https://tc39.es/ecma262/#sec-math.trunc
  // eslint-disable-next-line es/no-math-trunc -- safe
  var mathTrunc = Math.trunc || function trunc(x) {
    var n = +x;
    return (n > 0 ? floor$1 : ceil)(n);
  };

  var trunc = mathTrunc;

  // `ToIntegerOrInfinity` abstract operation
  // https://tc39.es/ecma262/#sec-tointegerorinfinity
  var toIntegerOrInfinity$4 = function (argument) {
    var number = +argument;
    // eslint-disable-next-line no-self-compare -- NaN check
    return number !== number || number === 0 ? 0 : trunc(number);
  };

  var toIntegerOrInfinity$3 = toIntegerOrInfinity$4;

  var max$3 = Math.max;
  var min$4 = Math.min;

  // Helper for a popular repeating case of the spec:
  // Let integer be ? ToInteger(index).
  // If integer < 0, let result be max((length + integer), 0); else let result be min(integer, length).
  var toAbsoluteIndex$3 = function (index, length) {
    var integer = toIntegerOrInfinity$3(index);
    return integer < 0 ? max$3(integer + length, 0) : min$4(integer, length);
  };

  var toIntegerOrInfinity$2 = toIntegerOrInfinity$4;

  var min$3 = Math.min;

  // `ToLength` abstract operation
  // https://tc39.es/ecma262/#sec-tolength
  var toLength$4 = function (argument) {
    return argument > 0 ? min$3(toIntegerOrInfinity$2(argument), 0x1FFFFFFFFFFFFF) : 0; // 2 ** 53 - 1 == 9007199254740991
  };

  var toLength$3 = toLength$4;

  // `LengthOfArrayLike` abstract operation
  // https://tc39.es/ecma262/#sec-lengthofarraylike
  var lengthOfArrayLike$6 = function (obj) {
    return toLength$3(obj.length);
  };

  var toIndexedObject$5 = toIndexedObject$7;
  var toAbsoluteIndex$2 = toAbsoluteIndex$3;
  var lengthOfArrayLike$5 = lengthOfArrayLike$6;

  // `Array.prototype.{ indexOf, includes }` methods implementation
  var createMethod$3 = function (IS_INCLUDES) {
    return function ($this, el, fromIndex) {
      var O = toIndexedObject$5($this);
      var length = lengthOfArrayLike$5(O);
      var index = toAbsoluteIndex$2(fromIndex, length);
      var value;
      // Array#includes uses SameValueZero equality algorithm
      // eslint-disable-next-line no-self-compare -- NaN check
      if (IS_INCLUDES && el != el) while (length > index) {
        value = O[index++];
        // eslint-disable-next-line no-self-compare -- NaN check
        if (value != value) return true;
      // Array#indexOf ignores holes, Array#includes - not
      } else for (;length > index; index++) {
        if ((IS_INCLUDES || index in O) && O[index] === el) return IS_INCLUDES || index || 0;
      } return !IS_INCLUDES && -1;
    };
  };

  var arrayIncludes = {
    // `Array.prototype.includes` method
    // https://tc39.es/ecma262/#sec-array.prototype.includes
    includes: createMethod$3(true),
    // `Array.prototype.indexOf` method
    // https://tc39.es/ecma262/#sec-array.prototype.indexof
    indexOf: createMethod$3(false)
  };

  var uncurryThis$l = functionUncurryThis;
  var hasOwn$3 = hasOwnProperty_1;
  var toIndexedObject$4 = toIndexedObject$7;
  var indexOf$1 = arrayIncludes.indexOf;
  var hiddenKeys$2 = hiddenKeys$4;

  var push$3 = uncurryThis$l([].push);

  var objectKeysInternal = function (object, names) {
    var O = toIndexedObject$4(object);
    var i = 0;
    var result = [];
    var key;
    for (key in O) !hasOwn$3(hiddenKeys$2, key) && hasOwn$3(O, key) && push$3(result, key);
    // Don't enum bug & hidden keys
    while (names.length > i) if (hasOwn$3(O, key = names[i++])) {
      ~indexOf$1(result, key) || push$3(result, key);
    }
    return result;
  };

  // IE8- don't enum bug keys
  var enumBugKeys$3 = [
    'constructor',
    'hasOwnProperty',
    'isPrototypeOf',
    'propertyIsEnumerable',
    'toLocaleString',
    'toString',
    'valueOf'
  ];

  var internalObjectKeys$1 = objectKeysInternal;
  var enumBugKeys$2 = enumBugKeys$3;

  var hiddenKeys$1 = enumBugKeys$2.concat('length', 'prototype');

  // `Object.getOwnPropertyNames` method
  // https://tc39.es/ecma262/#sec-object.getownpropertynames
  // eslint-disable-next-line es/no-object-getownpropertynames -- safe
  objectGetOwnPropertyNames.f = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
    return internalObjectKeys$1(O, hiddenKeys$1);
  };

  var objectGetOwnPropertySymbols = {};

  // eslint-disable-next-line es/no-object-getownpropertysymbols -- safe
  objectGetOwnPropertySymbols.f = Object.getOwnPropertySymbols;

  var getBuiltIn$6 = getBuiltIn$8;
  var uncurryThis$k = functionUncurryThis;
  var getOwnPropertyNamesModule = objectGetOwnPropertyNames;
  var getOwnPropertySymbolsModule = objectGetOwnPropertySymbols;
  var anObject$c = anObject$e;

  var concat$1 = uncurryThis$k([].concat);

  // all object keys, includes non-enumerable and symbols
  var ownKeys$1 = getBuiltIn$6('Reflect', 'ownKeys') || function ownKeys(it) {
    var keys = getOwnPropertyNamesModule.f(anObject$c(it));
    var getOwnPropertySymbols = getOwnPropertySymbolsModule.f;
    return getOwnPropertySymbols ? concat$1(keys, getOwnPropertySymbols(it)) : keys;
  };

  var hasOwn$2 = hasOwnProperty_1;
  var ownKeys = ownKeys$1;
  var getOwnPropertyDescriptorModule = objectGetOwnPropertyDescriptor;
  var definePropertyModule$2 = objectDefineProperty;

  var copyConstructorProperties$1 = function (target, source, exceptions) {
    var keys = ownKeys(source);
    var defineProperty = definePropertyModule$2.f;
    var getOwnPropertyDescriptor = getOwnPropertyDescriptorModule.f;
    for (var i = 0; i < keys.length; i++) {
      var key = keys[i];
      if (!hasOwn$2(target, key) && !(exceptions && hasOwn$2(exceptions, key))) {
        defineProperty(target, key, getOwnPropertyDescriptor(source, key));
      }
    }
  };

  var fails$f = fails$n;
  var isCallable$b = isCallable$l;

  var replacement = /#|\.prototype\./;

  var isForced$2 = function (feature, detection) {
    var value = data[normalize(feature)];
    return value == POLYFILL ? true
      : value == NATIVE ? false
      : isCallable$b(detection) ? fails$f(detection)
      : !!detection;
  };

  var normalize = isForced$2.normalize = function (string) {
    return String(string).replace(replacement, '.').toLowerCase();
  };

  var data = isForced$2.data = {};
  var NATIVE = isForced$2.NATIVE = 'N';
  var POLYFILL = isForced$2.POLYFILL = 'P';

  var isForced_1 = isForced$2;

  var global$c = global$l;
  var getOwnPropertyDescriptor$3 = objectGetOwnPropertyDescriptor.f;
  var createNonEnumerableProperty$2 = createNonEnumerableProperty$4;
  var defineBuiltIn$4 = defineBuiltIn$5;
  var defineGlobalProperty = defineGlobalProperty$3;
  var copyConstructorProperties = copyConstructorProperties$1;
  var isForced$1 = isForced_1;

  /*
    options.target         - name of the target object
    options.global         - target is the global object
    options.stat           - export as static methods of target
    options.proto          - export as prototype methods of target
    options.real           - real prototype method for the `pure` version
    options.forced         - export even if the native feature is available
    options.bind           - bind methods to the target, required for the `pure` version
    options.wrap           - wrap constructors to preventing global pollution, required for the `pure` version
    options.unsafe         - use the simple assignment of property instead of delete + defineProperty
    options.sham           - add a flag to not completely full polyfills
    options.enumerable     - export as enumerable property
    options.dontCallGetSet - prevent calling a getter on target
    options.name           - the .name of the function if it does not match the key
  */
  var _export = function (options, source) {
    var TARGET = options.target;
    var GLOBAL = options.global;
    var STATIC = options.stat;
    var FORCED, target, key, targetProperty, sourceProperty, descriptor;
    if (GLOBAL) {
      target = global$c;
    } else if (STATIC) {
      target = global$c[TARGET] || defineGlobalProperty(TARGET, {});
    } else {
      target = (global$c[TARGET] || {}).prototype;
    }
    if (target) for (key in source) {
      sourceProperty = source[key];
      if (options.dontCallGetSet) {
        descriptor = getOwnPropertyDescriptor$3(target, key);
        targetProperty = descriptor && descriptor.value;
      } else targetProperty = target[key];
      FORCED = isForced$1(GLOBAL ? key : TARGET + (STATIC ? '.' : '#') + key, options.forced);
      // contained in target
      if (!FORCED && targetProperty !== undefined) {
        if (typeof sourceProperty == typeof targetProperty) continue;
        copyConstructorProperties(sourceProperty, targetProperty);
      }
      // add a flag to not completely full polyfills
      if (options.sham || (targetProperty && targetProperty.sham)) {
        createNonEnumerableProperty$2(sourceProperty, 'sham', true);
      }
      defineBuiltIn$4(target, key, sourceProperty, options);
    }
  };

  var wellKnownSymbol$g = wellKnownSymbol$i;

  var TO_STRING_TAG$2 = wellKnownSymbol$g('toStringTag');
  var test = {};

  test[TO_STRING_TAG$2] = 'z';

  var toStringTagSupport = String(test) === '[object z]';

  var TO_STRING_TAG_SUPPORT$2 = toStringTagSupport;
  var isCallable$a = isCallable$l;
  var classofRaw$1 = classofRaw$2;
  var wellKnownSymbol$f = wellKnownSymbol$i;

  var TO_STRING_TAG$1 = wellKnownSymbol$f('toStringTag');
  var $Object = Object;

  // ES3 wrong here
  var CORRECT_ARGUMENTS = classofRaw$1(function () { return arguments; }()) == 'Arguments';

  // fallback for IE11 Script Access Denied error
  var tryGet = function (it, key) {
    try {
      return it[key];
    } catch (error) { /* empty */ }
  };

  // getting tag from ES6+ `Object.prototype.toString`
  var classof$b = TO_STRING_TAG_SUPPORT$2 ? classofRaw$1 : function (it) {
    var O, tag, result;
    return it === undefined ? 'Undefined' : it === null ? 'Null'
      // @@toStringTag case
      : typeof (tag = tryGet(O = $Object(it), TO_STRING_TAG$1)) == 'string' ? tag
      // builtinTag case
      : CORRECT_ARGUMENTS ? classofRaw$1(O)
      // ES3 arguments fallback
      : (result = classofRaw$1(O)) == 'Object' && isCallable$a(O.callee) ? 'Arguments' : result;
  };

  var classof$a = classof$b;

  var $String$2 = String;

  var toString$b = function (argument) {
    if (classof$a(argument) === 'Symbol') throw TypeError('Cannot convert a Symbol value to a string');
    return $String$2(argument);
  };

  var anObject$b = anObject$e;

  // `RegExp.prototype.flags` getter implementation
  // https://tc39.es/ecma262/#sec-get-regexp.prototype.flags
  var regexpFlags$1 = function () {
    var that = anObject$b(this);
    var result = '';
    if (that.hasIndices) result += 'd';
    if (that.global) result += 'g';
    if (that.ignoreCase) result += 'i';
    if (that.multiline) result += 'm';
    if (that.dotAll) result += 's';
    if (that.unicode) result += 'u';
    if (that.unicodeSets) result += 'v';
    if (that.sticky) result += 'y';
    return result;
  };

  var fails$e = fails$n;
  var global$b = global$l;

  // babel-minify and Closure Compiler transpiles RegExp('a', 'y') -> /a/y and it causes SyntaxError
  var $RegExp$2 = global$b.RegExp;

  var UNSUPPORTED_Y$1 = fails$e(function () {
    var re = $RegExp$2('a', 'y');
    re.lastIndex = 2;
    return re.exec('abcd') != null;
  });

  // UC Browser bug
  // https://github.com/zloirock/core-js/issues/1008
  var MISSED_STICKY$1 = UNSUPPORTED_Y$1 || fails$e(function () {
    return !$RegExp$2('a', 'y').sticky;
  });

  var BROKEN_CARET = UNSUPPORTED_Y$1 || fails$e(function () {
    // https://bugzilla.mozilla.org/show_bug.cgi?id=773687
    var re = $RegExp$2('^r', 'gy');
    re.lastIndex = 2;
    return re.exec('str') != null;
  });

  var regexpStickyHelpers = {
    BROKEN_CARET: BROKEN_CARET,
    MISSED_STICKY: MISSED_STICKY$1,
    UNSUPPORTED_Y: UNSUPPORTED_Y$1
  };

  var objectDefineProperties = {};

  var internalObjectKeys = objectKeysInternal;
  var enumBugKeys$1 = enumBugKeys$3;

  // `Object.keys` method
  // https://tc39.es/ecma262/#sec-object.keys
  // eslint-disable-next-line es/no-object-keys -- safe
  var objectKeys$1 = Object.keys || function keys(O) {
    return internalObjectKeys(O, enumBugKeys$1);
  };

  var DESCRIPTORS$3 = descriptors;
  var V8_PROTOTYPE_DEFINE_BUG = v8PrototypeDefineBug;
  var definePropertyModule$1 = objectDefineProperty;
  var anObject$a = anObject$e;
  var toIndexedObject$3 = toIndexedObject$7;
  var objectKeys = objectKeys$1;

  // `Object.defineProperties` method
  // https://tc39.es/ecma262/#sec-object.defineproperties
  // eslint-disable-next-line es/no-object-defineproperties -- safe
  objectDefineProperties.f = DESCRIPTORS$3 && !V8_PROTOTYPE_DEFINE_BUG ? Object.defineProperties : function defineProperties(O, Properties) {
    anObject$a(O);
    var props = toIndexedObject$3(Properties);
    var keys = objectKeys(Properties);
    var length = keys.length;
    var index = 0;
    var key;
    while (length > index) definePropertyModule$1.f(O, key = keys[index++], props[key]);
    return O;
  };

  var getBuiltIn$5 = getBuiltIn$8;

  var html$2 = getBuiltIn$5('document', 'documentElement');

  /* global ActiveXObject -- old IE, WSH */

  var anObject$9 = anObject$e;
  var definePropertiesModule = objectDefineProperties;
  var enumBugKeys = enumBugKeys$3;
  var hiddenKeys = hiddenKeys$4;
  var html$1 = html$2;
  var documentCreateElement$1 = documentCreateElement$2;
  var sharedKey = sharedKey$2;

  var GT = '>';
  var LT = '<';
  var PROTOTYPE = 'prototype';
  var SCRIPT = 'script';
  var IE_PROTO = sharedKey('IE_PROTO');

  var EmptyConstructor = function () { /* empty */ };

  var scriptTag = function (content) {
    return LT + SCRIPT + GT + content + LT + '/' + SCRIPT + GT;
  };

  // Create object with fake `null` prototype: use ActiveX Object with cleared prototype
  var NullProtoObjectViaActiveX = function (activeXDocument) {
    activeXDocument.write(scriptTag(''));
    activeXDocument.close();
    var temp = activeXDocument.parentWindow.Object;
    activeXDocument = null; // avoid memory leak
    return temp;
  };

  // Create object with fake `null` prototype: use iframe Object with cleared prototype
  var NullProtoObjectViaIFrame = function () {
    // Thrash, waste and sodomy: IE GC bug
    var iframe = documentCreateElement$1('iframe');
    var JS = 'java' + SCRIPT + ':';
    var iframeDocument;
    iframe.style.display = 'none';
    html$1.appendChild(iframe);
    // https://github.com/zloirock/core-js/issues/475
    iframe.src = String(JS);
    iframeDocument = iframe.contentWindow.document;
    iframeDocument.open();
    iframeDocument.write(scriptTag('document.F=Object'));
    iframeDocument.close();
    return iframeDocument.F;
  };

  // Check for document.domain and active x support
  // No need to use active x approach when document.domain is not set
  // see https://github.com/es-shims/es5-shim/issues/150
  // variation of https://github.com/kitcambridge/es5-shim/commit/4f738ac066346
  // avoid IE GC bug
  var activeXDocument;
  var NullProtoObject = function () {
    try {
      activeXDocument = new ActiveXObject('htmlfile');
    } catch (error) { /* ignore */ }
    NullProtoObject = typeof document != 'undefined'
      ? document.domain && activeXDocument
        ? NullProtoObjectViaActiveX(activeXDocument) // old IE
        : NullProtoObjectViaIFrame()
      : NullProtoObjectViaActiveX(activeXDocument); // WSH
    var length = enumBugKeys.length;
    while (length--) delete NullProtoObject[PROTOTYPE][enumBugKeys[length]];
    return NullProtoObject();
  };

  hiddenKeys[IE_PROTO] = true;

  // `Object.create` method
  // https://tc39.es/ecma262/#sec-object.create
  // eslint-disable-next-line es/no-object-create -- safe
  var objectCreate = Object.create || function create(O, Properties) {
    var result;
    if (O !== null) {
      EmptyConstructor[PROTOTYPE] = anObject$9(O);
      result = new EmptyConstructor();
      EmptyConstructor[PROTOTYPE] = null;
      // add "__proto__" for Object.getPrototypeOf polyfill
      result[IE_PROTO] = O;
    } else result = NullProtoObject();
    return Properties === undefined ? result : definePropertiesModule.f(result, Properties);
  };

  var fails$d = fails$n;
  var global$a = global$l;

  // babel-minify and Closure Compiler transpiles RegExp('.', 's') -> /./s and it causes SyntaxError
  var $RegExp$1 = global$a.RegExp;

  var regexpUnsupportedDotAll = fails$d(function () {
    var re = $RegExp$1('.', 's');
    return !(re.dotAll && re.exec('\n') && re.flags === 's');
  });

  var fails$c = fails$n;
  var global$9 = global$l;

  // babel-minify and Closure Compiler transpiles RegExp('(?<a>b)', 'g') -> /(?<a>b)/g and it causes SyntaxError
  var $RegExp = global$9.RegExp;

  var regexpUnsupportedNcg = fails$c(function () {
    var re = $RegExp('(?<a>b)', 'g');
    return re.exec('b').groups.a !== 'b' ||
      'b'.replace(re, '$<a>c') !== 'bc';
  });

  /* eslint-disable regexp/no-empty-capturing-group, regexp/no-empty-group, regexp/no-lazy-ends -- testing */
  /* eslint-disable regexp/no-useless-quantifier -- testing */
  var call$c = functionCall;
  var uncurryThis$j = functionUncurryThis;
  var toString$a = toString$b;
  var regexpFlags = regexpFlags$1;
  var stickyHelpers = regexpStickyHelpers;
  var shared = shared$4.exports;
  var create = objectCreate;
  var getInternalState$1 = internalState.get;
  var UNSUPPORTED_DOT_ALL = regexpUnsupportedDotAll;
  var UNSUPPORTED_NCG = regexpUnsupportedNcg;

  var nativeReplace = shared('native-string-replace', String.prototype.replace);
  var nativeExec = RegExp.prototype.exec;
  var patchedExec = nativeExec;
  var charAt$5 = uncurryThis$j(''.charAt);
  var indexOf = uncurryThis$j(''.indexOf);
  var replace$3 = uncurryThis$j(''.replace);
  var stringSlice$4 = uncurryThis$j(''.slice);

  var UPDATES_LAST_INDEX_WRONG = (function () {
    var re1 = /a/;
    var re2 = /b*/g;
    call$c(nativeExec, re1, 'a');
    call$c(nativeExec, re2, 'a');
    return re1.lastIndex !== 0 || re2.lastIndex !== 0;
  })();

  var UNSUPPORTED_Y = stickyHelpers.BROKEN_CARET;

  // nonparticipating capturing group, copied from es5-shim's String#split patch.
  var NPCG_INCLUDED = /()??/.exec('')[1] !== undefined;

  var PATCH = UPDATES_LAST_INDEX_WRONG || NPCG_INCLUDED || UNSUPPORTED_Y || UNSUPPORTED_DOT_ALL || UNSUPPORTED_NCG;

  if (PATCH) {
    patchedExec = function exec(string) {
      var re = this;
      var state = getInternalState$1(re);
      var str = toString$a(string);
      var raw = state.raw;
      var result, reCopy, lastIndex, match, i, object, group;

      if (raw) {
        raw.lastIndex = re.lastIndex;
        result = call$c(patchedExec, raw, str);
        re.lastIndex = raw.lastIndex;
        return result;
      }

      var groups = state.groups;
      var sticky = UNSUPPORTED_Y && re.sticky;
      var flags = call$c(regexpFlags, re);
      var source = re.source;
      var charsAdded = 0;
      var strCopy = str;

      if (sticky) {
        flags = replace$3(flags, 'y', '');
        if (indexOf(flags, 'g') === -1) {
          flags += 'g';
        }

        strCopy = stringSlice$4(str, re.lastIndex);
        // Support anchored sticky behavior.
        if (re.lastIndex > 0 && (!re.multiline || re.multiline && charAt$5(str, re.lastIndex - 1) !== '\n')) {
          source = '(?: ' + source + ')';
          strCopy = ' ' + strCopy;
          charsAdded++;
        }
        // ^(? + rx + ) is needed, in combination with some str slicing, to
        // simulate the 'y' flag.
        reCopy = new RegExp('^(?:' + source + ')', flags);
      }

      if (NPCG_INCLUDED) {
        reCopy = new RegExp('^' + source + '$(?!\\s)', flags);
      }
      if (UPDATES_LAST_INDEX_WRONG) lastIndex = re.lastIndex;

      match = call$c(nativeExec, sticky ? reCopy : re, strCopy);

      if (sticky) {
        if (match) {
          match.input = stringSlice$4(match.input, charsAdded);
          match[0] = stringSlice$4(match[0], charsAdded);
          match.index = re.lastIndex;
          re.lastIndex += match[0].length;
        } else re.lastIndex = 0;
      } else if (UPDATES_LAST_INDEX_WRONG && match) {
        re.lastIndex = re.global ? match.index + match[0].length : lastIndex;
      }
      if (NPCG_INCLUDED && match && match.length > 1) {
        // Fix browsers whose `exec` methods don't consistently return `undefined`
        // for NPCG, like IE8. NOTE: This doesn't work for /(.?)?/
        call$c(nativeReplace, match[0], reCopy, function () {
          for (i = 1; i < arguments.length - 2; i++) {
            if (arguments[i] === undefined) match[i] = undefined;
          }
        });
      }

      if (match && groups) {
        match.groups = object = create(null);
        for (i = 0; i < groups.length; i++) {
          group = groups[i];
          object[group[0]] = match[group[1]];
        }
      }

      return match;
    };
  }

  var regexpExec$2 = patchedExec;

  var $$i = _export;
  var exec$3 = regexpExec$2;

  // `RegExp.prototype.exec` method
  // https://tc39.es/ecma262/#sec-regexp.prototype.exec
  $$i({ target: 'RegExp', proto: true, forced: /./.exec !== exec$3 }, {
    exec: exec$3
  });

  // a string of all valid unicode whitespaces
  var whitespaces$4 = '\u0009\u000A\u000B\u000C\u000D\u0020\u00A0\u1680\u2000\u2001\u2002' +
    '\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028\u2029\uFEFF';

  var uncurryThis$i = functionUncurryThis;
  var requireObjectCoercible$5 = requireObjectCoercible$8;
  var toString$9 = toString$b;
  var whitespaces$3 = whitespaces$4;

  var replace$2 = uncurryThis$i(''.replace);
  var ltrim = RegExp('^[' + whitespaces$3 + ']+');
  var rtrim = RegExp('(^|[^' + whitespaces$3 + '])[' + whitespaces$3 + ']+$');

  // `String.prototype.{ trim, trimStart, trimEnd, trimLeft, trimRight }` methods implementation
  var createMethod$2 = function (TYPE) {
    return function ($this) {
      var string = toString$9(requireObjectCoercible$5($this));
      if (TYPE & 1) string = replace$2(string, ltrim, '');
      if (TYPE & 2) string = replace$2(string, rtrim, '$1');
      return string;
    };
  };

  var stringTrim = {
    // `String.prototype.{ trimLeft, trimStart }` methods
    // https://tc39.es/ecma262/#sec-string.prototype.trimstart
    start: createMethod$2(1),
    // `String.prototype.{ trimRight, trimEnd }` methods
    // https://tc39.es/ecma262/#sec-string.prototype.trimend
    end: createMethod$2(2),
    // `String.prototype.trim` method
    // https://tc39.es/ecma262/#sec-string.prototype.trim
    trim: createMethod$2(3)
  };

  var global$8 = global$l;
  var fails$b = fails$n;
  var uncurryThis$h = functionUncurryThis;
  var toString$8 = toString$b;
  var trim$1 = stringTrim.trim;
  var whitespaces$2 = whitespaces$4;

  var charAt$4 = uncurryThis$h(''.charAt);
  var $parseFloat$1 = global$8.parseFloat;
  var Symbol$2 = global$8.Symbol;
  var ITERATOR$4 = Symbol$2 && Symbol$2.iterator;
  var FORCED$3 = 1 / $parseFloat$1(whitespaces$2 + '-0') !== -Infinity
    // MS Edge 18- broken with boxed symbols
    || (ITERATOR$4 && !fails$b(function () { $parseFloat$1(Object(ITERATOR$4)); }));

  // `parseFloat` method
  // https://tc39.es/ecma262/#sec-parsefloat-string
  var numberParseFloat = FORCED$3 ? function parseFloat(string) {
    var trimmedString = trim$1(toString$8(string));
    var result = $parseFloat$1(trimmedString);
    return result === 0 && charAt$4(trimmedString, 0) == '-' ? -0 : result;
  } : $parseFloat$1;

  var $$h = _export;
  var $parseFloat = numberParseFloat;

  // `parseFloat` method
  // https://tc39.es/ecma262/#sec-parsefloat-string
  $$h({ global: true, forced: parseFloat != $parseFloat }, {
    parseFloat: $parseFloat
  });

  var classof$9 = classofRaw$2;

  // `IsArray` abstract operation
  // https://tc39.es/ecma262/#sec-isarray
  // eslint-disable-next-line es/no-array-isarray -- safe
  var isArray$4 = Array.isArray || function isArray(argument) {
    return classof$9(argument) == 'Array';
  };

  var uncurryThis$g = functionUncurryThis;
  var fails$a = fails$n;
  var isCallable$9 = isCallable$l;
  var classof$8 = classof$b;
  var getBuiltIn$4 = getBuiltIn$8;
  var inspectSource$1 = inspectSource$3;

  var noop = function () { /* empty */ };
  var empty = [];
  var construct = getBuiltIn$4('Reflect', 'construct');
  var constructorRegExp = /^\s*(?:class|function)\b/;
  var exec$2 = uncurryThis$g(constructorRegExp.exec);
  var INCORRECT_TO_STRING = !constructorRegExp.exec(noop);

  var isConstructorModern = function isConstructor(argument) {
    if (!isCallable$9(argument)) return false;
    try {
      construct(noop, empty, argument);
      return true;
    } catch (error) {
      return false;
    }
  };

  var isConstructorLegacy = function isConstructor(argument) {
    if (!isCallable$9(argument)) return false;
    switch (classof$8(argument)) {
      case 'AsyncFunction':
      case 'GeneratorFunction':
      case 'AsyncGeneratorFunction': return false;
    }
    try {
      // we can't check .prototype since constructors produced by .bind haven't it
      // `Function#toString` throws on some built-it function in some legacy engines
      // (for example, `DOMQuad` and similar in FF41-)
      return INCORRECT_TO_STRING || !!exec$2(constructorRegExp, inspectSource$1(argument));
    } catch (error) {
      return true;
    }
  };

  isConstructorLegacy.sham = true;

  // `IsConstructor` abstract operation
  // https://tc39.es/ecma262/#sec-isconstructor
  var isConstructor$3 = !construct || fails$a(function () {
    var called;
    return isConstructorModern(isConstructorModern.call)
      || !isConstructorModern(Object)
      || !isConstructorModern(function () { called = true; })
      || called;
  }) ? isConstructorLegacy : isConstructorModern;

  var toPropertyKey = toPropertyKey$3;
  var definePropertyModule = objectDefineProperty;
  var createPropertyDescriptor = createPropertyDescriptor$3;

  var createProperty$3 = function (object, key, value) {
    var propertyKey = toPropertyKey(key);
    if (propertyKey in object) definePropertyModule.f(object, propertyKey, createPropertyDescriptor(0, value));
    else object[propertyKey] = value;
  };

  var fails$9 = fails$n;
  var wellKnownSymbol$e = wellKnownSymbol$i;
  var V8_VERSION$2 = engineV8Version;

  var SPECIES$6 = wellKnownSymbol$e('species');

  var arrayMethodHasSpeciesSupport$4 = function (METHOD_NAME) {
    // We can't use this feature detection in V8 since it causes
    // deoptimization and serious performance degradation
    // https://github.com/zloirock/core-js/issues/677
    return V8_VERSION$2 >= 51 || !fails$9(function () {
      var array = [];
      var constructor = array.constructor = {};
      constructor[SPECIES$6] = function () {
        return { foo: 1 };
      };
      return array[METHOD_NAME](Boolean).foo !== 1;
    });
  };

  var uncurryThis$f = functionUncurryThis;

  var arraySlice$3 = uncurryThis$f([].slice);

  var $$g = _export;
  var isArray$3 = isArray$4;
  var isConstructor$2 = isConstructor$3;
  var isObject$5 = isObject$b;
  var toAbsoluteIndex$1 = toAbsoluteIndex$3;
  var lengthOfArrayLike$4 = lengthOfArrayLike$6;
  var toIndexedObject$2 = toIndexedObject$7;
  var createProperty$2 = createProperty$3;
  var wellKnownSymbol$d = wellKnownSymbol$i;
  var arrayMethodHasSpeciesSupport$3 = arrayMethodHasSpeciesSupport$4;
  var nativeSlice = arraySlice$3;

  var HAS_SPECIES_SUPPORT$2 = arrayMethodHasSpeciesSupport$3('slice');

  var SPECIES$5 = wellKnownSymbol$d('species');
  var $Array$2 = Array;
  var max$2 = Math.max;

  // `Array.prototype.slice` method
  // https://tc39.es/ecma262/#sec-array.prototype.slice
  // fallback for not array-like ES3 strings and DOM objects
  $$g({ target: 'Array', proto: true, forced: !HAS_SPECIES_SUPPORT$2 }, {
    slice: function slice(start, end) {
      var O = toIndexedObject$2(this);
      var length = lengthOfArrayLike$4(O);
      var k = toAbsoluteIndex$1(start, length);
      var fin = toAbsoluteIndex$1(end === undefined ? length : end, length);
      // inline `ArraySpeciesCreate` for usage native `Array#slice` where it's possible
      var Constructor, result, n;
      if (isArray$3(O)) {
        Constructor = O.constructor;
        // cross-realm fallback
        if (isConstructor$2(Constructor) && (Constructor === $Array$2 || isArray$3(Constructor.prototype))) {
          Constructor = undefined;
        } else if (isObject$5(Constructor)) {
          Constructor = Constructor[SPECIES$5];
          if (Constructor === null) Constructor = undefined;
        }
        if (Constructor === $Array$2 || Constructor === undefined) {
          return nativeSlice(O, k, fin);
        }
      }
      result = new (Constructor === undefined ? $Array$2 : Constructor)(max$2(fin - k, 0));
      for (n = 0; k < fin; k++, n++) if (k in O) createProperty$2(result, n, O[k]);
      result.length = n;
      return result;
    }
  });

  var classofRaw = classofRaw$2;
  var uncurryThis$e = functionUncurryThis;

  var functionUncurryThisClause = function (fn) {
    // Nashorn bug:
    //   https://github.com/zloirock/core-js/issues/1128
    //   https://github.com/zloirock/core-js/issues/1130
    if (classofRaw(fn) === 'Function') return uncurryThis$e(fn);
  };

  var isObject$4 = isObject$b;
  var classof$7 = classofRaw$2;
  var wellKnownSymbol$c = wellKnownSymbol$i;

  var MATCH$1 = wellKnownSymbol$c('match');

  // `IsRegExp` abstract operation
  // https://tc39.es/ecma262/#sec-isregexp
  var isRegexp = function (it) {
    var isRegExp;
    return isObject$4(it) && ((isRegExp = it[MATCH$1]) !== undefined ? !!isRegExp : classof$7(it) == 'RegExp');
  };

  var isRegExp = isRegexp;

  var $TypeError$a = TypeError;

  var notARegexp = function (it) {
    if (isRegExp(it)) {
      throw $TypeError$a("The method doesn't accept regular expressions");
    } return it;
  };

  var wellKnownSymbol$b = wellKnownSymbol$i;

  var MATCH = wellKnownSymbol$b('match');

  var correctIsRegexpLogic = function (METHOD_NAME) {
    var regexp = /./;
    try {
      '/./'[METHOD_NAME](regexp);
    } catch (error1) {
      try {
        regexp[MATCH] = false;
        return '/./'[METHOD_NAME](regexp);
      } catch (error2) { /* empty */ }
    } return false;
  };

  var $$f = _export;
  var uncurryThis$d = functionUncurryThisClause;
  var getOwnPropertyDescriptor$2 = objectGetOwnPropertyDescriptor.f;
  var toLength$2 = toLength$4;
  var toString$7 = toString$b;
  var notARegExp$1 = notARegexp;
  var requireObjectCoercible$4 = requireObjectCoercible$8;
  var correctIsRegExpLogic$1 = correctIsRegexpLogic;

  // eslint-disable-next-line es/no-string-prototype-endswith -- safe
  var nativeEndsWith = uncurryThis$d(''.endsWith);
  var slice = uncurryThis$d(''.slice);
  var min$2 = Math.min;

  var CORRECT_IS_REGEXP_LOGIC$1 = correctIsRegExpLogic$1('endsWith');
  // https://github.com/zloirock/core-js/pull/702
  var MDN_POLYFILL_BUG$1 = !CORRECT_IS_REGEXP_LOGIC$1 && !!function () {
    var descriptor = getOwnPropertyDescriptor$2(String.prototype, 'endsWith');
    return descriptor && !descriptor.writable;
  }();

  // `String.prototype.endsWith` method
  // https://tc39.es/ecma262/#sec-string.prototype.endswith
  $$f({ target: 'String', proto: true, forced: !MDN_POLYFILL_BUG$1 && !CORRECT_IS_REGEXP_LOGIC$1 }, {
    endsWith: function endsWith(searchString /* , endPosition = @length */) {
      var that = toString$7(requireObjectCoercible$4(this));
      notARegExp$1(searchString);
      var endPosition = arguments.length > 1 ? arguments[1] : undefined;
      var len = that.length;
      var end = endPosition === undefined ? len : min$2(toLength$2(endPosition), len);
      var search = toString$7(searchString);
      return nativeEndsWith
        ? nativeEndsWith(that, search, end)
        : slice(that, end - search.length, end) === search;
    }
  });

  var TO_STRING_TAG_SUPPORT$1 = toStringTagSupport;
  var classof$6 = classof$b;

  // `Object.prototype.toString` method implementation
  // https://tc39.es/ecma262/#sec-object.prototype.tostring
  var objectToString = TO_STRING_TAG_SUPPORT$1 ? {}.toString : function toString() {
    return '[object ' + classof$6(this) + ']';
  };

  var TO_STRING_TAG_SUPPORT = toStringTagSupport;
  var defineBuiltIn$3 = defineBuiltIn$5;
  var toString$6 = objectToString;

  // `Object.prototype.toString` method
  // https://tc39.es/ecma262/#sec-object.prototype.tostring
  if (!TO_STRING_TAG_SUPPORT) {
    defineBuiltIn$3(Object.prototype, 'toString', toString$6, { unsafe: true });
  }

  var makeBuiltIn = makeBuiltIn$3.exports;
  var defineProperty$1 = objectDefineProperty;

  var defineBuiltInAccessor$3 = function (target, name, descriptor) {
    if (descriptor.get) makeBuiltIn(descriptor.get, name, { getter: true });
    if (descriptor.set) makeBuiltIn(descriptor.set, name, { setter: true });
    return defineProperty$1.f(target, name, descriptor);
  };

  var DESCRIPTORS$2 = descriptors;
  var MISSED_STICKY = regexpStickyHelpers.MISSED_STICKY;
  var classof$5 = classofRaw$2;
  var defineBuiltInAccessor$2 = defineBuiltInAccessor$3;
  var getInternalState = internalState.get;

  var RegExpPrototype$1 = RegExp.prototype;
  var $TypeError$9 = TypeError;

  // `RegExp.prototype.sticky` getter
  // https://tc39.es/ecma262/#sec-get-regexp.prototype.sticky
  if (DESCRIPTORS$2 && MISSED_STICKY) {
    defineBuiltInAccessor$2(RegExpPrototype$1, 'sticky', {
      configurable: true,
      get: function sticky() {
        if (this === RegExpPrototype$1) return;
        // We can't use InternalStateModule.getterFor because
        // we don't add metadata for regexps created by a literal.
        if (classof$5(this) === 'RegExp') {
          return !!getInternalState(this).sticky;
        }
        throw $TypeError$9('Incompatible receiver, RegExp required');
      }
    });
  }

  // iterable DOM collections
  // flag - `iterable` interface - 'entries', 'keys', 'values', 'forEach' methods
  var domIterables = {
    CSSRuleList: 0,
    CSSStyleDeclaration: 0,
    CSSValueList: 0,
    ClientRectList: 0,
    DOMRectList: 0,
    DOMStringList: 0,
    DOMTokenList: 1,
    DataTransferItemList: 0,
    FileList: 0,
    HTMLAllCollection: 0,
    HTMLCollection: 0,
    HTMLFormElement: 0,
    HTMLSelectElement: 0,
    MediaList: 0,
    MimeTypeArray: 0,
    NamedNodeMap: 0,
    NodeList: 1,
    PaintRequestList: 0,
    Plugin: 0,
    PluginArray: 0,
    SVGLengthList: 0,
    SVGNumberList: 0,
    SVGPathSegList: 0,
    SVGPointList: 0,
    SVGStringList: 0,
    SVGTransformList: 0,
    SourceBufferList: 0,
    StyleSheetList: 0,
    TextTrackCueList: 0,
    TextTrackList: 0,
    TouchList: 0
  };

  // in old WebKit versions, `element.classList` is not an instance of global `DOMTokenList`
  var documentCreateElement = documentCreateElement$2;

  var classList = documentCreateElement('span').classList;
  var DOMTokenListPrototype$1 = classList && classList.constructor && classList.constructor.prototype;

  var domTokenListPrototype = DOMTokenListPrototype$1 === Object.prototype ? undefined : DOMTokenListPrototype$1;

  var uncurryThis$c = functionUncurryThisClause;
  var aCallable$6 = aCallable$8;
  var NATIVE_BIND$1 = functionBindNative;

  var bind$5 = uncurryThis$c(uncurryThis$c.bind);

  // optional / simple context binding
  var functionBindContext = function (fn, that) {
    aCallable$6(fn);
    return that === undefined ? fn : NATIVE_BIND$1 ? bind$5(fn, that) : function (/* ...args */) {
      return fn.apply(that, arguments);
    };
  };

  var isArray$2 = isArray$4;
  var isConstructor$1 = isConstructor$3;
  var isObject$3 = isObject$b;
  var wellKnownSymbol$a = wellKnownSymbol$i;

  var SPECIES$4 = wellKnownSymbol$a('species');
  var $Array$1 = Array;

  // a part of `ArraySpeciesCreate` abstract operation
  // https://tc39.es/ecma262/#sec-arrayspeciescreate
  var arraySpeciesConstructor$1 = function (originalArray) {
    var C;
    if (isArray$2(originalArray)) {
      C = originalArray.constructor;
      // cross-realm fallback
      if (isConstructor$1(C) && (C === $Array$1 || isArray$2(C.prototype))) C = undefined;
      else if (isObject$3(C)) {
        C = C[SPECIES$4];
        if (C === null) C = undefined;
      }
    } return C === undefined ? $Array$1 : C;
  };

  var arraySpeciesConstructor = arraySpeciesConstructor$1;

  // `ArraySpeciesCreate` abstract operation
  // https://tc39.es/ecma262/#sec-arrayspeciescreate
  var arraySpeciesCreate$2 = function (originalArray, length) {
    return new (arraySpeciesConstructor(originalArray))(length === 0 ? 0 : length);
  };

  var bind$4 = functionBindContext;
  var uncurryThis$b = functionUncurryThis;
  var IndexedObject$1 = indexedObject;
  var toObject$2 = toObject$4;
  var lengthOfArrayLike$3 = lengthOfArrayLike$6;
  var arraySpeciesCreate$1 = arraySpeciesCreate$2;

  var push$2 = uncurryThis$b([].push);

  // `Array.prototype.{ forEach, map, filter, some, every, find, findIndex, filterReject }` methods implementation
  var createMethod$1 = function (TYPE) {
    var IS_MAP = TYPE == 1;
    var IS_FILTER = TYPE == 2;
    var IS_SOME = TYPE == 3;
    var IS_EVERY = TYPE == 4;
    var IS_FIND_INDEX = TYPE == 6;
    var IS_FILTER_REJECT = TYPE == 7;
    var NO_HOLES = TYPE == 5 || IS_FIND_INDEX;
    return function ($this, callbackfn, that, specificCreate) {
      var O = toObject$2($this);
      var self = IndexedObject$1(O);
      var boundFunction = bind$4(callbackfn, that);
      var length = lengthOfArrayLike$3(self);
      var index = 0;
      var create = specificCreate || arraySpeciesCreate$1;
      var target = IS_MAP ? create($this, length) : IS_FILTER || IS_FILTER_REJECT ? create($this, 0) : undefined;
      var value, result;
      for (;length > index; index++) if (NO_HOLES || index in self) {
        value = self[index];
        result = boundFunction(value, index, O);
        if (TYPE) {
          if (IS_MAP) target[index] = result; // map
          else if (result) switch (TYPE) {
            case 3: return true;              // some
            case 5: return value;             // find
            case 6: return index;             // findIndex
            case 2: push$2(target, value);      // filter
          } else switch (TYPE) {
            case 4: return false;             // every
            case 7: push$2(target, value);      // filterReject
          }
        }
      }
      return IS_FIND_INDEX ? -1 : IS_SOME || IS_EVERY ? IS_EVERY : target;
    };
  };

  var arrayIteration = {
    // `Array.prototype.forEach` method
    // https://tc39.es/ecma262/#sec-array.prototype.foreach
    forEach: createMethod$1(0),
    // `Array.prototype.map` method
    // https://tc39.es/ecma262/#sec-array.prototype.map
    map: createMethod$1(1),
    // `Array.prototype.filter` method
    // https://tc39.es/ecma262/#sec-array.prototype.filter
    filter: createMethod$1(2),
    // `Array.prototype.some` method
    // https://tc39.es/ecma262/#sec-array.prototype.some
    some: createMethod$1(3),
    // `Array.prototype.every` method
    // https://tc39.es/ecma262/#sec-array.prototype.every
    every: createMethod$1(4),
    // `Array.prototype.find` method
    // https://tc39.es/ecma262/#sec-array.prototype.find
    find: createMethod$1(5),
    // `Array.prototype.findIndex` method
    // https://tc39.es/ecma262/#sec-array.prototype.findIndex
    findIndex: createMethod$1(6),
    // `Array.prototype.filterReject` method
    // https://github.com/tc39/proposal-array-filtering
    filterReject: createMethod$1(7)
  };

  var fails$8 = fails$n;

  var arrayMethodIsStrict$2 = function (METHOD_NAME, argument) {
    var method = [][METHOD_NAME];
    return !!method && fails$8(function () {
      // eslint-disable-next-line no-useless-call -- required for testing
      method.call(null, argument || function () { return 1; }, 1);
    });
  };

  var $forEach = arrayIteration.forEach;
  var arrayMethodIsStrict$1 = arrayMethodIsStrict$2;

  var STRICT_METHOD = arrayMethodIsStrict$1('forEach');

  // `Array.prototype.forEach` method implementation
  // https://tc39.es/ecma262/#sec-array.prototype.foreach
  var arrayForEach = !STRICT_METHOD ? function forEach(callbackfn /* , thisArg */) {
    return $forEach(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  // eslint-disable-next-line es/no-array-prototype-foreach -- safe
  } : [].forEach;

  var global$7 = global$l;
  var DOMIterables = domIterables;
  var DOMTokenListPrototype = domTokenListPrototype;
  var forEach = arrayForEach;
  var createNonEnumerableProperty$1 = createNonEnumerableProperty$4;

  var handlePrototype = function (CollectionPrototype) {
    // some Chrome versions have non-configurable methods on DOMTokenList
    if (CollectionPrototype && CollectionPrototype.forEach !== forEach) try {
      createNonEnumerableProperty$1(CollectionPrototype, 'forEach', forEach);
    } catch (error) {
      CollectionPrototype.forEach = forEach;
    }
  };

  for (var COLLECTION_NAME in DOMIterables) {
    if (DOMIterables[COLLECTION_NAME]) {
      handlePrototype(global$7[COLLECTION_NAME] && global$7[COLLECTION_NAME].prototype);
    }
  }

  handlePrototype(DOMTokenListPrototype);

  var global$6 = global$l;
  var fails$7 = fails$n;
  var uncurryThis$a = functionUncurryThis;
  var toString$5 = toString$b;
  var trim = stringTrim.trim;
  var whitespaces$1 = whitespaces$4;

  var $parseInt$1 = global$6.parseInt;
  var Symbol$1 = global$6.Symbol;
  var ITERATOR$3 = Symbol$1 && Symbol$1.iterator;
  var hex = /^[+-]?0x/i;
  var exec$1 = uncurryThis$a(hex.exec);
  var FORCED$2 = $parseInt$1(whitespaces$1 + '08') !== 8 || $parseInt$1(whitespaces$1 + '0x16') !== 22
    // MS Edge 18- broken with boxed symbols
    || (ITERATOR$3 && !fails$7(function () { $parseInt$1(Object(ITERATOR$3)); }));

  // `parseInt` method
  // https://tc39.es/ecma262/#sec-parseint-string-radix
  var numberParseInt = FORCED$2 ? function parseInt(string, radix) {
    var S = trim(toString$5(string));
    return $parseInt$1(S, (radix >>> 0) || (exec$1(hex, S) ? 16 : 10));
  } : $parseInt$1;

  var $$e = _export;
  var $parseInt = numberParseInt;

  // `parseInt` method
  // https://tc39.es/ecma262/#sec-parseint-string-radix
  $$e({ global: true, forced: parseInt != $parseInt }, {
    parseInt: $parseInt
  });

  var $$d = _export;
  var $filter = arrayIteration.filter;
  var arrayMethodHasSpeciesSupport$2 = arrayMethodHasSpeciesSupport$4;

  var HAS_SPECIES_SUPPORT$1 = arrayMethodHasSpeciesSupport$2('filter');

  // `Array.prototype.filter` method
  // https://tc39.es/ecma262/#sec-array.prototype.filter
  // with adding support of @@species
  $$d({ target: 'Array', proto: true, forced: !HAS_SPECIES_SUPPORT$1 }, {
    filter: function filter(callbackfn /* , thisArg */) {
      return $filter(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
    }
  });

  var $$c = _export;
  var uncurryThis$9 = functionUncurryThisClause;
  var getOwnPropertyDescriptor$1 = objectGetOwnPropertyDescriptor.f;
  var toLength$1 = toLength$4;
  var toString$4 = toString$b;
  var notARegExp = notARegexp;
  var requireObjectCoercible$3 = requireObjectCoercible$8;
  var correctIsRegExpLogic = correctIsRegexpLogic;

  // eslint-disable-next-line es/no-string-prototype-startswith -- safe
  var nativeStartsWith = uncurryThis$9(''.startsWith);
  var stringSlice$3 = uncurryThis$9(''.slice);
  var min$1 = Math.min;

  var CORRECT_IS_REGEXP_LOGIC = correctIsRegExpLogic('startsWith');
  // https://github.com/zloirock/core-js/pull/702
  var MDN_POLYFILL_BUG = !CORRECT_IS_REGEXP_LOGIC && !!function () {
    var descriptor = getOwnPropertyDescriptor$1(String.prototype, 'startsWith');
    return descriptor && !descriptor.writable;
  }();

  // `String.prototype.startsWith` method
  // https://tc39.es/ecma262/#sec-string.prototype.startswith
  $$c({ target: 'String', proto: true, forced: !MDN_POLYFILL_BUG && !CORRECT_IS_REGEXP_LOGIC }, {
    startsWith: function startsWith(searchString /* , position = 0 */) {
      var that = toString$4(requireObjectCoercible$3(this));
      notARegExp(searchString);
      var index = toLength$1(min$1(arguments.length > 1 ? arguments[1] : undefined, that.length));
      var search = toString$4(searchString);
      return nativeStartsWith
        ? nativeStartsWith(that, search, index)
        : stringSlice$3(that, index, index + search.length) === search;
    }
  });

  var $TypeError$8 = TypeError;
  var MAX_SAFE_INTEGER = 0x1FFFFFFFFFFFFF; // 2 ** 53 - 1 == 9007199254740991

  var doesNotExceedSafeInteger$1 = function (it) {
    if (it > MAX_SAFE_INTEGER) throw $TypeError$8('Maximum allowed index exceeded');
    return it;
  };

  var $$b = _export;
  var fails$6 = fails$n;
  var isArray$1 = isArray$4;
  var isObject$2 = isObject$b;
  var toObject$1 = toObject$4;
  var lengthOfArrayLike$2 = lengthOfArrayLike$6;
  var doesNotExceedSafeInteger = doesNotExceedSafeInteger$1;
  var createProperty$1 = createProperty$3;
  var arraySpeciesCreate = arraySpeciesCreate$2;
  var arrayMethodHasSpeciesSupport$1 = arrayMethodHasSpeciesSupport$4;
  var wellKnownSymbol$9 = wellKnownSymbol$i;
  var V8_VERSION$1 = engineV8Version;

  var IS_CONCAT_SPREADABLE = wellKnownSymbol$9('isConcatSpreadable');

  // We can't use this feature detection in V8 since it causes
  // deoptimization and serious performance degradation
  // https://github.com/zloirock/core-js/issues/679
  var IS_CONCAT_SPREADABLE_SUPPORT = V8_VERSION$1 >= 51 || !fails$6(function () {
    var array = [];
    array[IS_CONCAT_SPREADABLE] = false;
    return array.concat()[0] !== array;
  });

  var isConcatSpreadable = function (O) {
    if (!isObject$2(O)) return false;
    var spreadable = O[IS_CONCAT_SPREADABLE];
    return spreadable !== undefined ? !!spreadable : isArray$1(O);
  };

  var FORCED$1 = !IS_CONCAT_SPREADABLE_SUPPORT || !arrayMethodHasSpeciesSupport$1('concat');

  // `Array.prototype.concat` method
  // https://tc39.es/ecma262/#sec-array.prototype.concat
  // with adding support of @@isConcatSpreadable and @@species
  $$b({ target: 'Array', proto: true, arity: 1, forced: FORCED$1 }, {
    // eslint-disable-next-line no-unused-vars -- required for `.length`
    concat: function concat(arg) {
      var O = toObject$1(this);
      var A = arraySpeciesCreate(O, 0);
      var n = 0;
      var i, k, length, len, E;
      for (i = -1, length = arguments.length; i < length; i++) {
        E = i === -1 ? O : arguments[i];
        if (isConcatSpreadable(E)) {
          len = lengthOfArrayLike$2(E);
          doesNotExceedSafeInteger(n + len);
          for (k = 0; k < len; k++, n++) if (k in E) createProperty$1(A, n, E[k]);
        } else {
          doesNotExceedSafeInteger(n + 1);
          createProperty$1(A, n++, E);
        }
      }
      A.length = n;
      return A;
    }
  });

  var classof$4 = classofRaw$2;

  var engineIsNode = typeof process != 'undefined' && classof$4(process) == 'process';

  var uncurryThis$8 = functionUncurryThis;
  var aCallable$5 = aCallable$8;

  var functionUncurryThisAccessor = function (object, key, method) {
    try {
      // eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
      return uncurryThis$8(aCallable$5(Object.getOwnPropertyDescriptor(object, key)[method]));
    } catch (error) { /* empty */ }
  };

  var isCallable$8 = isCallable$l;

  var $String$1 = String;
  var $TypeError$7 = TypeError;

  var aPossiblePrototype$1 = function (argument) {
    if (typeof argument == 'object' || isCallable$8(argument)) return argument;
    throw $TypeError$7("Can't set " + $String$1(argument) + ' as a prototype');
  };

  /* eslint-disable no-proto -- safe */

  var uncurryThisAccessor = functionUncurryThisAccessor;
  var anObject$8 = anObject$e;
  var aPossiblePrototype = aPossiblePrototype$1;

  // `Object.setPrototypeOf` method
  // https://tc39.es/ecma262/#sec-object.setprototypeof
  // Works with __proto__ only. Old v8 can't work with null proto objects.
  // eslint-disable-next-line es/no-object-setprototypeof -- safe
  var objectSetPrototypeOf = Object.setPrototypeOf || ('__proto__' in {} ? function () {
    var CORRECT_SETTER = false;
    var test = {};
    var setter;
    try {
      setter = uncurryThisAccessor(Object.prototype, '__proto__', 'set');
      setter(test, []);
      CORRECT_SETTER = test instanceof Array;
    } catch (error) { /* empty */ }
    return function setPrototypeOf(O, proto) {
      anObject$8(O);
      aPossiblePrototype(proto);
      if (CORRECT_SETTER) setter(O, proto);
      else O.__proto__ = proto;
      return O;
    };
  }() : undefined);

  var defineProperty = objectDefineProperty.f;
  var hasOwn$1 = hasOwnProperty_1;
  var wellKnownSymbol$8 = wellKnownSymbol$i;

  var TO_STRING_TAG = wellKnownSymbol$8('toStringTag');

  var setToStringTag$1 = function (target, TAG, STATIC) {
    if (target && !STATIC) target = target.prototype;
    if (target && !hasOwn$1(target, TO_STRING_TAG)) {
      defineProperty(target, TO_STRING_TAG, { configurable: true, value: TAG });
    }
  };

  var getBuiltIn$3 = getBuiltIn$8;
  var defineBuiltInAccessor$1 = defineBuiltInAccessor$3;
  var wellKnownSymbol$7 = wellKnownSymbol$i;
  var DESCRIPTORS$1 = descriptors;

  var SPECIES$3 = wellKnownSymbol$7('species');

  var setSpecies$1 = function (CONSTRUCTOR_NAME) {
    var Constructor = getBuiltIn$3(CONSTRUCTOR_NAME);

    if (DESCRIPTORS$1 && Constructor && !Constructor[SPECIES$3]) {
      defineBuiltInAccessor$1(Constructor, SPECIES$3, {
        configurable: true,
        get: function () { return this; }
      });
    }
  };

  var isPrototypeOf$1 = objectIsPrototypeOf;

  var $TypeError$6 = TypeError;

  var anInstance$1 = function (it, Prototype) {
    if (isPrototypeOf$1(Prototype, it)) return it;
    throw $TypeError$6('Incorrect invocation');
  };

  var isConstructor = isConstructor$3;
  var tryToString$2 = tryToString$4;

  var $TypeError$5 = TypeError;

  // `Assert: IsConstructor(argument) is true`
  var aConstructor$1 = function (argument) {
    if (isConstructor(argument)) return argument;
    throw $TypeError$5(tryToString$2(argument) + ' is not a constructor');
  };

  var anObject$7 = anObject$e;
  var aConstructor = aConstructor$1;
  var isNullOrUndefined$3 = isNullOrUndefined$6;
  var wellKnownSymbol$6 = wellKnownSymbol$i;

  var SPECIES$2 = wellKnownSymbol$6('species');

  // `SpeciesConstructor` abstract operation
  // https://tc39.es/ecma262/#sec-speciesconstructor
  var speciesConstructor$1 = function (O, defaultConstructor) {
    var C = anObject$7(O).constructor;
    var S;
    return C === undefined || isNullOrUndefined$3(S = anObject$7(C)[SPECIES$2]) ? defaultConstructor : aConstructor(S);
  };

  var NATIVE_BIND = functionBindNative;

  var FunctionPrototype$1 = Function.prototype;
  var apply$3 = FunctionPrototype$1.apply;
  var call$b = FunctionPrototype$1.call;

  // eslint-disable-next-line es/no-reflect -- safe
  var functionApply = typeof Reflect == 'object' && Reflect.apply || (NATIVE_BIND ? call$b.bind(apply$3) : function () {
    return call$b.apply(apply$3, arguments);
  });

  var $TypeError$4 = TypeError;

  var validateArgumentsLength$1 = function (passed, required) {
    if (passed < required) throw $TypeError$4('Not enough arguments');
    return passed;
  };

  var userAgent$2 = engineUserAgent;

  // eslint-disable-next-line redos/no-vulnerable -- safe
  var engineIsIos = /(?:ipad|iphone|ipod).*applewebkit/i.test(userAgent$2);

  var global$5 = global$l;
  var apply$2 = functionApply;
  var bind$3 = functionBindContext;
  var isCallable$7 = isCallable$l;
  var hasOwn = hasOwnProperty_1;
  var fails$5 = fails$n;
  var html = html$2;
  var arraySlice$2 = arraySlice$3;
  var createElement = documentCreateElement$2;
  var validateArgumentsLength = validateArgumentsLength$1;
  var IS_IOS$1 = engineIsIos;
  var IS_NODE$3 = engineIsNode;

  var set = global$5.setImmediate;
  var clear = global$5.clearImmediate;
  var process$3 = global$5.process;
  var Dispatch = global$5.Dispatch;
  var Function$1 = global$5.Function;
  var MessageChannel = global$5.MessageChannel;
  var String$1 = global$5.String;
  var counter = 0;
  var queue$2 = {};
  var ONREADYSTATECHANGE = 'onreadystatechange';
  var $location, defer, channel, port;

  fails$5(function () {
    // Deno throws a ReferenceError on `location` access without `--location` flag
    $location = global$5.location;
  });

  var run = function (id) {
    if (hasOwn(queue$2, id)) {
      var fn = queue$2[id];
      delete queue$2[id];
      fn();
    }
  };

  var runner = function (id) {
    return function () {
      run(id);
    };
  };

  var eventListener = function (event) {
    run(event.data);
  };

  var globalPostMessageDefer = function (id) {
    // old engines have not location.origin
    global$5.postMessage(String$1(id), $location.protocol + '//' + $location.host);
  };

  // Node.js 0.9+ & IE10+ has setImmediate, otherwise:
  if (!set || !clear) {
    set = function setImmediate(handler) {
      validateArgumentsLength(arguments.length, 1);
      var fn = isCallable$7(handler) ? handler : Function$1(handler);
      var args = arraySlice$2(arguments, 1);
      queue$2[++counter] = function () {
        apply$2(fn, undefined, args);
      };
      defer(counter);
      return counter;
    };
    clear = function clearImmediate(id) {
      delete queue$2[id];
    };
    // Node.js 0.8-
    if (IS_NODE$3) {
      defer = function (id) {
        process$3.nextTick(runner(id));
      };
    // Sphere (JS game engine) Dispatch API
    } else if (Dispatch && Dispatch.now) {
      defer = function (id) {
        Dispatch.now(runner(id));
      };
    // Browsers with MessageChannel, includes WebWorkers
    // except iOS - https://github.com/zloirock/core-js/issues/624
    } else if (MessageChannel && !IS_IOS$1) {
      channel = new MessageChannel();
      port = channel.port2;
      channel.port1.onmessage = eventListener;
      defer = bind$3(port.postMessage, port);
    // Browsers with postMessage, skip WebWorkers
    // IE8 has postMessage, but it's sync & typeof its postMessage is 'object'
    } else if (
      global$5.addEventListener &&
      isCallable$7(global$5.postMessage) &&
      !global$5.importScripts &&
      $location && $location.protocol !== 'file:' &&
      !fails$5(globalPostMessageDefer)
    ) {
      defer = globalPostMessageDefer;
      global$5.addEventListener('message', eventListener, false);
    // IE8-
    } else if (ONREADYSTATECHANGE in createElement('script')) {
      defer = function (id) {
        html.appendChild(createElement('script'))[ONREADYSTATECHANGE] = function () {
          html.removeChild(this);
          run(id);
        };
      };
    // Rest old browsers
    } else {
      defer = function (id) {
        setTimeout(runner(id), 0);
      };
    }
  }

  var task$1 = {
    set: set,
    clear: clear
  };

  var Queue$2 = function () {
    this.head = null;
    this.tail = null;
  };

  Queue$2.prototype = {
    add: function (item) {
      var entry = { item: item, next: null };
      var tail = this.tail;
      if (tail) tail.next = entry;
      else this.head = entry;
      this.tail = entry;
    },
    get: function () {
      var entry = this.head;
      if (entry) {
        var next = this.head = entry.next;
        if (next === null) this.tail = null;
        return entry.item;
      }
    }
  };

  var queue$1 = Queue$2;

  var userAgent$1 = engineUserAgent;

  var engineIsIosPebble = /ipad|iphone|ipod/i.test(userAgent$1) && typeof Pebble != 'undefined';

  var userAgent = engineUserAgent;

  var engineIsWebosWebkit = /web0s(?!.*chrome)/i.test(userAgent);

  var global$4 = global$l;
  var bind$2 = functionBindContext;
  var getOwnPropertyDescriptor = objectGetOwnPropertyDescriptor.f;
  var macrotask = task$1.set;
  var Queue$1 = queue$1;
  var IS_IOS = engineIsIos;
  var IS_IOS_PEBBLE = engineIsIosPebble;
  var IS_WEBOS_WEBKIT = engineIsWebosWebkit;
  var IS_NODE$2 = engineIsNode;

  var MutationObserver$1 = global$4.MutationObserver || global$4.WebKitMutationObserver;
  var document$2 = global$4.document;
  var process$2 = global$4.process;
  var Promise$1 = global$4.Promise;
  // Node.js 11 shows ExperimentalWarning on getting `queueMicrotask`
  var queueMicrotaskDescriptor = getOwnPropertyDescriptor(global$4, 'queueMicrotask');
  var microtask$1 = queueMicrotaskDescriptor && queueMicrotaskDescriptor.value;
  var notify$1, toggle, node, promise, then;

  // modern engines have queueMicrotask method
  if (!microtask$1) {
    var queue = new Queue$1();

    var flush = function () {
      var parent, fn;
      if (IS_NODE$2 && (parent = process$2.domain)) parent.exit();
      while (fn = queue.get()) try {
        fn();
      } catch (error) {
        if (queue.head) notify$1();
        throw error;
      }
      if (parent) parent.enter();
    };

    // browsers with MutationObserver, except iOS - https://github.com/zloirock/core-js/issues/339
    // also except WebOS Webkit https://github.com/zloirock/core-js/issues/898
    if (!IS_IOS && !IS_NODE$2 && !IS_WEBOS_WEBKIT && MutationObserver$1 && document$2) {
      toggle = true;
      node = document$2.createTextNode('');
      new MutationObserver$1(flush).observe(node, { characterData: true });
      notify$1 = function () {
        node.data = toggle = !toggle;
      };
    // environments with maybe non-completely correct, but existent Promise
    } else if (!IS_IOS_PEBBLE && Promise$1 && Promise$1.resolve) {
      // Promise.resolve without an argument throws an error in LG WebOS 2
      promise = Promise$1.resolve(undefined);
      // workaround of WebKit ~ iOS Safari 10.1 bug
      promise.constructor = Promise$1;
      then = bind$2(promise.then, promise);
      notify$1 = function () {
        then(flush);
      };
    // Node.js without promises
    } else if (IS_NODE$2) {
      notify$1 = function () {
        process$2.nextTick(flush);
      };
    // for other environments - macrotask based on:
    // - setImmediate
    // - MessageChannel
    // - window.postMessage
    // - onreadystatechange
    // - setTimeout
    } else {
      // `webpack` dev server bug on IE global methods - use bind(fn, global)
      macrotask = bind$2(macrotask, global$4);
      notify$1 = function () {
        macrotask(flush);
      };
    }

    microtask$1 = function (fn) {
      if (!queue.head) notify$1();
      queue.add(fn);
    };
  }

  var microtask_1 = microtask$1;

  var hostReportErrors$1 = function (a, b) {
    try {
      // eslint-disable-next-line no-console -- safe
      arguments.length == 1 ? console.error(a) : console.error(a, b);
    } catch (error) { /* empty */ }
  };

  var perform$3 = function (exec) {
    try {
      return { error: false, value: exec() };
    } catch (error) {
      return { error: true, value: error };
    }
  };

  var global$3 = global$l;

  var promiseNativeConstructor = global$3.Promise;

  /* global Deno -- Deno case */

  var engineIsDeno = typeof Deno == 'object' && Deno && typeof Deno.version == 'object';

  var IS_DENO$1 = engineIsDeno;
  var IS_NODE$1 = engineIsNode;

  var engineIsBrowser = !IS_DENO$1 && !IS_NODE$1
    && typeof window == 'object'
    && typeof document == 'object';

  var global$2 = global$l;
  var NativePromiseConstructor$3 = promiseNativeConstructor;
  var isCallable$6 = isCallable$l;
  var isForced = isForced_1;
  var inspectSource = inspectSource$3;
  var wellKnownSymbol$5 = wellKnownSymbol$i;
  var IS_BROWSER = engineIsBrowser;
  var IS_DENO = engineIsDeno;
  var V8_VERSION = engineV8Version;

  NativePromiseConstructor$3 && NativePromiseConstructor$3.prototype;
  var SPECIES$1 = wellKnownSymbol$5('species');
  var SUBCLASSING = false;
  var NATIVE_PROMISE_REJECTION_EVENT$1 = isCallable$6(global$2.PromiseRejectionEvent);

  var FORCED_PROMISE_CONSTRUCTOR$5 = isForced('Promise', function () {
    var PROMISE_CONSTRUCTOR_SOURCE = inspectSource(NativePromiseConstructor$3);
    var GLOBAL_CORE_JS_PROMISE = PROMISE_CONSTRUCTOR_SOURCE !== String(NativePromiseConstructor$3);
    // V8 6.6 (Node 10 and Chrome 66) have a bug with resolving custom thenables
    // https://bugs.chromium.org/p/chromium/issues/detail?id=830565
    // We can't detect it synchronously, so just check versions
    if (!GLOBAL_CORE_JS_PROMISE && V8_VERSION === 66) return true;
    // We can't use @@species feature detection in V8 since it causes
    // deoptimization and performance degradation
    // https://github.com/zloirock/core-js/issues/679
    if (!V8_VERSION || V8_VERSION < 51 || !/native code/.test(PROMISE_CONSTRUCTOR_SOURCE)) {
      // Detect correctness of subclassing with @@species support
      var promise = new NativePromiseConstructor$3(function (resolve) { resolve(1); });
      var FakePromise = function (exec) {
        exec(function () { /* empty */ }, function () { /* empty */ });
      };
      var constructor = promise.constructor = {};
      constructor[SPECIES$1] = FakePromise;
      SUBCLASSING = promise.then(function () { /* empty */ }) instanceof FakePromise;
      if (!SUBCLASSING) return true;
    // Unhandled rejections tracking support, NodeJS Promise without it fails @@species test
    } return !GLOBAL_CORE_JS_PROMISE && (IS_BROWSER || IS_DENO) && !NATIVE_PROMISE_REJECTION_EVENT$1;
  });

  var promiseConstructorDetection = {
    CONSTRUCTOR: FORCED_PROMISE_CONSTRUCTOR$5,
    REJECTION_EVENT: NATIVE_PROMISE_REJECTION_EVENT$1,
    SUBCLASSING: SUBCLASSING
  };

  var newPromiseCapability$2 = {};

  var aCallable$4 = aCallable$8;

  var $TypeError$3 = TypeError;

  var PromiseCapability = function (C) {
    var resolve, reject;
    this.promise = new C(function ($$resolve, $$reject) {
      if (resolve !== undefined || reject !== undefined) throw $TypeError$3('Bad Promise constructor');
      resolve = $$resolve;
      reject = $$reject;
    });
    this.resolve = aCallable$4(resolve);
    this.reject = aCallable$4(reject);
  };

  // `NewPromiseCapability` abstract operation
  // https://tc39.es/ecma262/#sec-newpromisecapability
  newPromiseCapability$2.f = function (C) {
    return new PromiseCapability(C);
  };

  var $$a = _export;
  var IS_NODE = engineIsNode;
  var global$1 = global$l;
  var call$a = functionCall;
  var defineBuiltIn$2 = defineBuiltIn$5;
  var setPrototypeOf = objectSetPrototypeOf;
  var setToStringTag = setToStringTag$1;
  var setSpecies = setSpecies$1;
  var aCallable$3 = aCallable$8;
  var isCallable$5 = isCallable$l;
  var isObject$1 = isObject$b;
  var anInstance = anInstance$1;
  var speciesConstructor = speciesConstructor$1;
  var task = task$1.set;
  var microtask = microtask_1;
  var hostReportErrors = hostReportErrors$1;
  var perform$2 = perform$3;
  var Queue = queue$1;
  var InternalStateModule = internalState;
  var NativePromiseConstructor$2 = promiseNativeConstructor;
  var PromiseConstructorDetection = promiseConstructorDetection;
  var newPromiseCapabilityModule$3 = newPromiseCapability$2;

  var PROMISE = 'Promise';
  var FORCED_PROMISE_CONSTRUCTOR$4 = PromiseConstructorDetection.CONSTRUCTOR;
  var NATIVE_PROMISE_REJECTION_EVENT = PromiseConstructorDetection.REJECTION_EVENT;
  var NATIVE_PROMISE_SUBCLASSING = PromiseConstructorDetection.SUBCLASSING;
  var getInternalPromiseState = InternalStateModule.getterFor(PROMISE);
  var setInternalState = InternalStateModule.set;
  var NativePromisePrototype$1 = NativePromiseConstructor$2 && NativePromiseConstructor$2.prototype;
  var PromiseConstructor = NativePromiseConstructor$2;
  var PromisePrototype = NativePromisePrototype$1;
  var TypeError$1 = global$1.TypeError;
  var document$1 = global$1.document;
  var process$1 = global$1.process;
  var newPromiseCapability$1 = newPromiseCapabilityModule$3.f;
  var newGenericPromiseCapability = newPromiseCapability$1;

  var DISPATCH_EVENT = !!(document$1 && document$1.createEvent && global$1.dispatchEvent);
  var UNHANDLED_REJECTION = 'unhandledrejection';
  var REJECTION_HANDLED = 'rejectionhandled';
  var PENDING = 0;
  var FULFILLED = 1;
  var REJECTED = 2;
  var HANDLED = 1;
  var UNHANDLED = 2;

  var Internal, OwnPromiseCapability, PromiseWrapper, nativeThen;

  // helpers
  var isThenable = function (it) {
    var then;
    return isObject$1(it) && isCallable$5(then = it.then) ? then : false;
  };

  var callReaction = function (reaction, state) {
    var value = state.value;
    var ok = state.state == FULFILLED;
    var handler = ok ? reaction.ok : reaction.fail;
    var resolve = reaction.resolve;
    var reject = reaction.reject;
    var domain = reaction.domain;
    var result, then, exited;
    try {
      if (handler) {
        if (!ok) {
          if (state.rejection === UNHANDLED) onHandleUnhandled(state);
          state.rejection = HANDLED;
        }
        if (handler === true) result = value;
        else {
          if (domain) domain.enter();
          result = handler(value); // can throw
          if (domain) {
            domain.exit();
            exited = true;
          }
        }
        if (result === reaction.promise) {
          reject(TypeError$1('Promise-chain cycle'));
        } else if (then = isThenable(result)) {
          call$a(then, result, resolve, reject);
        } else resolve(result);
      } else reject(value);
    } catch (error) {
      if (domain && !exited) domain.exit();
      reject(error);
    }
  };

  var notify = function (state, isReject) {
    if (state.notified) return;
    state.notified = true;
    microtask(function () {
      var reactions = state.reactions;
      var reaction;
      while (reaction = reactions.get()) {
        callReaction(reaction, state);
      }
      state.notified = false;
      if (isReject && !state.rejection) onUnhandled(state);
    });
  };

  var dispatchEvent = function (name, promise, reason) {
    var event, handler;
    if (DISPATCH_EVENT) {
      event = document$1.createEvent('Event');
      event.promise = promise;
      event.reason = reason;
      event.initEvent(name, false, true);
      global$1.dispatchEvent(event);
    } else event = { promise: promise, reason: reason };
    if (!NATIVE_PROMISE_REJECTION_EVENT && (handler = global$1['on' + name])) handler(event);
    else if (name === UNHANDLED_REJECTION) hostReportErrors('Unhandled promise rejection', reason);
  };

  var onUnhandled = function (state) {
    call$a(task, global$1, function () {
      var promise = state.facade;
      var value = state.value;
      var IS_UNHANDLED = isUnhandled(state);
      var result;
      if (IS_UNHANDLED) {
        result = perform$2(function () {
          if (IS_NODE) {
            process$1.emit('unhandledRejection', value, promise);
          } else dispatchEvent(UNHANDLED_REJECTION, promise, value);
        });
        // Browsers should not trigger `rejectionHandled` event if it was handled here, NodeJS - should
        state.rejection = IS_NODE || isUnhandled(state) ? UNHANDLED : HANDLED;
        if (result.error) throw result.value;
      }
    });
  };

  var isUnhandled = function (state) {
    return state.rejection !== HANDLED && !state.parent;
  };

  var onHandleUnhandled = function (state) {
    call$a(task, global$1, function () {
      var promise = state.facade;
      if (IS_NODE) {
        process$1.emit('rejectionHandled', promise);
      } else dispatchEvent(REJECTION_HANDLED, promise, state.value);
    });
  };

  var bind$1 = function (fn, state, unwrap) {
    return function (value) {
      fn(state, value, unwrap);
    };
  };

  var internalReject = function (state, value, unwrap) {
    if (state.done) return;
    state.done = true;
    if (unwrap) state = unwrap;
    state.value = value;
    state.state = REJECTED;
    notify(state, true);
  };

  var internalResolve = function (state, value, unwrap) {
    if (state.done) return;
    state.done = true;
    if (unwrap) state = unwrap;
    try {
      if (state.facade === value) throw TypeError$1("Promise can't be resolved itself");
      var then = isThenable(value);
      if (then) {
        microtask(function () {
          var wrapper = { done: false };
          try {
            call$a(then, value,
              bind$1(internalResolve, wrapper, state),
              bind$1(internalReject, wrapper, state)
            );
          } catch (error) {
            internalReject(wrapper, error, state);
          }
        });
      } else {
        state.value = value;
        state.state = FULFILLED;
        notify(state, false);
      }
    } catch (error) {
      internalReject({ done: false }, error, state);
    }
  };

  // constructor polyfill
  if (FORCED_PROMISE_CONSTRUCTOR$4) {
    // 25.4.3.1 Promise(executor)
    PromiseConstructor = function Promise(executor) {
      anInstance(this, PromisePrototype);
      aCallable$3(executor);
      call$a(Internal, this);
      var state = getInternalPromiseState(this);
      try {
        executor(bind$1(internalResolve, state), bind$1(internalReject, state));
      } catch (error) {
        internalReject(state, error);
      }
    };

    PromisePrototype = PromiseConstructor.prototype;

    // eslint-disable-next-line no-unused-vars -- required for `.length`
    Internal = function Promise(executor) {
      setInternalState(this, {
        type: PROMISE,
        done: false,
        notified: false,
        parent: false,
        reactions: new Queue(),
        rejection: false,
        state: PENDING,
        value: undefined
      });
    };

    // `Promise.prototype.then` method
    // https://tc39.es/ecma262/#sec-promise.prototype.then
    Internal.prototype = defineBuiltIn$2(PromisePrototype, 'then', function then(onFulfilled, onRejected) {
      var state = getInternalPromiseState(this);
      var reaction = newPromiseCapability$1(speciesConstructor(this, PromiseConstructor));
      state.parent = true;
      reaction.ok = isCallable$5(onFulfilled) ? onFulfilled : true;
      reaction.fail = isCallable$5(onRejected) && onRejected;
      reaction.domain = IS_NODE ? process$1.domain : undefined;
      if (state.state == PENDING) state.reactions.add(reaction);
      else microtask(function () {
        callReaction(reaction, state);
      });
      return reaction.promise;
    });

    OwnPromiseCapability = function () {
      var promise = new Internal();
      var state = getInternalPromiseState(promise);
      this.promise = promise;
      this.resolve = bind$1(internalResolve, state);
      this.reject = bind$1(internalReject, state);
    };

    newPromiseCapabilityModule$3.f = newPromiseCapability$1 = function (C) {
      return C === PromiseConstructor || C === PromiseWrapper
        ? new OwnPromiseCapability(C)
        : newGenericPromiseCapability(C);
    };

    if (isCallable$5(NativePromiseConstructor$2) && NativePromisePrototype$1 !== Object.prototype) {
      nativeThen = NativePromisePrototype$1.then;

      if (!NATIVE_PROMISE_SUBCLASSING) {
        // make `Promise#then` return a polyfilled `Promise` for native promise-based APIs
        defineBuiltIn$2(NativePromisePrototype$1, 'then', function then(onFulfilled, onRejected) {
          var that = this;
          return new PromiseConstructor(function (resolve, reject) {
            call$a(nativeThen, that, resolve, reject);
          }).then(onFulfilled, onRejected);
        // https://github.com/zloirock/core-js/issues/640
        }, { unsafe: true });
      }

      // make `.constructor === Promise` work for native promise-based APIs
      try {
        delete NativePromisePrototype$1.constructor;
      } catch (error) { /* empty */ }

      // make `instanceof Promise` work for native promise-based APIs
      if (setPrototypeOf) {
        setPrototypeOf(NativePromisePrototype$1, PromisePrototype);
      }
    }
  }

  $$a({ global: true, constructor: true, wrap: true, forced: FORCED_PROMISE_CONSTRUCTOR$4 }, {
    Promise: PromiseConstructor
  });

  setToStringTag(PromiseConstructor, PROMISE, false);
  setSpecies(PROMISE);

  var iterators = {};

  var wellKnownSymbol$4 = wellKnownSymbol$i;
  var Iterators$1 = iterators;

  var ITERATOR$2 = wellKnownSymbol$4('iterator');
  var ArrayPrototype = Array.prototype;

  // check on default Array iterator
  var isArrayIteratorMethod$1 = function (it) {
    return it !== undefined && (Iterators$1.Array === it || ArrayPrototype[ITERATOR$2] === it);
  };

  var classof$3 = classof$b;
  var getMethod$3 = getMethod$5;
  var isNullOrUndefined$2 = isNullOrUndefined$6;
  var Iterators = iterators;
  var wellKnownSymbol$3 = wellKnownSymbol$i;

  var ITERATOR$1 = wellKnownSymbol$3('iterator');

  var getIteratorMethod$2 = function (it) {
    if (!isNullOrUndefined$2(it)) return getMethod$3(it, ITERATOR$1)
      || getMethod$3(it, '@@iterator')
      || Iterators[classof$3(it)];
  };

  var call$9 = functionCall;
  var aCallable$2 = aCallable$8;
  var anObject$6 = anObject$e;
  var tryToString$1 = tryToString$4;
  var getIteratorMethod$1 = getIteratorMethod$2;

  var $TypeError$2 = TypeError;

  var getIterator$1 = function (argument, usingIterator) {
    var iteratorMethod = arguments.length < 2 ? getIteratorMethod$1(argument) : usingIterator;
    if (aCallable$2(iteratorMethod)) return anObject$6(call$9(iteratorMethod, argument));
    throw $TypeError$2(tryToString$1(argument) + ' is not iterable');
  };

  var call$8 = functionCall;
  var anObject$5 = anObject$e;
  var getMethod$2 = getMethod$5;

  var iteratorClose$1 = function (iterator, kind, value) {
    var innerResult, innerError;
    anObject$5(iterator);
    try {
      innerResult = getMethod$2(iterator, 'return');
      if (!innerResult) {
        if (kind === 'throw') throw value;
        return value;
      }
      innerResult = call$8(innerResult, iterator);
    } catch (error) {
      innerError = true;
      innerResult = error;
    }
    if (kind === 'throw') throw value;
    if (innerError) throw innerResult;
    anObject$5(innerResult);
    return value;
  };

  var bind = functionBindContext;
  var call$7 = functionCall;
  var anObject$4 = anObject$e;
  var tryToString = tryToString$4;
  var isArrayIteratorMethod = isArrayIteratorMethod$1;
  var lengthOfArrayLike$1 = lengthOfArrayLike$6;
  var isPrototypeOf = objectIsPrototypeOf;
  var getIterator = getIterator$1;
  var getIteratorMethod = getIteratorMethod$2;
  var iteratorClose = iteratorClose$1;

  var $TypeError$1 = TypeError;

  var Result = function (stopped, result) {
    this.stopped = stopped;
    this.result = result;
  };

  var ResultPrototype = Result.prototype;

  var iterate$2 = function (iterable, unboundFunction, options) {
    var that = options && options.that;
    var AS_ENTRIES = !!(options && options.AS_ENTRIES);
    var IS_RECORD = !!(options && options.IS_RECORD);
    var IS_ITERATOR = !!(options && options.IS_ITERATOR);
    var INTERRUPTED = !!(options && options.INTERRUPTED);
    var fn = bind(unboundFunction, that);
    var iterator, iterFn, index, length, result, next, step;

    var stop = function (condition) {
      if (iterator) iteratorClose(iterator, 'normal', condition);
      return new Result(true, condition);
    };

    var callFn = function (value) {
      if (AS_ENTRIES) {
        anObject$4(value);
        return INTERRUPTED ? fn(value[0], value[1], stop) : fn(value[0], value[1]);
      } return INTERRUPTED ? fn(value, stop) : fn(value);
    };

    if (IS_RECORD) {
      iterator = iterable.iterator;
    } else if (IS_ITERATOR) {
      iterator = iterable;
    } else {
      iterFn = getIteratorMethod(iterable);
      if (!iterFn) throw $TypeError$1(tryToString(iterable) + ' is not iterable');
      // optimisation for array iterators
      if (isArrayIteratorMethod(iterFn)) {
        for (index = 0, length = lengthOfArrayLike$1(iterable); length > index; index++) {
          result = callFn(iterable[index]);
          if (result && isPrototypeOf(ResultPrototype, result)) return result;
        } return new Result(false);
      }
      iterator = getIterator(iterable, iterFn);
    }

    next = IS_RECORD ? iterable.next : iterator.next;
    while (!(step = call$7(next, iterator)).done) {
      try {
        result = callFn(step.value);
      } catch (error) {
        iteratorClose(iterator, 'throw', error);
      }
      if (typeof result == 'object' && result && isPrototypeOf(ResultPrototype, result)) return result;
    } return new Result(false);
  };

  var wellKnownSymbol$2 = wellKnownSymbol$i;

  var ITERATOR = wellKnownSymbol$2('iterator');
  var SAFE_CLOSING = false;

  try {
    var called = 0;
    var iteratorWithReturn = {
      next: function () {
        return { done: !!called++ };
      },
      'return': function () {
        SAFE_CLOSING = true;
      }
    };
    iteratorWithReturn[ITERATOR] = function () {
      return this;
    };
    // eslint-disable-next-line es/no-array-from, no-throw-literal -- required for testing
    Array.from(iteratorWithReturn, function () { throw 2; });
  } catch (error) { /* empty */ }

  var checkCorrectnessOfIteration$1 = function (exec, SKIP_CLOSING) {
    if (!SKIP_CLOSING && !SAFE_CLOSING) return false;
    var ITERATION_SUPPORT = false;
    try {
      var object = {};
      object[ITERATOR] = function () {
        return {
          next: function () {
            return { done: ITERATION_SUPPORT = true };
          }
        };
      };
      exec(object);
    } catch (error) { /* empty */ }
    return ITERATION_SUPPORT;
  };

  var NativePromiseConstructor$1 = promiseNativeConstructor;
  var checkCorrectnessOfIteration = checkCorrectnessOfIteration$1;
  var FORCED_PROMISE_CONSTRUCTOR$3 = promiseConstructorDetection.CONSTRUCTOR;

  var promiseStaticsIncorrectIteration = FORCED_PROMISE_CONSTRUCTOR$3 || !checkCorrectnessOfIteration(function (iterable) {
    NativePromiseConstructor$1.all(iterable).then(undefined, function () { /* empty */ });
  });

  var $$9 = _export;
  var call$6 = functionCall;
  var aCallable$1 = aCallable$8;
  var newPromiseCapabilityModule$2 = newPromiseCapability$2;
  var perform$1 = perform$3;
  var iterate$1 = iterate$2;
  var PROMISE_STATICS_INCORRECT_ITERATION$1 = promiseStaticsIncorrectIteration;

  // `Promise.all` method
  // https://tc39.es/ecma262/#sec-promise.all
  $$9({ target: 'Promise', stat: true, forced: PROMISE_STATICS_INCORRECT_ITERATION$1 }, {
    all: function all(iterable) {
      var C = this;
      var capability = newPromiseCapabilityModule$2.f(C);
      var resolve = capability.resolve;
      var reject = capability.reject;
      var result = perform$1(function () {
        var $promiseResolve = aCallable$1(C.resolve);
        var values = [];
        var counter = 0;
        var remaining = 1;
        iterate$1(iterable, function (promise) {
          var index = counter++;
          var alreadyCalled = false;
          remaining++;
          call$6($promiseResolve, C, promise).then(function (value) {
            if (alreadyCalled) return;
            alreadyCalled = true;
            values[index] = value;
            --remaining || resolve(values);
          }, reject);
        });
        --remaining || resolve(values);
      });
      if (result.error) reject(result.value);
      return capability.promise;
    }
  });

  var $$8 = _export;
  var FORCED_PROMISE_CONSTRUCTOR$2 = promiseConstructorDetection.CONSTRUCTOR;
  var NativePromiseConstructor = promiseNativeConstructor;
  var getBuiltIn$2 = getBuiltIn$8;
  var isCallable$4 = isCallable$l;
  var defineBuiltIn$1 = defineBuiltIn$5;

  var NativePromisePrototype = NativePromiseConstructor && NativePromiseConstructor.prototype;

  // `Promise.prototype.catch` method
  // https://tc39.es/ecma262/#sec-promise.prototype.catch
  $$8({ target: 'Promise', proto: true, forced: FORCED_PROMISE_CONSTRUCTOR$2, real: true }, {
    'catch': function (onRejected) {
      return this.then(undefined, onRejected);
    }
  });

  // makes sure that native promise-based APIs `Promise#catch` properly works with patched `Promise#then`
  if (isCallable$4(NativePromiseConstructor)) {
    var method = getBuiltIn$2('Promise').prototype['catch'];
    if (NativePromisePrototype['catch'] !== method) {
      defineBuiltIn$1(NativePromisePrototype, 'catch', method, { unsafe: true });
    }
  }

  var $$7 = _export;
  var call$5 = functionCall;
  var aCallable = aCallable$8;
  var newPromiseCapabilityModule$1 = newPromiseCapability$2;
  var perform = perform$3;
  var iterate = iterate$2;
  var PROMISE_STATICS_INCORRECT_ITERATION = promiseStaticsIncorrectIteration;

  // `Promise.race` method
  // https://tc39.es/ecma262/#sec-promise.race
  $$7({ target: 'Promise', stat: true, forced: PROMISE_STATICS_INCORRECT_ITERATION }, {
    race: function race(iterable) {
      var C = this;
      var capability = newPromiseCapabilityModule$1.f(C);
      var reject = capability.reject;
      var result = perform(function () {
        var $promiseResolve = aCallable(C.resolve);
        iterate(iterable, function (promise) {
          call$5($promiseResolve, C, promise).then(capability.resolve, reject);
        });
      });
      if (result.error) reject(result.value);
      return capability.promise;
    }
  });

  var $$6 = _export;
  var call$4 = functionCall;
  var newPromiseCapabilityModule = newPromiseCapability$2;
  var FORCED_PROMISE_CONSTRUCTOR$1 = promiseConstructorDetection.CONSTRUCTOR;

  // `Promise.reject` method
  // https://tc39.es/ecma262/#sec-promise.reject
  $$6({ target: 'Promise', stat: true, forced: FORCED_PROMISE_CONSTRUCTOR$1 }, {
    reject: function reject(r) {
      var capability = newPromiseCapabilityModule.f(this);
      call$4(capability.reject, undefined, r);
      return capability.promise;
    }
  });

  var anObject$3 = anObject$e;
  var isObject = isObject$b;
  var newPromiseCapability = newPromiseCapability$2;

  var promiseResolve$1 = function (C, x) {
    anObject$3(C);
    if (isObject(x) && x.constructor === C) return x;
    var promiseCapability = newPromiseCapability.f(C);
    var resolve = promiseCapability.resolve;
    resolve(x);
    return promiseCapability.promise;
  };

  var $$5 = _export;
  var getBuiltIn$1 = getBuiltIn$8;
  var FORCED_PROMISE_CONSTRUCTOR = promiseConstructorDetection.CONSTRUCTOR;
  var promiseResolve = promiseResolve$1;

  getBuiltIn$1('Promise');

  // `Promise.resolve` method
  // https://tc39.es/ecma262/#sec-promise.resolve
  $$5({ target: 'Promise', stat: true, forced: FORCED_PROMISE_CONSTRUCTOR }, {
    resolve: function resolve(x) {
      return promiseResolve(this, x);
    }
  });

  var PROPER_FUNCTION_NAME = functionName.PROPER;
  var fails$4 = fails$n;
  var whitespaces = whitespaces$4;

  var non = '\u200B\u0085\u180E';

  // check that a method works with the correct list
  // of whitespaces and has a correct name
  var stringTrimForced = function (METHOD_NAME) {
    return fails$4(function () {
      return !!whitespaces[METHOD_NAME]()
        || non[METHOD_NAME]() !== non
        || (PROPER_FUNCTION_NAME && whitespaces[METHOD_NAME].name !== METHOD_NAME);
    });
  };

  var $$4 = _export;
  var $trim = stringTrim.trim;
  var forcedStringTrimMethod = stringTrimForced;

  // `String.prototype.trim` method
  // https://tc39.es/ecma262/#sec-string.prototype.trim
  $$4({ target: 'String', proto: true, forced: forcedStringTrimMethod('trim') }, {
    trim: function trim() {
      return $trim(this);
    }
  });

  // TODO: Remove from `core-js@4` since it's moved to entry points

  var uncurryThis$7 = functionUncurryThisClause;
  var defineBuiltIn = defineBuiltIn$5;
  var regexpExec$1 = regexpExec$2;
  var fails$3 = fails$n;
  var wellKnownSymbol$1 = wellKnownSymbol$i;
  var createNonEnumerableProperty = createNonEnumerableProperty$4;

  var SPECIES = wellKnownSymbol$1('species');
  var RegExpPrototype = RegExp.prototype;

  var fixRegexpWellKnownSymbolLogic = function (KEY, exec, FORCED, SHAM) {
    var SYMBOL = wellKnownSymbol$1(KEY);

    var DELEGATES_TO_SYMBOL = !fails$3(function () {
      // String methods call symbol-named RegEp methods
      var O = {};
      O[SYMBOL] = function () { return 7; };
      return ''[KEY](O) != 7;
    });

    var DELEGATES_TO_EXEC = DELEGATES_TO_SYMBOL && !fails$3(function () {
      // Symbol-named RegExp methods call .exec
      var execCalled = false;
      var re = /a/;

      if (KEY === 'split') {
        // We can't use real regex here since it causes deoptimization
        // and serious performance degradation in V8
        // https://github.com/zloirock/core-js/issues/306
        re = {};
        // RegExp[@@split] doesn't call the regex's exec method, but first creates
        // a new one. We need to return the patched regex when creating the new one.
        re.constructor = {};
        re.constructor[SPECIES] = function () { return re; };
        re.flags = '';
        re[SYMBOL] = /./[SYMBOL];
      }

      re.exec = function () { execCalled = true; return null; };

      re[SYMBOL]('');
      return !execCalled;
    });

    if (
      !DELEGATES_TO_SYMBOL ||
      !DELEGATES_TO_EXEC ||
      FORCED
    ) {
      var uncurriedNativeRegExpMethod = uncurryThis$7(/./[SYMBOL]);
      var methods = exec(SYMBOL, ''[KEY], function (nativeMethod, regexp, str, arg2, forceStringMethod) {
        var uncurriedNativeMethod = uncurryThis$7(nativeMethod);
        var $exec = regexp.exec;
        if ($exec === regexpExec$1 || $exec === RegExpPrototype.exec) {
          if (DELEGATES_TO_SYMBOL && !forceStringMethod) {
            // The native String method already delegates to @@method (this
            // polyfilled function), leasing to infinite recursion.
            // We avoid it by directly calling the native @@method method.
            return { done: true, value: uncurriedNativeRegExpMethod(regexp, str, arg2) };
          }
          return { done: true, value: uncurriedNativeMethod(str, regexp, arg2) };
        }
        return { done: false };
      });

      defineBuiltIn(String.prototype, KEY, methods[0]);
      defineBuiltIn(RegExpPrototype, SYMBOL, methods[1]);
    }

    if (SHAM) createNonEnumerableProperty(RegExpPrototype[SYMBOL], 'sham', true);
  };

  var uncurryThis$6 = functionUncurryThis;
  var toIntegerOrInfinity$1 = toIntegerOrInfinity$4;
  var toString$3 = toString$b;
  var requireObjectCoercible$2 = requireObjectCoercible$8;

  var charAt$3 = uncurryThis$6(''.charAt);
  var charCodeAt$1 = uncurryThis$6(''.charCodeAt);
  var stringSlice$2 = uncurryThis$6(''.slice);

  var createMethod = function (CONVERT_TO_STRING) {
    return function ($this, pos) {
      var S = toString$3(requireObjectCoercible$2($this));
      var position = toIntegerOrInfinity$1(pos);
      var size = S.length;
      var first, second;
      if (position < 0 || position >= size) return CONVERT_TO_STRING ? '' : undefined;
      first = charCodeAt$1(S, position);
      return first < 0xD800 || first > 0xDBFF || position + 1 === size
        || (second = charCodeAt$1(S, position + 1)) < 0xDC00 || second > 0xDFFF
          ? CONVERT_TO_STRING
            ? charAt$3(S, position)
            : first
          : CONVERT_TO_STRING
            ? stringSlice$2(S, position, position + 2)
            : (first - 0xD800 << 10) + (second - 0xDC00) + 0x10000;
    };
  };

  var stringMultibyte = {
    // `String.prototype.codePointAt` method
    // https://tc39.es/ecma262/#sec-string.prototype.codepointat
    codeAt: createMethod(false),
    // `String.prototype.at` method
    // https://github.com/mathiasbynens/String.prototype.at
    charAt: createMethod(true)
  };

  var charAt$2 = stringMultibyte.charAt;

  // `AdvanceStringIndex` abstract operation
  // https://tc39.es/ecma262/#sec-advancestringindex
  var advanceStringIndex$1 = function (S, index, unicode) {
    return index + (unicode ? charAt$2(S, index).length : 1);
  };

  var uncurryThis$5 = functionUncurryThis;
  var toObject = toObject$4;

  var floor = Math.floor;
  var charAt$1 = uncurryThis$5(''.charAt);
  var replace$1 = uncurryThis$5(''.replace);
  var stringSlice$1 = uncurryThis$5(''.slice);
  // eslint-disable-next-line redos/no-vulnerable -- safe
  var SUBSTITUTION_SYMBOLS = /\$([$&'`]|\d{1,2}|<[^>]*>)/g;
  var SUBSTITUTION_SYMBOLS_NO_NAMED = /\$([$&'`]|\d{1,2})/g;

  // `GetSubstitution` abstract operation
  // https://tc39.es/ecma262/#sec-getsubstitution
  var getSubstitution$1 = function (matched, str, position, captures, namedCaptures, replacement) {
    var tailPos = position + matched.length;
    var m = captures.length;
    var symbols = SUBSTITUTION_SYMBOLS_NO_NAMED;
    if (namedCaptures !== undefined) {
      namedCaptures = toObject(namedCaptures);
      symbols = SUBSTITUTION_SYMBOLS;
    }
    return replace$1(replacement, symbols, function (match, ch) {
      var capture;
      switch (charAt$1(ch, 0)) {
        case '$': return '$';
        case '&': return matched;
        case '`': return stringSlice$1(str, 0, position);
        case "'": return stringSlice$1(str, tailPos);
        case '<':
          capture = namedCaptures[stringSlice$1(ch, 1, -1)];
          break;
        default: // \d\d?
          var n = +ch;
          if (n === 0) return match;
          if (n > m) {
            var f = floor(n / 10);
            if (f === 0) return match;
            if (f <= m) return captures[f - 1] === undefined ? charAt$1(ch, 1) : captures[f - 1] + charAt$1(ch, 1);
            return match;
          }
          capture = captures[n - 1];
      }
      return capture === undefined ? '' : capture;
    });
  };

  var call$3 = functionCall;
  var anObject$2 = anObject$e;
  var isCallable$3 = isCallable$l;
  var classof$2 = classofRaw$2;
  var regexpExec = regexpExec$2;

  var $TypeError = TypeError;

  // `RegExpExec` abstract operation
  // https://tc39.es/ecma262/#sec-regexpexec
  var regexpExecAbstract = function (R, S) {
    var exec = R.exec;
    if (isCallable$3(exec)) {
      var result = call$3(exec, R, S);
      if (result !== null) anObject$2(result);
      return result;
    }
    if (classof$2(R) === 'RegExp') return call$3(regexpExec, R, S);
    throw $TypeError('RegExp#exec called on incompatible receiver');
  };

  var apply$1 = functionApply;
  var call$2 = functionCall;
  var uncurryThis$4 = functionUncurryThis;
  var fixRegExpWellKnownSymbolLogic$1 = fixRegexpWellKnownSymbolLogic;
  var fails$2 = fails$n;
  var anObject$1 = anObject$e;
  var isCallable$2 = isCallable$l;
  var isNullOrUndefined$1 = isNullOrUndefined$6;
  var toIntegerOrInfinity = toIntegerOrInfinity$4;
  var toLength = toLength$4;
  var toString$2 = toString$b;
  var requireObjectCoercible$1 = requireObjectCoercible$8;
  var advanceStringIndex = advanceStringIndex$1;
  var getMethod$1 = getMethod$5;
  var getSubstitution = getSubstitution$1;
  var regExpExec$2 = regexpExecAbstract;
  var wellKnownSymbol = wellKnownSymbol$i;

  var REPLACE = wellKnownSymbol('replace');
  var max$1 = Math.max;
  var min = Math.min;
  var concat = uncurryThis$4([].concat);
  var push$1 = uncurryThis$4([].push);
  var stringIndexOf = uncurryThis$4(''.indexOf);
  var stringSlice = uncurryThis$4(''.slice);

  var maybeToString = function (it) {
    return it === undefined ? it : String(it);
  };

  // IE <= 11 replaces $0 with the whole match, as if it was $&
  // https://stackoverflow.com/questions/6024666/getting-ie-to-replace-a-regex-with-the-literal-string-0
  var REPLACE_KEEPS_$0 = (function () {
    // eslint-disable-next-line regexp/prefer-escape-replacement-dollar-char -- required for testing
    return 'a'.replace(/./, '$0') === '$0';
  })();

  // Safari <= 13.0.3(?) substitutes nth capture where n>m with an empty string
  var REGEXP_REPLACE_SUBSTITUTES_UNDEFINED_CAPTURE = (function () {
    if (/./[REPLACE]) {
      return /./[REPLACE]('a', '$0') === '';
    }
    return false;
  })();

  var REPLACE_SUPPORTS_NAMED_GROUPS = !fails$2(function () {
    var re = /./;
    re.exec = function () {
      var result = [];
      result.groups = { a: '7' };
      return result;
    };
    // eslint-disable-next-line regexp/no-useless-dollar-replacements -- false positive
    return ''.replace(re, '$<a>') !== '7';
  });

  // @@replace logic
  fixRegExpWellKnownSymbolLogic$1('replace', function (_, nativeReplace, maybeCallNative) {
    var UNSAFE_SUBSTITUTE = REGEXP_REPLACE_SUBSTITUTES_UNDEFINED_CAPTURE ? '$' : '$0';

    return [
      // `String.prototype.replace` method
      // https://tc39.es/ecma262/#sec-string.prototype.replace
      function replace(searchValue, replaceValue) {
        var O = requireObjectCoercible$1(this);
        var replacer = isNullOrUndefined$1(searchValue) ? undefined : getMethod$1(searchValue, REPLACE);
        return replacer
          ? call$2(replacer, searchValue, O, replaceValue)
          : call$2(nativeReplace, toString$2(O), searchValue, replaceValue);
      },
      // `RegExp.prototype[@@replace]` method
      // https://tc39.es/ecma262/#sec-regexp.prototype-@@replace
      function (string, replaceValue) {
        var rx = anObject$1(this);
        var S = toString$2(string);

        if (
          typeof replaceValue == 'string' &&
          stringIndexOf(replaceValue, UNSAFE_SUBSTITUTE) === -1 &&
          stringIndexOf(replaceValue, '$<') === -1
        ) {
          var res = maybeCallNative(nativeReplace, rx, S, replaceValue);
          if (res.done) return res.value;
        }

        var functionalReplace = isCallable$2(replaceValue);
        if (!functionalReplace) replaceValue = toString$2(replaceValue);

        var global = rx.global;
        if (global) {
          var fullUnicode = rx.unicode;
          rx.lastIndex = 0;
        }
        var results = [];
        while (true) {
          var result = regExpExec$2(rx, S);
          if (result === null) break;

          push$1(results, result);
          if (!global) break;

          var matchStr = toString$2(result[0]);
          if (matchStr === '') rx.lastIndex = advanceStringIndex(S, toLength(rx.lastIndex), fullUnicode);
        }

        var accumulatedResult = '';
        var nextSourcePosition = 0;
        for (var i = 0; i < results.length; i++) {
          result = results[i];

          var matched = toString$2(result[0]);
          var position = max$1(min(toIntegerOrInfinity(result.index), S.length), 0);
          var captures = [];
          // NOTE: This is equivalent to
          //   captures = result.slice(1).map(maybeToString)
          // but for some reason `nativeSlice.call(result, 1, result.length)` (called in
          // the slice polyfill when slicing native arrays) "doesn't work" in safari 9 and
          // causes a crash (https://pastebin.com/N21QzeQA) when trying to debug it.
          for (var j = 1; j < result.length; j++) push$1(captures, maybeToString(result[j]));
          var namedCaptures = result.groups;
          if (functionalReplace) {
            var replacerArgs = concat([matched], captures, position, S);
            if (namedCaptures !== undefined) push$1(replacerArgs, namedCaptures);
            var replacement = toString$2(apply$1(replaceValue, undefined, replacerArgs));
          } else {
            replacement = getSubstitution(matched, S, position, captures, namedCaptures, replaceValue);
          }
          if (position >= nextSourcePosition) {
            accumulatedResult += stringSlice(S, nextSourcePosition, position) + replacement;
            nextSourcePosition = position + matched.length;
          }
        }
        return accumulatedResult + stringSlice(S, nextSourcePosition);
      }
    ];
  }, !REPLACE_SUPPORTS_NAMED_GROUPS || !REPLACE_KEEPS_$0 || REGEXP_REPLACE_SUBSTITUTES_UNDEFINED_CAPTURE);

  var $$3 = _export;
  var uncurryThis$3 = functionUncurryThis;
  var IndexedObject = indexedObject;
  var toIndexedObject$1 = toIndexedObject$7;
  var arrayMethodIsStrict = arrayMethodIsStrict$2;

  var nativeJoin = uncurryThis$3([].join);

  var ES3_STRINGS = IndexedObject != Object;
  var FORCED = ES3_STRINGS || !arrayMethodIsStrict('join', ',');

  // `Array.prototype.join` method
  // https://tc39.es/ecma262/#sec-array.prototype.join
  $$3({ target: 'Array', proto: true, forced: FORCED }, {
    join: function join(separator) {
      return nativeJoin(toIndexedObject$1(this), separator === undefined ? ',' : separator);
    }
  });

  var $$2 = _export;
  var $map = arrayIteration.map;
  var arrayMethodHasSpeciesSupport = arrayMethodHasSpeciesSupport$4;

  var HAS_SPECIES_SUPPORT = arrayMethodHasSpeciesSupport('map');

  // `Array.prototype.map` method
  // https://tc39.es/ecma262/#sec-array.prototype.map
  // with adding support of @@species
  $$2({ target: 'Array', proto: true, forced: !HAS_SPECIES_SUPPORT }, {
    map: function map(callbackfn /* , thisArg */) {
      return $map(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
    }
  });

  var DESCRIPTORS = descriptors;
  var FUNCTION_NAME_EXISTS = functionName.EXISTS;
  var uncurryThis$2 = functionUncurryThis;
  var defineBuiltInAccessor = defineBuiltInAccessor$3;

  var FunctionPrototype = Function.prototype;
  var functionToString = uncurryThis$2(FunctionPrototype.toString);
  var nameRE = /function\b(?:\s|\/\*[\S\s]*?\*\/|\/\/[^\n\r]*[\n\r]+)*([^\s(/]*)/;
  var regExpExec$1 = uncurryThis$2(nameRE.exec);
  var NAME = 'name';

  // Function instances `.name` property
  // https://tc39.es/ecma262/#sec-function-instances-name
  if (DESCRIPTORS && !FUNCTION_NAME_EXISTS) {
    defineBuiltInAccessor(FunctionPrototype, NAME, {
      configurable: true,
      get: function () {
        try {
          return regExpExec$1(nameRE, functionToString(this))[1];
        } catch (error) {
          return '';
        }
      }
    });
  }

  var uncurryThis$1 = functionUncurryThis;
  var isArray = isArray$4;
  var isCallable$1 = isCallable$l;
  var classof$1 = classofRaw$2;
  var toString$1 = toString$b;

  var push = uncurryThis$1([].push);

  var getJsonReplacerFunction = function (replacer) {
    if (isCallable$1(replacer)) return replacer;
    if (!isArray(replacer)) return;
    var rawLength = replacer.length;
    var keys = [];
    for (var i = 0; i < rawLength; i++) {
      var element = replacer[i];
      if (typeof element == 'string') push(keys, element);
      else if (typeof element == 'number' || classof$1(element) == 'Number' || classof$1(element) == 'String') push(keys, toString$1(element));
    }
    var keysLength = keys.length;
    var root = true;
    return function (key, value) {
      if (root) {
        root = false;
        return value;
      }
      if (isArray(this)) return value;
      for (var j = 0; j < keysLength; j++) if (keys[j] === key) return value;
    };
  };

  var $$1 = _export;
  var getBuiltIn = getBuiltIn$8;
  var apply = functionApply;
  var call$1 = functionCall;
  var uncurryThis = functionUncurryThis;
  var fails$1 = fails$n;
  var isCallable = isCallable$l;
  var isSymbol = isSymbol$3;
  var arraySlice$1 = arraySlice$3;
  var getReplacerFunction = getJsonReplacerFunction;
  var NATIVE_SYMBOL = symbolConstructorDetection;

  var $String = String;
  var $stringify = getBuiltIn('JSON', 'stringify');
  var exec = uncurryThis(/./.exec);
  var charAt = uncurryThis(''.charAt);
  var charCodeAt = uncurryThis(''.charCodeAt);
  var replace = uncurryThis(''.replace);
  var numberToString = uncurryThis(1.0.toString);

  var tester = /[\uD800-\uDFFF]/g;
  var low = /^[\uD800-\uDBFF]$/;
  var hi = /^[\uDC00-\uDFFF]$/;

  var WRONG_SYMBOLS_CONVERSION = !NATIVE_SYMBOL || fails$1(function () {
    var symbol = getBuiltIn('Symbol')();
    // MS Edge converts symbol values to JSON as {}
    return $stringify([symbol]) != '[null]'
      // WebKit converts symbol values to JSON as null
      || $stringify({ a: symbol }) != '{}'
      // V8 throws on boxed symbols
      || $stringify(Object(symbol)) != '{}';
  });

  // https://github.com/tc39/proposal-well-formed-stringify
  var ILL_FORMED_UNICODE = fails$1(function () {
    return $stringify('\uDF06\uD834') !== '"\\udf06\\ud834"'
      || $stringify('\uDEAD') !== '"\\udead"';
  });

  var stringifyWithSymbolsFix = function (it, replacer) {
    var args = arraySlice$1(arguments);
    var $replacer = getReplacerFunction(replacer);
    if (!isCallable($replacer) && (it === undefined || isSymbol(it))) return; // IE8 returns string on undefined
    args[1] = function (key, value) {
      // some old implementations (like WebKit) could pass numbers as keys
      if (isCallable($replacer)) value = call$1($replacer, this, $String(key), value);
      if (!isSymbol(value)) return value;
    };
    return apply($stringify, null, args);
  };

  var fixIllFormed = function (match, offset, string) {
    var prev = charAt(string, offset - 1);
    var next = charAt(string, offset + 1);
    if ((exec(low, match) && !exec(hi, next)) || (exec(hi, match) && !exec(low, prev))) {
      return '\\u' + numberToString(charCodeAt(match, 0), 16);
    } return match;
  };

  if ($stringify) {
    // `JSON.stringify` method
    // https://tc39.es/ecma262/#sec-json.stringify
    $$1({ target: 'JSON', stat: true, arity: 3, forced: WRONG_SYMBOLS_CONVERSION || ILL_FORMED_UNICODE }, {
      // eslint-disable-next-line no-unused-vars -- required for `.length`
      stringify: function stringify(it, replacer, space) {
        var args = arraySlice$1(arguments);
        var result = apply(WRONG_SYMBOLS_CONVERSION ? stringifyWithSymbolsFix : $stringify, null, args);
        return ILL_FORMED_UNICODE && typeof result == 'string' ? replace(result, tester, fixIllFormed) : result;
      }
    });
  }

  var objectGetOwnPropertyNamesExternal = {};

  var toAbsoluteIndex = toAbsoluteIndex$3;
  var lengthOfArrayLike = lengthOfArrayLike$6;
  var createProperty = createProperty$3;

  var $Array = Array;
  var max = Math.max;

  var arraySliceSimple = function (O, start, end) {
    var length = lengthOfArrayLike(O);
    var k = toAbsoluteIndex(start, length);
    var fin = toAbsoluteIndex(end === undefined ? length : end, length);
    var result = $Array(max(fin - k, 0));
    for (var n = 0; k < fin; k++, n++) createProperty(result, n, O[k]);
    result.length = n;
    return result;
  };

  /* eslint-disable es/no-object-getownpropertynames -- safe */

  var classof = classofRaw$2;
  var toIndexedObject = toIndexedObject$7;
  var $getOwnPropertyNames = objectGetOwnPropertyNames.f;
  var arraySlice = arraySliceSimple;

  var windowNames = typeof window == 'object' && window && Object.getOwnPropertyNames
    ? Object.getOwnPropertyNames(window) : [];

  var getWindowNames = function (it) {
    try {
      return $getOwnPropertyNames(it);
    } catch (error) {
      return arraySlice(windowNames);
    }
  };

  // fallback for IE11 buggy Object.getOwnPropertyNames with iframe and window
  objectGetOwnPropertyNamesExternal.f = function getOwnPropertyNames(it) {
    return windowNames && classof(it) == 'Window'
      ? getWindowNames(it)
      : $getOwnPropertyNames(toIndexedObject(it));
  };

  var $ = _export;
  var fails = fails$n;
  var getOwnPropertyNames = objectGetOwnPropertyNamesExternal.f;

  // eslint-disable-next-line es/no-object-getownpropertynames -- required for testing
  var FAILS_ON_PRIMITIVES = fails(function () { return !Object.getOwnPropertyNames(1); });

  // `Object.getOwnPropertyNames` method
  // https://tc39.es/ecma262/#sec-object.getownpropertynames
  $({ target: 'Object', stat: true, forced: FAILS_ON_PRIMITIVES }, {
    getOwnPropertyNames: getOwnPropertyNames
  });

  // `SameValue` abstract operation
  // https://tc39.es/ecma262/#sec-samevalue
  // eslint-disable-next-line es/no-object-is -- safe
  var sameValue$1 = Object.is || function is(x, y) {
    // eslint-disable-next-line no-self-compare -- NaN check
    return x === y ? x !== 0 || 1 / x === 1 / y : x != x && y != y;
  };

  var call = functionCall;
  var fixRegExpWellKnownSymbolLogic = fixRegexpWellKnownSymbolLogic;
  var anObject = anObject$e;
  var isNullOrUndefined = isNullOrUndefined$6;
  var requireObjectCoercible = requireObjectCoercible$8;
  var sameValue = sameValue$1;
  var toString = toString$b;
  var getMethod = getMethod$5;
  var regExpExec = regexpExecAbstract;

  // @@search logic
  fixRegExpWellKnownSymbolLogic('search', function (SEARCH, nativeSearch, maybeCallNative) {
    return [
      // `String.prototype.search` method
      // https://tc39.es/ecma262/#sec-string.prototype.search
      function search(regexp) {
        var O = requireObjectCoercible(this);
        var searcher = isNullOrUndefined(regexp) ? undefined : getMethod(regexp, SEARCH);
        return searcher ? call(searcher, regexp, O) : new RegExp(regexp)[SEARCH](toString(O));
      },
      // `RegExp.prototype[@@search]` method
      // https://tc39.es/ecma262/#sec-regexp.prototype-@@search
      function (string) {
        var rx = anObject(this);
        var S = toString(string);
        var res = maybeCallNative(nativeSearch, rx, S);

        if (res.done) return res.value;

        var previousLastIndex = rx.lastIndex;
        if (!sameValue(previousLastIndex, 0)) rx.lastIndex = 0;
        var result = regExpExec(rx, S);
        if (!sameValue(rx.lastIndex, previousLastIndex)) rx.lastIndex = previousLastIndex;
        return result === null ? -1 : result.index;
      }
    ];
  });

  /*!
   * html2canvas 1.4.1 <https://html2canvas.hertzen.com>
   * Copyright (c) 2022 Niklas von Hertzen <https://hertzen.com>
   * Released under MIT License
   */
  /*! *****************************************************************************
  Copyright (c) Microsoft Corporation.

  Permission to use, copy, modify, and/or distribute this software for any
  purpose with or without fee is hereby granted.

  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
  REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
  AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
  INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
  LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
  OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
  PERFORMANCE OF THIS SOFTWARE.
  ***************************************************************************** */
  /* global Reflect, Promise */

  var extendStatics = function(d, b) {
      extendStatics = Object.setPrototypeOf ||
          ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
          function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
      return extendStatics(d, b);
  };

  function __extends(d, b) {
      if (typeof b !== "function" && b !== null)
          throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
      extendStatics(d, b);
      function __() { this.constructor = d; }
      d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  }

  function __awaiter(thisArg, _arguments, P, generator) {
      function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
      return new (P || (P = Promise))(function (resolve, reject) {
          function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
          function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
          function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
          step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
  }

  function __generator(thisArg, body) {
      var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
      return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
      function verb(n) { return function (v) { return step([n, v]); }; }
      function step(op) {
          if (f) throw new TypeError("Generator is already executing.");
          while (_) try {
              if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
              if (y = 0, t) op = [op[0] & 2, t.value];
              switch (op[0]) {
                  case 0: case 1: t = op; break;
                  case 4: _.label++; return { value: op[1], done: false };
                  case 5: _.label++; y = op[1]; op = [0]; continue;
                  case 7: op = _.ops.pop(); _.trys.pop(); continue;
                  default:
                      if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                      if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                      if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                      if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                      if (t[2]) _.ops.pop();
                      _.trys.pop(); continue;
              }
              op = body.call(thisArg, _);
          } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
          if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
      }
  }

  var Bounds = /** @class */ (function () {
      function Bounds(left, top, width, height) {
          this.left = left;
          this.top = top;
          this.width = width;
          this.height = height;
      }
      Bounds.prototype.add = function (x, y, w, h) {
          return new Bounds(this.left + x, this.top + y, this.width + w, this.height + h);
      };
      Bounds.fromClientRect = function (context, clientRect) {
          return new Bounds(clientRect.left + context.windowBounds.left, clientRect.top + context.windowBounds.top, clientRect.width, clientRect.height);
      };
      Bounds.fromDOMRectList = function (context, domRectList) {
          var domRect = Array.from(domRectList).find(function (rect) { return rect.width !== 0; });
          return domRect
              ? new Bounds(domRect.left + context.windowBounds.left, domRect.top + context.windowBounds.top, domRect.width, domRect.height)
              : Bounds.EMPTY;
      };
      Bounds.EMPTY = new Bounds(0, 0, 0, 0);
      return Bounds;
  }());
  var parseBounds = function (context, node) {
      return Bounds.fromClientRect(context, node.getBoundingClientRect());
  };

  /*
   * css-line-break 2.1.0 <https://github.com/niklasvh/css-line-break#readme>
   * Copyright (c) 2022 Niklas von Hertzen <https://hertzen.com>
   * Released under MIT License
   */
  var toCodePoints$1 = function (str) {
      var codePoints = [];
      var i = 0;
      var length = str.length;
      while (i < length) {
          var value = str.charCodeAt(i++);
          if (value >= 0xd800 && value <= 0xdbff && i < length) {
              var extra = str.charCodeAt(i++);
              if ((extra & 0xfc00) === 0xdc00) {
                  codePoints.push(((value & 0x3ff) << 10) + (extra & 0x3ff) + 0x10000);
              }
              else {
                  codePoints.push(value);
                  i--;
              }
          }
          else {
              codePoints.push(value);
          }
      }
      return codePoints;
  };
  var fromCodePoint$1 = function () {
      var codePoints = [];
      for (var _i = 0; _i < arguments.length; _i++) {
          codePoints[_i] = arguments[_i];
      }
      if (String.fromCodePoint) {
          return String.fromCodePoint.apply(String, codePoints);
      }
      var length = codePoints.length;
      if (!length) {
          return '';
      }
      var codeUnits = [];
      var index = -1;
      var result = '';
      while (++index < length) {
          var codePoint = codePoints[index];
          if (codePoint <= 0xffff) {
              codeUnits.push(codePoint);
          }
          else {
              codePoint -= 0x10000;
              codeUnits.push((codePoint >> 10) + 0xd800, (codePoint % 0x400) + 0xdc00);
          }
          if (index + 1 === length || codeUnits.length > 0x4000) {
              result += String.fromCharCode.apply(String, codeUnits);
              codeUnits.length = 0;
          }
      }
      return result;
  };
  var chars$2 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  // Use a lookup table to find the index.
  var lookup$2 = typeof Uint8Array === 'undefined' ? [] : new Uint8Array(256);
  for (var i$2 = 0; i$2 < chars$2.length; i$2++) {
      lookup$2[chars$2.charCodeAt(i$2)] = i$2;
  }

  /*
   * utrie 1.0.2 <https://github.com/niklasvh/utrie>
   * Copyright (c) 2022 Niklas von Hertzen <https://hertzen.com>
   * Released under MIT License
   */
  var chars$1$1 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  // Use a lookup table to find the index.
  var lookup$1$1 = typeof Uint8Array === 'undefined' ? [] : new Uint8Array(256);
  for (var i$1$1 = 0; i$1$1 < chars$1$1.length; i$1$1++) {
      lookup$1$1[chars$1$1.charCodeAt(i$1$1)] = i$1$1;
  }
  var decode$1 = function (base64) {
      var bufferLength = base64.length * 0.75, len = base64.length, i, p = 0, encoded1, encoded2, encoded3, encoded4;
      if (base64[base64.length - 1] === '=') {
          bufferLength--;
          if (base64[base64.length - 2] === '=') {
              bufferLength--;
          }
      }
      var buffer = typeof ArrayBuffer !== 'undefined' &&
          typeof Uint8Array !== 'undefined' &&
          typeof Uint8Array.prototype.slice !== 'undefined'
          ? new ArrayBuffer(bufferLength)
          : new Array(bufferLength);
      var bytes = Array.isArray(buffer) ? buffer : new Uint8Array(buffer);
      for (i = 0; i < len; i += 4) {
          encoded1 = lookup$1$1[base64.charCodeAt(i)];
          encoded2 = lookup$1$1[base64.charCodeAt(i + 1)];
          encoded3 = lookup$1$1[base64.charCodeAt(i + 2)];
          encoded4 = lookup$1$1[base64.charCodeAt(i + 3)];
          bytes[p++] = (encoded1 << 2) | (encoded2 >> 4);
          bytes[p++] = ((encoded2 & 15) << 4) | (encoded3 >> 2);
          bytes[p++] = ((encoded3 & 3) << 6) | (encoded4 & 63);
      }
      return buffer;
  };
  var polyUint16Array$1 = function (buffer) {
      var length = buffer.length;
      var bytes = [];
      for (var i = 0; i < length; i += 2) {
          bytes.push((buffer[i + 1] << 8) | buffer[i]);
      }
      return bytes;
  };
  var polyUint32Array$1 = function (buffer) {
      var length = buffer.length;
      var bytes = [];
      for (var i = 0; i < length; i += 4) {
          bytes.push((buffer[i + 3] << 24) | (buffer[i + 2] << 16) | (buffer[i + 1] << 8) | buffer[i]);
      }
      return bytes;
  };

  /** Shift size for getting the index-2 table offset. */
  var UTRIE2_SHIFT_2$1 = 5;
  /** Shift size for getting the index-1 table offset. */
  var UTRIE2_SHIFT_1$1 = 6 + 5;
  /**
   * Shift size for shifting left the index array values.
   * Increases possible data size with 16-bit index values at the cost
   * of compactability.
   * This requires data blocks to be aligned by UTRIE2_DATA_GRANULARITY.
   */
  var UTRIE2_INDEX_SHIFT$1 = 2;
  /**
   * Difference between the two shift sizes,
   * for getting an index-1 offset from an index-2 offset. 6=11-5
   */
  var UTRIE2_SHIFT_1_2$1 = UTRIE2_SHIFT_1$1 - UTRIE2_SHIFT_2$1;
  /**
   * The part of the index-2 table for U+D800..U+DBFF stores values for
   * lead surrogate code _units_ not code _points_.
   * Values for lead surrogate code _points_ are indexed with this portion of the table.
   * Length=32=0x20=0x400>>UTRIE2_SHIFT_2. (There are 1024=0x400 lead surrogates.)
   */
  var UTRIE2_LSCP_INDEX_2_OFFSET$1 = 0x10000 >> UTRIE2_SHIFT_2$1;
  /** Number of entries in a data block. 32=0x20 */
  var UTRIE2_DATA_BLOCK_LENGTH$1 = 1 << UTRIE2_SHIFT_2$1;
  /** Mask for getting the lower bits for the in-data-block offset. */
  var UTRIE2_DATA_MASK$1 = UTRIE2_DATA_BLOCK_LENGTH$1 - 1;
  var UTRIE2_LSCP_INDEX_2_LENGTH$1 = 0x400 >> UTRIE2_SHIFT_2$1;
  /** Count the lengths of both BMP pieces. 2080=0x820 */
  var UTRIE2_INDEX_2_BMP_LENGTH$1 = UTRIE2_LSCP_INDEX_2_OFFSET$1 + UTRIE2_LSCP_INDEX_2_LENGTH$1;
  /**
   * The 2-byte UTF-8 version of the index-2 table follows at offset 2080=0x820.
   * Length 32=0x20 for lead bytes C0..DF, regardless of UTRIE2_SHIFT_2.
   */
  var UTRIE2_UTF8_2B_INDEX_2_OFFSET$1 = UTRIE2_INDEX_2_BMP_LENGTH$1;
  var UTRIE2_UTF8_2B_INDEX_2_LENGTH$1 = 0x800 >> 6; /* U+0800 is the first code point after 2-byte UTF-8 */
  /**
   * The index-1 table, only used for supplementary code points, at offset 2112=0x840.
   * Variable length, for code points up to highStart, where the last single-value range starts.
   * Maximum length 512=0x200=0x100000>>UTRIE2_SHIFT_1.
   * (For 0x100000 supplementary code points U+10000..U+10ffff.)
   *
   * The part of the index-2 table for supplementary code points starts
   * after this index-1 table.
   *
   * Both the index-1 table and the following part of the index-2 table
   * are omitted completely if there is only BMP data.
   */
  var UTRIE2_INDEX_1_OFFSET$1 = UTRIE2_UTF8_2B_INDEX_2_OFFSET$1 + UTRIE2_UTF8_2B_INDEX_2_LENGTH$1;
  /**
   * Number of index-1 entries for the BMP. 32=0x20
   * This part of the index-1 table is omitted from the serialized form.
   */
  var UTRIE2_OMITTED_BMP_INDEX_1_LENGTH$1 = 0x10000 >> UTRIE2_SHIFT_1$1;
  /** Number of entries in an index-2 block. 64=0x40 */
  var UTRIE2_INDEX_2_BLOCK_LENGTH$1 = 1 << UTRIE2_SHIFT_1_2$1;
  /** Mask for getting the lower bits for the in-index-2-block offset. */
  var UTRIE2_INDEX_2_MASK$1 = UTRIE2_INDEX_2_BLOCK_LENGTH$1 - 1;
  var slice16$1 = function (view, start, end) {
      if (view.slice) {
          return view.slice(start, end);
      }
      return new Uint16Array(Array.prototype.slice.call(view, start, end));
  };
  var slice32$1 = function (view, start, end) {
      if (view.slice) {
          return view.slice(start, end);
      }
      return new Uint32Array(Array.prototype.slice.call(view, start, end));
  };
  var createTrieFromBase64$1 = function (base64, _byteLength) {
      var buffer = decode$1(base64);
      var view32 = Array.isArray(buffer) ? polyUint32Array$1(buffer) : new Uint32Array(buffer);
      var view16 = Array.isArray(buffer) ? polyUint16Array$1(buffer) : new Uint16Array(buffer);
      var headerLength = 24;
      var index = slice16$1(view16, headerLength / 2, view32[4] / 2);
      var data = view32[5] === 2
          ? slice16$1(view16, (headerLength + view32[4]) / 2)
          : slice32$1(view32, Math.ceil((headerLength + view32[4]) / 4));
      return new Trie$1(view32[0], view32[1], view32[2], view32[3], index, data);
  };
  var Trie$1 = /** @class */ (function () {
      function Trie(initialValue, errorValue, highStart, highValueIndex, index, data) {
          this.initialValue = initialValue;
          this.errorValue = errorValue;
          this.highStart = highStart;
          this.highValueIndex = highValueIndex;
          this.index = index;
          this.data = data;
      }
      /**
       * Get the value for a code point as stored in the Trie.
       *
       * @param codePoint the code point
       * @return the value
       */
      Trie.prototype.get = function (codePoint) {
          var ix;
          if (codePoint >= 0) {
              if (codePoint < 0x0d800 || (codePoint > 0x0dbff && codePoint <= 0x0ffff)) {
                  // Ordinary BMP code point, excluding leading surrogates.
                  // BMP uses a single level lookup.  BMP index starts at offset 0 in the Trie2 index.
                  // 16 bit data is stored in the index array itself.
                  ix = this.index[codePoint >> UTRIE2_SHIFT_2$1];
                  ix = (ix << UTRIE2_INDEX_SHIFT$1) + (codePoint & UTRIE2_DATA_MASK$1);
                  return this.data[ix];
              }
              if (codePoint <= 0xffff) {
                  // Lead Surrogate Code Point.  A Separate index section is stored for
                  // lead surrogate code units and code points.
                  //   The main index has the code unit data.
                  //   For this function, we need the code point data.
                  // Note: this expression could be refactored for slightly improved efficiency, but
                  //       surrogate code points will be so rare in practice that it's not worth it.
                  ix = this.index[UTRIE2_LSCP_INDEX_2_OFFSET$1 + ((codePoint - 0xd800) >> UTRIE2_SHIFT_2$1)];
                  ix = (ix << UTRIE2_INDEX_SHIFT$1) + (codePoint & UTRIE2_DATA_MASK$1);
                  return this.data[ix];
              }
              if (codePoint < this.highStart) {
                  // Supplemental code point, use two-level lookup.
                  ix = UTRIE2_INDEX_1_OFFSET$1 - UTRIE2_OMITTED_BMP_INDEX_1_LENGTH$1 + (codePoint >> UTRIE2_SHIFT_1$1);
                  ix = this.index[ix];
                  ix += (codePoint >> UTRIE2_SHIFT_2$1) & UTRIE2_INDEX_2_MASK$1;
                  ix = this.index[ix];
                  ix = (ix << UTRIE2_INDEX_SHIFT$1) + (codePoint & UTRIE2_DATA_MASK$1);
                  return this.data[ix];
              }
              if (codePoint <= 0x10ffff) {
                  return this.data[this.highValueIndex];
              }
          }
          // Fall through.  The code point is outside of the legal range of 0..0x10ffff.
          return this.errorValue;
      };
      return Trie;
  }());

  /*
   * base64-arraybuffer 1.0.2 <https://github.com/niklasvh/base64-arraybuffer>
   * Copyright (c) 2022 Niklas von Hertzen <https://hertzen.com>
   * Released under MIT License
   */
  var chars$3 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  // Use a lookup table to find the index.
  var lookup$3 = typeof Uint8Array === 'undefined' ? [] : new Uint8Array(256);
  for (var i$3 = 0; i$3 < chars$3.length; i$3++) {
      lookup$3[chars$3.charCodeAt(i$3)] = i$3;
  }

  var base64$1 = 'KwAAAAAAAAAACA4AUD0AADAgAAACAAAAAAAIABAAGABAAEgAUABYAGAAaABgAGgAYgBqAF8AZwBgAGgAcQB5AHUAfQCFAI0AlQCdAKIAqgCyALoAYABoAGAAaABgAGgAwgDKAGAAaADGAM4A0wDbAOEA6QDxAPkAAQEJAQ8BFwF1AH0AHAEkASwBNAE6AUIBQQFJAVEBWQFhAWgBcAF4ATAAgAGGAY4BlQGXAZ8BpwGvAbUBvQHFAc0B0wHbAeMB6wHxAfkBAQIJAvEBEQIZAiECKQIxAjgCQAJGAk4CVgJeAmQCbAJ0AnwCgQKJApECmQKgAqgCsAK4ArwCxAIwAMwC0wLbAjAA4wLrAvMC+AIAAwcDDwMwABcDHQMlAy0DNQN1AD0DQQNJA0kDSQNRA1EDVwNZA1kDdQB1AGEDdQBpA20DdQN1AHsDdQCBA4kDkQN1AHUAmQOhA3UAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AKYDrgN1AHUAtgO+A8YDzgPWAxcD3gPjA+sD8wN1AHUA+wMDBAkEdQANBBUEHQQlBCoEFwMyBDgEYABABBcDSARQBFgEYARoBDAAcAQzAXgEgASIBJAEdQCXBHUAnwSnBK4EtgS6BMIEyAR1AHUAdQB1AHUAdQCVANAEYABgAGAAYABgAGAAYABgANgEYADcBOQEYADsBPQE/AQEBQwFFAUcBSQFLAU0BWQEPAVEBUsFUwVbBWAAYgVgAGoFcgV6BYIFigWRBWAAmQWfBaYFYABgAGAAYABgAKoFYACxBbAFuQW6BcEFwQXHBcEFwQXPBdMF2wXjBeoF8gX6BQIGCgYSBhoGIgYqBjIGOgZgAD4GRgZMBmAAUwZaBmAAYABgAGAAYABgAGAAYABgAGAAYABgAGIGYABpBnAGYABgAGAAYABgAGAAYABgAGAAYAB4Bn8GhQZgAGAAYAB1AHcDFQSLBmAAYABgAJMGdQA9A3UAmwajBqsGqwaVALMGuwbDBjAAywbSBtIG1QbSBtIG0gbSBtIG0gbdBuMG6wbzBvsGAwcLBxMHAwcbByMHJwcsBywHMQcsB9IGOAdAB0gHTgfSBkgHVgfSBtIG0gbSBtIG0gbSBtIG0gbSBiwHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAdgAGAALAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAdbB2MHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsB2kH0gZwB64EdQB1AHUAdQB1AHUAdQB1AHUHfQdgAIUHjQd1AHUAlQedB2AAYAClB6sHYACzB7YHvgfGB3UAzgfWBzMB3gfmB1EB7gf1B/0HlQENAQUIDQh1ABUIHQglCBcDLQg1CD0IRQhNCEEDUwh1AHUAdQBbCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIcAh3CHoIMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwAIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIgggwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAALAcsBywHLAcsBywHLAcsBywHLAcsB4oILAcsB44I0gaWCJ4Ipgh1AHUAqgiyCHUAdQB1AHUAdQB1AHUAdQB1AHUAtwh8AXUAvwh1AMUIyQjRCNkI4AjoCHUAdQB1AO4I9gj+CAYJDgkTCS0HGwkjCYIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiAAIAAAAFAAYABgAGIAXwBgAHEAdQBFAJUAogCyAKAAYABgAEIA4ABGANMA4QDxAMEBDwE1AFwBLAE6AQEBUQF4QkhCmEKoQrhCgAHIQsAB0MLAAcABwAHAAeDC6ABoAHDCwMMAAcABwAHAAdDDGMMAAcAB6MM4wwjDWMNow3jDaABoAGgAaABoAGgAaABoAGgAaABoAGgAaABoAGgAaABoAGgAaABoAEjDqABWw6bDqABpg6gAaABoAHcDvwOPA+gAaABfA/8DvwO/A78DvwO/A78DvwO/A78DvwO/A78DvwO/A78DvwO/A78DvwO/A78DvwO/A78DvwO/A78DpcPAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcAB9cPKwkyCToJMAB1AHUAdQBCCUoJTQl1AFUJXAljCWcJawkwADAAMAAwAHMJdQB2CX4JdQCECYoJjgmWCXUAngkwAGAAYABxAHUApgn3A64JtAl1ALkJdQDACTAAMAAwADAAdQB1AHUAdQB1AHUAdQB1AHUAowYNBMUIMAAwADAAMADICcsJ0wnZCRUE4QkwAOkJ8An4CTAAMAB1AAAKvwh1AAgKDwoXCh8KdQAwACcKLgp1ADYKqAmICT4KRgowADAAdQB1AE4KMAB1AFYKdQBeCnUAZQowADAAMAAwADAAMAAwADAAMAAVBHUAbQowADAAdQC5CXUKMAAwAHwBxAijBogEMgF9CoQKiASMCpQKmgqIBKIKqgquCogEDQG2Cr4KxgrLCjAAMADTCtsKCgHjCusK8Qr5CgELMAAwADAAMAB1AIsECQsRC3UANAEZCzAAMAAwADAAMAB1ACELKQswAHUANAExCzkLdQBBC0kLMABRC1kLMAAwADAAMAAwADAAdQBhCzAAMAAwAGAAYABpC3ELdwt/CzAAMACHC4sLkwubC58Lpwt1AK4Ltgt1APsDMAAwADAAMAAwADAAMAAwAL4LwwvLC9IL1wvdCzAAMADlC+kL8Qv5C/8LSQswADAAMAAwADAAMAAwADAAMAAHDDAAMAAwADAAMAAODBYMHgx1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1ACYMMAAwADAAdQB1AHUALgx1AHUAdQB1AHUAdQA2DDAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwAHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AD4MdQBGDHUAdQB1AHUAdQB1AEkMdQB1AHUAdQB1AFAMMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwAHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQBYDHUAdQB1AF8MMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUA+wMVBGcMMAAwAHwBbwx1AHcMfwyHDI8MMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAYABgAJcMMAAwADAAdQB1AJ8MlQClDDAAMACtDCwHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsB7UMLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AA0EMAC9DDAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAsBywHLAcsBywHLAcsBywHLQcwAMEMyAwsBywHLAcsBywHLAcsBywHLAcsBywHzAwwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwAHUAdQB1ANQM2QzhDDAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMABgAGAAYABgAGAAYABgAOkMYADxDGAA+AwADQYNYABhCWAAYAAODTAAMAAwADAAFg1gAGAAHg37AzAAMAAwADAAYABgACYNYAAsDTQNPA1gAEMNPg1LDWAAYABgAGAAYABgAGAAYABgAGAAUg1aDYsGVglhDV0NcQBnDW0NdQ15DWAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAlQCBDZUAiA2PDZcNMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAnw2nDTAAMAAwADAAMAAwAHUArw23DTAAMAAwADAAMAAwADAAMAAwADAAMAB1AL8NMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAB1AHUAdQB1AHUAdQDHDTAAYABgAM8NMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAA1w11ANwNMAAwAD0B5A0wADAAMAAwADAAMADsDfQN/A0EDgwOFA4wABsOMAAwADAAMAAwADAAMAAwANIG0gbSBtIG0gbSBtIG0gYjDigOwQUuDsEFMw7SBjoO0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIGQg5KDlIOVg7SBtIGXg5lDm0OdQ7SBtIGfQ6EDooOjQ6UDtIGmg6hDtIG0gaoDqwO0ga0DrwO0gZgAGAAYADEDmAAYAAkBtIGzA5gANIOYADaDokO0gbSBt8O5w7SBu8O0gb1DvwO0gZgAGAAxA7SBtIG0gbSBtIGYABgAGAAYAAED2AAsAUMD9IG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIGFA8sBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAccD9IGLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHJA8sBywHLAcsBywHLAccDywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywPLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAc0D9IG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIGLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAccD9IG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIGFA8sBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHPA/SBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gYUD0QPlQCVAJUAMAAwADAAMACVAJUAlQCVAJUAlQCVAEwPMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAA//8EAAQABAAEAAQABAAEAAQABAANAAMAAQABAAIABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQACgATABcAHgAbABoAHgAXABYAEgAeABsAGAAPABgAHABLAEsASwBLAEsASwBLAEsASwBLABgAGAAeAB4AHgATAB4AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQABYAGwASAB4AHgAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAWAA0AEQAeAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAAQABAAEAAQABAAFAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAJABYAGgAbABsAGwAeAB0AHQAeAE8AFwAeAA0AHgAeABoAGwBPAE8ADgBQAB0AHQAdAE8ATwAXAE8ATwBPABYAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAFAAUABQAFAAUABQAFAAUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAeAB4AHgAeAFAATwBAAE8ATwBPAEAATwBQAFAATwBQAB4AHgAeAB4AHgAeAB0AHQAdAB0AHgAdAB4ADgBQAFAAUABQAFAAHgAeAB4AHgAeAB4AHgBQAB4AUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAJAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAkACQAJAAkACQAJAAkABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAeAB4AHgAeAFAAHgAeAB4AKwArAFAAUABQAFAAGABQACsAKwArACsAHgAeAFAAHgBQAFAAUAArAFAAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAEAAQABAAEAAQABAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAUAAeAB4AHgAeAB4AHgBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAYAA0AKwArAB4AHgAbACsABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQADQAEAB4ABAAEAB4ABAAEABMABAArACsAKwArACsAKwArACsAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAKwArACsAKwBWAFYAVgBWAB4AHgArACsAKwArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AGgAaABoAGAAYAB4AHgAEAAQABAAEAAQABAAEAAQABAAEAAQAEwAEACsAEwATAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABABLAEsASwBLAEsASwBLAEsASwBLABoAGQAZAB4AUABQAAQAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQABMAUAAEAAQABAAEAAQABAAEAB4AHgAEAAQABAAEAAQABABQAFAABAAEAB4ABAAEAAQABABQAFAASwBLAEsASwBLAEsASwBLAEsASwBQAFAAUAAeAB4AUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwAeAFAABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAFAAKwArACsAKwArACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQAUABQAB4AHgAYABMAUAArACsABAAbABsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAFAABAAEAAQABAAEAFAABAAEAAQAUAAEAAQABAAEAAQAKwArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAArACsAHgArAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwArACsAKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAB4ABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAUAAEAAQABAAEAAQABAAEAFAAUABQAFAAUABQAFAAUABQAFAABAAEAA0ADQBLAEsASwBLAEsASwBLAEsASwBLAB4AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAArAFAAUABQAFAAUABQAFAAUAArACsAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUAArACsAKwBQAFAAUABQACsAKwAEAFAABAAEAAQABAAEAAQABAArACsABAAEACsAKwAEAAQABABQACsAKwArACsAKwArACsAKwAEACsAKwArACsAUABQACsAUABQAFAABAAEACsAKwBLAEsASwBLAEsASwBLAEsASwBLAFAAUAAaABoAUABQAFAAUABQAEwAHgAbAFAAHgAEACsAKwAEAAQABAArAFAAUABQAFAAUABQACsAKwArACsAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUABQACsAUABQACsAUABQACsAKwAEACsABAAEAAQABAAEACsAKwArACsABAAEACsAKwAEAAQABAArACsAKwAEACsAKwArACsAKwArACsAUABQAFAAUAArAFAAKwArACsAKwArACsAKwBLAEsASwBLAEsASwBLAEsASwBLAAQABABQAFAAUAAEAB4AKwArACsAKwArACsAKwArACsAKwAEAAQABAArAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUABQACsAUABQAFAAUABQACsAKwAEAFAABAAEAAQABAAEAAQABAAEACsABAAEAAQAKwAEAAQABAArACsAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAABAAEACsAKwBLAEsASwBLAEsASwBLAEsASwBLAB4AGwArACsAKwArACsAKwArAFAABAAEAAQABAAEAAQAKwAEAAQABAArAFAAUABQAFAAUABQAFAAUAArACsAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAArACsABAAEACsAKwAEAAQABAArACsAKwArACsAKwArAAQABAAEACsAKwArACsAUABQACsAUABQAFAABAAEACsAKwBLAEsASwBLAEsASwBLAEsASwBLAB4AUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArAAQAUAArAFAAUABQAFAAUABQACsAKwArAFAAUABQACsAUABQAFAAUAArACsAKwBQAFAAKwBQACsAUABQACsAKwArAFAAUAArACsAKwBQAFAAUAArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArAAQABAAEAAQABAArACsAKwAEAAQABAArAAQABAAEAAQAKwArAFAAKwArACsAKwArACsABAArACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAUABQAFAAHgAeAB4AHgAeAB4AGwAeACsAKwArACsAKwAEAAQABAAEAAQAUABQAFAAUABQAFAAUABQACsAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAUAAEAAQABAAEAAQABAAEACsABAAEAAQAKwAEAAQABAAEACsAKwArACsAKwArACsABAAEACsAUABQAFAAKwArACsAKwArAFAAUAAEAAQAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAKwAOAFAAUABQAFAAUABQAFAAHgBQAAQABAAEAA4AUABQAFAAUABQAFAAUABQACsAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAKwArAAQAUAAEAAQABAAEAAQABAAEACsABAAEAAQAKwAEAAQABAAEACsAKwArACsAKwArACsABAAEACsAKwArACsAKwArACsAUAArAFAAUAAEAAQAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwBQAFAAKwArACsAKwArACsAKwArACsAKwArACsAKwAEAAQABAAEAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAFAABAAEAAQABAAEAAQABAArAAQABAAEACsABAAEAAQABABQAB4AKwArACsAKwBQAFAAUAAEAFAAUABQAFAAUABQAFAAUABQAFAABAAEACsAKwBLAEsASwBLAEsASwBLAEsASwBLAFAAUABQAFAAUABQAFAAUABQABoAUABQAFAAUABQAFAAKwAEAAQABAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQACsAUAArACsAUABQAFAAUABQAFAAUAArACsAKwAEACsAKwArACsABAAEAAQABAAEAAQAKwAEACsABAAEAAQABAAEAAQABAAEACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArAAQABAAeACsAKwArACsAKwArACsAKwArACsAKwArAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXAAqAFwAXAAqACoAKgAqACoAKgAqACsAKwArACsAGwBcAFwAXABcAFwAXABcACoAKgAqACoAKgAqACoAKgAeAEsASwBLAEsASwBLAEsASwBLAEsADQANACsAKwArACsAKwBcAFwAKwBcACsAXABcAFwAXABcACsAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcACsAXAArAFwAXABcAFwAXABcAFwAXABcAFwAKgBcAFwAKgAqACoAKgAqACoAKgAqACoAXAArACsAXABcAFwAXABcACsAXAArACoAKgAqACoAKgAqACsAKwBLAEsASwBLAEsASwBLAEsASwBLACsAKwBcAFwAXABcAFAADgAOAA4ADgAeAA4ADgAJAA4ADgANAAkAEwATABMAEwATAAkAHgATAB4AHgAeAAQABAAeAB4AHgAeAB4AHgBLAEsASwBLAEsASwBLAEsASwBLAFAAUABQAFAAUABQAFAAUABQAFAADQAEAB4ABAAeAAQAFgARABYAEQAEAAQAUABQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQADQAEAAQABAAEAAQADQAEAAQAUABQAFAAUABQAAQABAAEAAQABAAEAAQABAAEAAQABAArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAArAA0ADQAeAB4AHgAeAB4AHgAEAB4AHgAeAB4AHgAeACsAHgAeAA4ADgANAA4AHgAeAB4AHgAeAAkACQArACsAKwArACsAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgBcAEsASwBLAEsASwBLAEsASwBLAEsADQANAB4AHgAeAB4AXABcAFwAXABcAFwAKgAqACoAKgBcAFwAXABcACoAKgAqAFwAKgAqACoAXABcACoAKgAqACoAKgAqACoAXABcAFwAKgAqACoAKgBcAFwAXABcAFwAXABcAFwAXABcAFwAXABcACoAKgAqACoAKgAqACoAKgAqACoAKgAqAFwAKgBLAEsASwBLAEsASwBLAEsASwBLACoAKgAqACoAKgAqAFAAUABQAFAAUABQACsAUAArACsAKwArACsAUAArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgBQAFAAUABQAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAUAArACsAUABQAFAAUABQAFAAUAArAFAAKwBQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAKwArAFAAUABQAFAAUABQAFAAKwBQACsAUABQAFAAUAArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsABAAEAAQAHgANAB4AHgAeAB4AHgAeAB4AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUAArACsADQBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAANAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAWABEAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAA0ADQANAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAAQABAAEACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAANAA0AKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUAArAAQABAArACsAKwArACsAKwArACsAKwArACsAKwBcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqAA0ADQAVAFwADQAeAA0AGwBcACoAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwAeAB4AEwATAA0ADQAOAB4AEwATAB4ABAAEAAQACQArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAFAAUABQAFAAUAAEAAQAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQAUAArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAArACsAKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArACsAHgArACsAKwATABMASwBLAEsASwBLAEsASwBLAEsASwBcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXAArACsAXABcAFwAXABcACsAKwArACsAKwArACsAKwArACsAKwBcAFwAXABcAFwAXABcAFwAXABcAFwAXAArACsAKwArAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAXAArACsAKwAqACoAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAArACsAHgAeAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcACoAKgAqACoAKgAqACoAKgAqACoAKwAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKwArAAQASwBLAEsASwBLAEsASwBLAEsASwArACsAKwArACsAKwBLAEsASwBLAEsASwBLAEsASwBLACsAKwArACsAKwArACoAKgAqACoAKgAqACoAXAAqACoAKgAqACoAKgArACsABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsABAAEAAQABAAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABABQAFAAUABQAFAAUABQACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwANAA0AHgANAA0ADQANAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAEAAQABAAEAAQABAAEAAQAHgAeAB4AHgAeAB4AHgAeAB4AKwArACsABAAEAAQAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABABQAFAASwBLAEsASwBLAEsASwBLAEsASwBQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwAeAB4AHgAeAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArAA0ADQANAA0ADQBLAEsASwBLAEsASwBLAEsASwBLACsAKwArAFAAUABQAEsASwBLAEsASwBLAEsASwBLAEsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAA0ADQBQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUAAeAB4AHgAeAB4AHgAeAB4AKwArACsAKwArACsAKwArAAQABAAEAB4ABAAEAAQABAAEAAQABAAEAAQABAAEAAQABABQAFAAUABQAAQAUABQAFAAUABQAFAABABQAFAABAAEAAQAUAArACsAKwArACsABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsABAAEAAQABAAEAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwArAFAAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAKwBQACsAUAArAFAAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACsAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArAB4AHgAeAB4AHgAeAB4AHgBQAB4AHgAeAFAAUABQACsAHgAeAB4AHgAeAB4AHgAeAB4AHgBQAFAAUABQACsAKwAeAB4AHgAeAB4AHgArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwArAFAAUABQACsAHgAeAB4AHgAeAB4AHgAOAB4AKwANAA0ADQANAA0ADQANAAkADQANAA0ACAAEAAsABAAEAA0ACQANAA0ADAAdAB0AHgAXABcAFgAXABcAFwAWABcAHQAdAB4AHgAUABQAFAANAAEAAQAEAAQABAAEAAQACQAaABoAGgAaABoAGgAaABoAHgAXABcAHQAVABUAHgAeAB4AHgAeAB4AGAAWABEAFQAVABUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ADQAeAA0ADQANAA0AHgANAA0ADQAHAB4AHgAeAB4AKwAEAAQABAAEAAQABAAEAAQABAAEAFAAUAArACsATwBQAFAAUABQAFAAHgAeAB4AFgARAE8AUABPAE8ATwBPAFAAUABQAFAAUAAeAB4AHgAWABEAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArABsAGwAbABsAGwAbABsAGgAbABsAGwAbABsAGwAbABsAGwAbABsAGwAbABsAGgAbABsAGwAbABoAGwAbABoAGwAbABsAGwAbABsAGwAbABsAGwAbABsAGwAbABsAGwAbAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAHgAeAFAAGgAeAB0AHgBQAB4AGgAeAB4AHgAeAB4AHgAeAB4AHgBPAB4AUAAbAB4AHgBQAFAAUABQAFAAHgAeAB4AHQAdAB4AUAAeAFAAHgBQAB4AUABPAFAAUAAeAB4AHgAeAB4AHgAeAFAAUABQAFAAUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAFAAHgBQAFAAUABQAE8ATwBQAFAAUABQAFAATwBQAFAATwBQAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAFAAUABQAFAATwBPAE8ATwBPAE8ATwBPAE8ATwBQAFAAUABQAFAAUABQAFAAUAAeAB4AUABQAFAAUABPAB4AHgArACsAKwArAB0AHQAdAB0AHQAdAB0AHQAdAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHgAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB4AHQAdAB4AHgAeAB0AHQAeAB4AHQAeAB4AHgAdAB4AHQAbABsAHgAdAB4AHgAeAB4AHQAeAB4AHQAdAB0AHQAeAB4AHQAeAB0AHgAdAB0AHQAdAB0AHQAeAB0AHgAeAB4AHgAeAB0AHQAdAB0AHgAeAB4AHgAdAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB4AHgAeAB0AHgAeAB4AHgAeAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB0AHgAeAB0AHQAdAB0AHgAeAB0AHQAeAB4AHQAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHQAeAB4AHQAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHQAeAB4AHgAdAB4AHgAeAB4AHgAeAB4AHQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AFAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeABYAEQAWABEAHgAeAB4AHgAeAB4AHQAeAB4AHgAeAB4AHgAeACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAWABEAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAFAAHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHgAeAB4AHgAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAeAB4AHQAdAB0AHQAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHQAeAB0AHQAdAB0AHQAdAB0AHgAeAB4AHgAeAB4AHgAeAB0AHQAeAB4AHQAdAB4AHgAeAB4AHQAdAB4AHgAeAB4AHQAdAB0AHgAeAB0AHgAeAB0AHQAdAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB0AHQAdAB4AHgAeAB4AHgAeAB4AHgAeAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAlACUAJQAlAB4AHQAdAB4AHgAdAB4AHgAeAB4AHQAdAB4AHgAeAB4AJQAlAB0AHQAlAB4AJQAlACUAIAAlACUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAlACUAJQAeAB4AHgAeAB0AHgAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB0AHgAdAB0AHQAeAB0AJQAdAB0AHgAdAB0AHgAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHQAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAlACUAJQAlACUAJQAlACUAJQAlACUAJQAdAB0AHQAdACUAHgAlACUAJQAdACUAJQAdAB0AHQAlACUAHQAdACUAHQAdACUAJQAlAB4AHQAeAB4AHgAeAB0AHQAlAB0AHQAdAB0AHQAdACUAJQAlACUAJQAdACUAJQAgACUAHQAdACUAJQAlACUAJQAlACUAJQAeAB4AHgAlACUAIAAgACAAIAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHgAeAB4AFwAXABcAFwAXABcAHgATABMAJQAeAB4AHgAWABEAFgARABYAEQAWABEAFgARABYAEQAWABEATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeABYAEQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAWABEAFgARABYAEQAWABEAFgARAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AFgARABYAEQAWABEAFgARABYAEQAWABEAFgARABYAEQAWABEAFgARABYAEQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAWABEAFgARAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AFgARAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB0AHQAdAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AUABQAFAAUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAEAAQABAAeAB4AKwArACsAKwArABMADQANAA0AUAATAA0AUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAUAANACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXAA0ADQANAA0ADQANAA0ADQAeAA0AFgANAB4AHgAXABcAHgAeABcAFwAWABEAFgARABYAEQAWABEADQANAA0ADQATAFAADQANAB4ADQANAB4AHgAeAB4AHgAMAAwADQANAA0AHgANAA0AFgANAA0ADQANAA0ADQANAA0AHgANAB4ADQANAB4AHgAeACsAKwArACsAKwArACsAKwArACsAKwArACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAKwArACsAKwArACsAKwArACsAKwArACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAlACUAJQAlACUAJQAlACUAJQAlACUAJQArACsAKwArAA0AEQARACUAJQBHAFcAVwAWABEAFgARABYAEQAWABEAFgARACUAJQAWABEAFgARABYAEQAWABEAFQAWABEAEQAlAFcAVwBXAFcAVwBXAFcAVwBXAAQABAAEAAQABAAEACUAVwBXAFcAVwA2ACUAJQBXAFcAVwBHAEcAJQAlACUAKwBRAFcAUQBXAFEAVwBRAFcAUQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFEAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBRAFcAUQBXAFEAVwBXAFcAVwBXAFcAUQBXAFcAVwBXAFcAVwBRAFEAKwArAAQABAAVABUARwBHAFcAFQBRAFcAUQBXAFEAVwBRAFcAUQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFEAVwBRAFcAUQBXAFcAVwBXAFcAVwBRAFcAVwBXAFcAVwBXAFEAUQBXAFcAVwBXABUAUQBHAEcAVwArACsAKwArACsAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAKwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAKwAlACUAVwBXAFcAVwAlACUAJQAlACUAJQAlACUAJQAlACsAKwArACsAKwArACsAKwArACsAKwArAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQArAFcAVwBXAFcAVwBXAFcAVwBXAFcAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQBPAE8ATwBPAE8ATwBPAE8AJQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACUAJQAlAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAEcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAKwArACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAADQATAA0AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABLAEsASwBLAEsASwBLAEsASwBLAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAFAABAAEAAQABAAeAAQABAAEAAQABAAEAAQABAAEAAQAHgBQAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AUABQAAQABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAeAA0ADQANAA0ADQArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAFAAUABQAFAAUABQAFAAUABQAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAB4AHgAeAB4AHgAeAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAHgAeAB4AHgAeAB4AHgAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAeAB4AUABQAFAAUABQAFAAUABQAFAAUABQAAQAUABQAFAABABQAFAAUABQAAQAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAAeAB4AHgAeAAQAKwArACsAUABQAFAAUABQAFAAHgAeABoAHgArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAADgAOABMAEwArACsAKwArACsAKwArACsABAAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwANAA0ASwBLAEsASwBLAEsASwBLAEsASwArACsAKwArACsAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABABQAFAAUABQAFAAUAAeAB4AHgBQAA4AUABQAAQAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAA0ADQBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwArACsAKwArACsAKwArACsAKwArAB4AWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYACsAKwArAAQAHgAeAB4AHgAeAB4ADQANAA0AHgAeAB4AHgArAFAASwBLAEsASwBLAEsASwBLAEsASwArACsAKwArAB4AHgBcAFwAXABcAFwAKgBcAFwAXABcAFwAXABcAFwAXABcAEsASwBLAEsASwBLAEsASwBLAEsAXABcAFwAXABcACsAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwArAFAAUABQAAQAUABQAFAAUABQAFAAUABQAAQABAArACsASwBLAEsASwBLAEsASwBLAEsASwArACsAHgANAA0ADQBcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAKgAqACoAXAAqACoAKgBcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXAAqAFwAKgAqACoAXABcACoAKgBcAFwAXABcAFwAKgAqAFwAKgBcACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFwAXABcACoAKgBQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAA0ADQBQAFAAUAAEAAQAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUAArACsAUABQAFAAUABQAFAAKwArAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgAeACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQADQAEAAQAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAVABVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBUAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVACsAKwArACsAKwArACsAKwArACsAKwArAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAKwArACsAKwBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAKwArACsAKwAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACUAJQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAJQAlACUAJQAlACUAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAKwArACsAKwArAFYABABWAFYAVgBWAFYAVgBWAFYAVgBWAB4AVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgArAFYAVgBWAFYAVgArAFYAKwBWAFYAKwBWAFYAKwBWAFYAVgBWAFYAVgBWAFYAVgBWAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAEQAWAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUAAaAB4AKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAGAARABEAGAAYABMAEwAWABEAFAArACsAKwArACsAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACUAJQAlACUAJQAWABEAFgARABYAEQAWABEAFgARABYAEQAlACUAFgARACUAJQAlACUAJQAlACUAEQAlABEAKwAVABUAEwATACUAFgARABYAEQAWABEAJQAlACUAJQAlACUAJQAlACsAJQAbABoAJQArACsAKwArAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAAcAKwATACUAJQAbABoAJQAlABYAEQAlACUAEQAlABEAJQBXAFcAVwBXAFcAVwBXAFcAVwBXABUAFQAlACUAJQATACUAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXABYAJQARACUAJQAlAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwAWACUAEQAlABYAEQARABYAEQARABUAVwBRAFEAUQBRAFEAUQBRAFEAUQBRAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAEcARwArACsAVwBXAFcAVwBXAFcAKwArAFcAVwBXAFcAVwBXACsAKwBXAFcAVwBXAFcAVwArACsAVwBXAFcAKwArACsAGgAbACUAJQAlABsAGwArAB4AHgAeAB4AHgAeAB4AKwArACsAKwArACsAKwArACsAKwAEAAQABAAQAB0AKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsADQANAA0AKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArAB4AHgAeAB4AHgAeAB4AHgAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAFAAHgAeAB4AKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAAQAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAA0AUABQAFAAUAArACsAKwArAFAAUABQAFAAUABQAFAAUAANAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwAeACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAKwArAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUAArACsAKwBQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwANAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAeAB4AUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUAArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArAA0AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAUABQAFAAUABQAAQABAAEACsABAAEACsAKwArACsAKwAEAAQABAAEAFAAUABQAFAAKwBQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAAQABAAEACsAKwArACsABABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAA0ADQANAA0ADQANAA0ADQAeACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAeAFAAUABQAFAAUABQAFAAUAAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAArACsAKwArAFAAUABQAFAAUAANAA0ADQANAA0ADQAUACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsADQANAA0ADQANAA0ADQBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAB4AHgAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAFAAUABQAFAAUABQAAQABAAEAAQAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUAArAAQABAANACsAKwBQAFAAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAAQABAAEAAQABAAEAAQABAAEAAQABABQAFAAUABQAB4AHgAeAB4AHgArACsAKwArACsAKwAEAAQABAAEAAQABAAEAA0ADQAeAB4AHgAeAB4AKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAAEAAQABAAEAAQABAAeAB4AHgANAA0ADQANACsAKwArACsAKwArACsAKwArACsAKwAeACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwBLAEsASwBLAEsASwBLAEsASwBLACsAKwArACsAKwArAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsASwBLAEsASwBLAEsASwBLAEsASwANAA0ADQANAFAABAAEAFAAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAeAA4AUAArACsAKwArACsAKwArACsAKwAEAFAAUABQAFAADQANAB4ADQAEAAQABAAEAB4ABAAEAEsASwBLAEsASwBLAEsASwBLAEsAUAAOAFAADQANAA0AKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAANAA0AHgANAA0AHgAEACsAUABQAFAAUABQAFAAUAArAFAAKwBQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAA0AKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsABAAEAAQABAArAFAAUABQAFAAUABQAFAAUAArACsAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUABQACsAUABQAFAAUABQACsABAAEAFAABAAEAAQABAAEAAQABAArACsABAAEACsAKwAEAAQABAArACsAUAArACsAKwArACsAKwAEACsAKwArACsAKwBQAFAAUABQAFAABAAEACsAKwAEAAQABAAEAAQABAAEACsAKwArAAQABAAEAAQABAArACsAKwArACsAKwArACsAKwArACsABAAEAAQABAAEAAQABABQAFAAUABQAA0ADQANAA0AHgBLAEsASwBLAEsASwBLAEsASwBLAA0ADQArAB4ABABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAEAAQABAAEAFAAUAAeAFAAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAArACsABAAEAAQABAAEAAQABAAEAAQADgANAA0AEwATAB4AHgAeAA0ADQANAA0ADQANAA0ADQANAA0ADQANAA0ADQANAFAAUABQAFAABAAEACsAKwAEAA0ADQAeAFAAKwArACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAFAAKwArACsAKwArACsAKwBLAEsASwBLAEsASwBLAEsASwBLACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAKwArACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwBcAFwADQANAA0AKgBQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAeACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwBQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAKwArAFAAKwArAFAAUABQAFAAUABQAFAAUAArAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQAKwAEAAQAKwArAAQABAAEAAQAUAAEAFAABAAEAA0ADQANACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAArACsABAAEAAQABAAEAAQABABQAA4AUAAEACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAABAAEAAQABAAEAAQABAAEAAQABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAFAABAAEAAQABAAOAB4ADQANAA0ADQAOAB4ABAArACsAKwArACsAKwArACsAUAAEAAQABAAEAAQABAAEAAQABAAEAAQAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAA0ADQANAFAADgAOAA4ADQANACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEACsABAAEAAQABAAEAAQABAAEAFAADQANAA0ADQANACsAKwArACsAKwArACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwAOABMAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQACsAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAArACsAKwAEACsABAAEACsABAAEAAQABAAEAAQABABQAAQAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAKwBQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQAKwAEAAQAKwAEAAQABAAEAAQAUAArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAB4AHgAeAB4AHgAeAB4AHgAaABoAGgAaAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwArACsAKwArACsAKwArAA0AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsADQANAA0ADQANACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAASABIAEgAQwBDAEMAUABQAFAAUABDAFAAUABQAEgAQwBIAEMAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAASABDAEMAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwAJAAkACQAJAAkACQAJABYAEQArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABIAEMAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwANAA0AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAAQABAAEAAQABAANACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAA0ADQANAB4AHgAeAB4AHgAeAFAAUABQAFAADQAeACsAKwArACsAKwArACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwArAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAANAA0AHgAeACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwAEAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwArACsAKwArACsAKwAEAAQABAAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAARwBHABUARwAJACsAKwArACsAKwArACsAKwArACsAKwAEAAQAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACsAKwArACsAKwArACsAKwBXAFcAVwBXAFcAVwBXAFcAVwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUQBRAFEAKwArACsAKwArACsAKwArACsAKwArACsAKwBRAFEAUQBRACsAKwArACsAKwArACsAKwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUAArACsAHgAEAAQADQAEAAQABAAEACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwArACsAKwArAB4AHgAeAB4AHgAeAB4AKwArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAAQABAAEAAQABAAeAB4AHgAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAB4AHgAEAAQABAAEAAQABAAEAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAEAAQABAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAEAAQAHgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwArACsAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwBQAFAAKwArAFAAKwArAFAAUAArACsAUABQAFAAUAArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACsAUAArAFAAUABQAFAAUABQAFAAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwBQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAHgAeAFAAUABQAFAAUAArAFAAKwArACsAUABQAFAAUABQAFAAUAArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAFAAUABQAFAAUABQAFAAUABQAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAB4AHgAeAB4AHgAeAB4AHgAeACsAKwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAeAB4AHgAeAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAeAB4AHgAeAB4AHgAeAB4ABAAeAB4AHgAeAB4AHgAeAB4AHgAeAAQAHgAeAA0ADQANAA0AHgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAEAAQABAAEAAQAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAAQABAAEAAQABAAEAAQAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwArAAQABAAEAAQABAAEAAQAKwAEAAQAKwAEAAQABAAEAAQAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwAEAAQABAAEAAQABAAEAFAAUABQAFAAUABQAFAAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwBQAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArABsAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwArAB4AHgAeAB4ABAAEAAQABAAEAAQABABQACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwArACsAKwArABYAFgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAGgBQAFAAUAAaAFAAUABQAFAAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAKwBQACsAKwBQACsAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAKwBQACsAUAArACsAKwArACsAKwBQACsAKwArACsAUAArAFAAKwBQACsAUABQAFAAKwBQAFAAKwBQACsAKwBQACsAUAArAFAAKwBQACsAUAArAFAAUAArAFAAKwArAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUABQAFAAUAArAFAAUABQAFAAKwBQACsAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAUABQAFAAKwBQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8AJQAlACUAHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHgAeAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB4AHgAeACUAJQAlAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQApACkAKQApACkAKQApACkAKQApACkAKQApACkAKQApACkAKQApACkAKQApACkAKQApACkAJQAlACUAJQAlACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAeAB4AJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlAB4AHgAlACUAJQAlACUAHgAlACUAJQAlACUAIAAgACAAJQAlACAAJQAlACAAIAAgACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACEAIQAhACEAIQAlACUAIAAgACUAJQAgACAAIAAgACAAIAAgACAAIAAgACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAJQAlACUAIAAlACUAJQAlACAAIAAgACUAIAAgACAAJQAlACUAJQAlACUAJQAgACUAIAAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAHgAlAB4AJQAeACUAJQAlACUAJQAgACUAJQAlACUAHgAlAB4AHgAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlAB4AHgAeAB4AHgAeAB4AJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAeACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACAAIAAlACUAJQAlACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACAAJQAlACUAJQAgACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAHgAeAB4AHgAeAB4AHgAeACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAeAB4AHgAeAB4AHgAlACUAJQAlACUAJQAlACAAIAAgACUAJQAlACAAIAAgACAAIAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeABcAFwAXABUAFQAVAB4AHgAeAB4AJQAlACUAIAAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACAAIAAgACUAJQAlACUAJQAlACUAJQAlACAAJQAlACUAJQAlACUAJQAlACUAJQAlACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AJQAlACUAJQAlACUAJQAlACUAJQAlACUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACUAJQAlACUAJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAeACUAJQAlACUAJQAlAB4AHgAeAB4AHgAeAB4AHgAlACUAJQAlACUAJQAlACUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAgACUAJQAgACUAJQAlACUAJQAlACUAJQAgACAAIAAgACAAIAAgACAAJQAlACUAJQAlACUAIAAlACUAJQAlACUAJQAlACUAJQAgACAAIAAgACAAIAAgACAAIAAgACUAJQAgACAAIAAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAgACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACAAIAAlACAAIAAlACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAgACAAIAAlACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAJQAlAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAKwArAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACUAJQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwAlACUAJQAlACUAJQAlACUAJQAlACUAVwBXACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAKwAEACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAA==';

  var LETTER_NUMBER_MODIFIER = 50;
  // Non-tailorable Line Breaking Classes
  var BK = 1; //  Cause a line break (after)
  var CR$1 = 2; //  Cause a line break (after), except between CR and LF
  var LF$1 = 3; //  Cause a line break (after)
  var CM = 4; //  Prohibit a line break between the character and the preceding character
  var NL = 5; //  Cause a line break (after)
  var WJ = 7; //  Prohibit line breaks before and after
  var ZW = 8; //  Provide a break opportunity
  var GL = 9; //  Prohibit line breaks before and after
  var SP = 10; // Enable indirect line breaks
  var ZWJ$1 = 11; // Prohibit line breaks within joiner sequences
  // Break Opportunities
  var B2 = 12; //  Provide a line break opportunity before and after the character
  var BA = 13; //  Generally provide a line break opportunity after the character
  var BB = 14; //  Generally provide a line break opportunity before the character
  var HY = 15; //  Provide a line break opportunity after the character, except in numeric context
  var CB = 16; //   Provide a line break opportunity contingent on additional information
  // Characters Prohibiting Certain Breaks
  var CL = 17; //  Prohibit line breaks before
  var CP = 18; //  Prohibit line breaks before
  var EX = 19; //  Prohibit line breaks before
  var IN = 20; //  Allow only indirect line breaks between pairs
  var NS = 21; //  Allow only indirect line breaks before
  var OP = 22; //  Prohibit line breaks after
  var QU = 23; //  Act like they are both opening and closing
  // Numeric Context
  var IS = 24; //  Prevent breaks after any and before numeric
  var NU = 25; //  Form numeric expressions for line breaking purposes
  var PO = 26; //  Do not break following a numeric expression
  var PR = 27; //  Do not break in front of a numeric expression
  var SY = 28; //  Prevent a break before; and allow a break after
  // Other Characters
  var AI = 29; //  Act like AL when the resolvedEAW is N; otherwise; act as ID
  var AL = 30; //  Are alphabetic characters or symbols that are used with alphabetic characters
  var CJ = 31; //  Treat as NS or ID for strict or normal breaking.
  var EB = 32; //  Do not break from following Emoji Modifier
  var EM = 33; //  Do not break from preceding Emoji Base
  var H2 = 34; //  Form Korean syllable blocks
  var H3 = 35; //  Form Korean syllable blocks
  var HL = 36; //  Do not break around a following hyphen; otherwise act as Alphabetic
  var ID = 37; //  Break before or after; except in some numeric context
  var JL = 38; //  Form Korean syllable blocks
  var JV = 39; //  Form Korean syllable blocks
  var JT = 40; //  Form Korean syllable blocks
  var RI$1 = 41; //  Keep pairs together. For pairs; break before and after other classes
  var SA = 42; //  Provide a line break opportunity contingent on additional, language-specific context analysis
  var XX = 43; //  Have as yet unknown line breaking behavior or unassigned code positions
  var ea_OP = [0x2329, 0xff08];
  var BREAK_MANDATORY = '!';
  var BREAK_NOT_ALLOWED$1 = '×';
  var BREAK_ALLOWED$1 = '÷';
  var UnicodeTrie$1 = createTrieFromBase64$1(base64$1);
  var ALPHABETICS = [AL, HL];
  var HARD_LINE_BREAKS = [BK, CR$1, LF$1, NL];
  var SPACE$1 = [SP, ZW];
  var PREFIX_POSTFIX = [PR, PO];
  var LINE_BREAKS = HARD_LINE_BREAKS.concat(SPACE$1);
  var KOREAN_SYLLABLE_BLOCK = [JL, JV, JT, H2, H3];
  var HYPHEN = [HY, BA];
  var codePointsToCharacterClasses = function (codePoints, lineBreak) {
      if (lineBreak === void 0) { lineBreak = 'strict'; }
      var types = [];
      var indices = [];
      var categories = [];
      codePoints.forEach(function (codePoint, index) {
          var classType = UnicodeTrie$1.get(codePoint);
          if (classType > LETTER_NUMBER_MODIFIER) {
              categories.push(true);
              classType -= LETTER_NUMBER_MODIFIER;
          }
          else {
              categories.push(false);
          }
          if (['normal', 'auto', 'loose'].indexOf(lineBreak) !== -1) {
              // U+2010, – U+2013, 〜 U+301C, ゠ U+30A0
              if ([0x2010, 0x2013, 0x301c, 0x30a0].indexOf(codePoint) !== -1) {
                  indices.push(index);
                  return types.push(CB);
              }
          }
          if (classType === CM || classType === ZWJ$1) {
              // LB10 Treat any remaining combining mark or ZWJ as AL.
              if (index === 0) {
                  indices.push(index);
                  return types.push(AL);
              }
              // LB9 Do not break a combining character sequence; treat it as if it has the line breaking class of
              // the base character in all of the following rules. Treat ZWJ as if it were CM.
              var prev = types[index - 1];
              if (LINE_BREAKS.indexOf(prev) === -1) {
                  indices.push(indices[index - 1]);
                  return types.push(prev);
              }
              indices.push(index);
              return types.push(AL);
          }
          indices.push(index);
          if (classType === CJ) {
              return types.push(lineBreak === 'strict' ? NS : ID);
          }
          if (classType === SA) {
              return types.push(AL);
          }
          if (classType === AI) {
              return types.push(AL);
          }
          // For supplementary characters, a useful default is to treat characters in the range 10000..1FFFD as AL
          // and characters in the ranges 20000..2FFFD and 30000..3FFFD as ID, until the implementation can be revised
          // to take into account the actual line breaking properties for these characters.
          if (classType === XX) {
              if ((codePoint >= 0x20000 && codePoint <= 0x2fffd) || (codePoint >= 0x30000 && codePoint <= 0x3fffd)) {
                  return types.push(ID);
              }
              else {
                  return types.push(AL);
              }
          }
          types.push(classType);
      });
      return [indices, types, categories];
  };
  var isAdjacentWithSpaceIgnored = function (a, b, currentIndex, classTypes) {
      var current = classTypes[currentIndex];
      if (Array.isArray(a) ? a.indexOf(current) !== -1 : a === current) {
          var i = currentIndex;
          while (i <= classTypes.length) {
              i++;
              var next = classTypes[i];
              if (next === b) {
                  return true;
              }
              if (next !== SP) {
                  break;
              }
          }
      }
      if (current === SP) {
          var i = currentIndex;
          while (i > 0) {
              i--;
              var prev = classTypes[i];
              if (Array.isArray(a) ? a.indexOf(prev) !== -1 : a === prev) {
                  var n = currentIndex;
                  while (n <= classTypes.length) {
                      n++;
                      var next = classTypes[n];
                      if (next === b) {
                          return true;
                      }
                      if (next !== SP) {
                          break;
                      }
                  }
              }
              if (prev !== SP) {
                  break;
              }
          }
      }
      return false;
  };
  var previousNonSpaceClassType = function (currentIndex, classTypes) {
      var i = currentIndex;
      while (i >= 0) {
          var type = classTypes[i];
          if (type === SP) {
              i--;
          }
          else {
              return type;
          }
      }
      return 0;
  };
  var _lineBreakAtIndex = function (codePoints, classTypes, indicies, index, forbiddenBreaks) {
      if (indicies[index] === 0) {
          return BREAK_NOT_ALLOWED$1;
      }
      var currentIndex = index - 1;
      if (Array.isArray(forbiddenBreaks) && forbiddenBreaks[currentIndex] === true) {
          return BREAK_NOT_ALLOWED$1;
      }
      var beforeIndex = currentIndex - 1;
      var afterIndex = currentIndex + 1;
      var current = classTypes[currentIndex];
      // LB4 Always break after hard line breaks.
      // LB5 Treat CR followed by LF, as well as CR, LF, and NL as hard line breaks.
      var before = beforeIndex >= 0 ? classTypes[beforeIndex] : 0;
      var next = classTypes[afterIndex];
      if (current === CR$1 && next === LF$1) {
          return BREAK_NOT_ALLOWED$1;
      }
      if (HARD_LINE_BREAKS.indexOf(current) !== -1) {
          return BREAK_MANDATORY;
      }
      // LB6 Do not break before hard line breaks.
      if (HARD_LINE_BREAKS.indexOf(next) !== -1) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB7 Do not break before spaces or zero width space.
      if (SPACE$1.indexOf(next) !== -1) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB8 Break before any character following a zero-width space, even if one or more spaces intervene.
      if (previousNonSpaceClassType(currentIndex, classTypes) === ZW) {
          return BREAK_ALLOWED$1;
      }
      // LB8a Do not break after a zero width joiner.
      if (UnicodeTrie$1.get(codePoints[currentIndex]) === ZWJ$1) {
          return BREAK_NOT_ALLOWED$1;
      }
      // zwj emojis
      if ((current === EB || current === EM) && UnicodeTrie$1.get(codePoints[afterIndex]) === ZWJ$1) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB11 Do not break before or after Word joiner and related characters.
      if (current === WJ || next === WJ) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB12 Do not break after NBSP and related characters.
      if (current === GL) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB12a Do not break before NBSP and related characters, except after spaces and hyphens.
      if ([SP, BA, HY].indexOf(current) === -1 && next === GL) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB13 Do not break before ‘]’ or ‘!’ or ‘;’ or ‘/’, even after spaces.
      if ([CL, CP, EX, IS, SY].indexOf(next) !== -1) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB14 Do not break after ‘[’, even after spaces.
      if (previousNonSpaceClassType(currentIndex, classTypes) === OP) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB15 Do not break within ‘”[’, even with intervening spaces.
      if (isAdjacentWithSpaceIgnored(QU, OP, currentIndex, classTypes)) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB16 Do not break between closing punctuation and a nonstarter (lb=NS), even with intervening spaces.
      if (isAdjacentWithSpaceIgnored([CL, CP], NS, currentIndex, classTypes)) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB17 Do not break within ‘——’, even with intervening spaces.
      if (isAdjacentWithSpaceIgnored(B2, B2, currentIndex, classTypes)) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB18 Break after spaces.
      if (current === SP) {
          return BREAK_ALLOWED$1;
      }
      // LB19 Do not break before or after quotation marks, such as ‘ ” ’.
      if (current === QU || next === QU) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB20 Break before and after unresolved CB.
      if (next === CB || current === CB) {
          return BREAK_ALLOWED$1;
      }
      // LB21 Do not break before hyphen-minus, other hyphens, fixed-width spaces, small kana, and other non-starters, or after acute accents.
      if ([BA, HY, NS].indexOf(next) !== -1 || current === BB) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB21a Don't break after Hebrew + Hyphen.
      if (before === HL && HYPHEN.indexOf(current) !== -1) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB21b Don’t break between Solidus and Hebrew letters.
      if (current === SY && next === HL) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB22 Do not break before ellipsis.
      if (next === IN) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB23 Do not break between digits and letters.
      if ((ALPHABETICS.indexOf(next) !== -1 && current === NU) || (ALPHABETICS.indexOf(current) !== -1 && next === NU)) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB23a Do not break between numeric prefixes and ideographs, or between ideographs and numeric postfixes.
      if ((current === PR && [ID, EB, EM].indexOf(next) !== -1) ||
          ([ID, EB, EM].indexOf(current) !== -1 && next === PO)) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB24 Do not break between numeric prefix/postfix and letters, or between letters and prefix/postfix.
      if ((ALPHABETICS.indexOf(current) !== -1 && PREFIX_POSTFIX.indexOf(next) !== -1) ||
          (PREFIX_POSTFIX.indexOf(current) !== -1 && ALPHABETICS.indexOf(next) !== -1)) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB25 Do not break between the following pairs of classes relevant to numbers:
      if (
      // (PR | PO) × ( OP | HY )? NU
      ([PR, PO].indexOf(current) !== -1 &&
          (next === NU || ([OP, HY].indexOf(next) !== -1 && classTypes[afterIndex + 1] === NU))) ||
          // ( OP | HY ) × NU
          ([OP, HY].indexOf(current) !== -1 && next === NU) ||
          // NU ×	(NU | SY | IS)
          (current === NU && [NU, SY, IS].indexOf(next) !== -1)) {
          return BREAK_NOT_ALLOWED$1;
      }
      // NU (NU | SY | IS)* × (NU | SY | IS | CL | CP)
      if ([NU, SY, IS, CL, CP].indexOf(next) !== -1) {
          var prevIndex = currentIndex;
          while (prevIndex >= 0) {
              var type = classTypes[prevIndex];
              if (type === NU) {
                  return BREAK_NOT_ALLOWED$1;
              }
              else if ([SY, IS].indexOf(type) !== -1) {
                  prevIndex--;
              }
              else {
                  break;
              }
          }
      }
      // NU (NU | SY | IS)* (CL | CP)? × (PO | PR))
      if ([PR, PO].indexOf(next) !== -1) {
          var prevIndex = [CL, CP].indexOf(current) !== -1 ? beforeIndex : currentIndex;
          while (prevIndex >= 0) {
              var type = classTypes[prevIndex];
              if (type === NU) {
                  return BREAK_NOT_ALLOWED$1;
              }
              else if ([SY, IS].indexOf(type) !== -1) {
                  prevIndex--;
              }
              else {
                  break;
              }
          }
      }
      // LB26 Do not break a Korean syllable.
      if ((JL === current && [JL, JV, H2, H3].indexOf(next) !== -1) ||
          ([JV, H2].indexOf(current) !== -1 && [JV, JT].indexOf(next) !== -1) ||
          ([JT, H3].indexOf(current) !== -1 && next === JT)) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB27 Treat a Korean Syllable Block the same as ID.
      if ((KOREAN_SYLLABLE_BLOCK.indexOf(current) !== -1 && [IN, PO].indexOf(next) !== -1) ||
          (KOREAN_SYLLABLE_BLOCK.indexOf(next) !== -1 && current === PR)) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB28 Do not break between alphabetics (“at”).
      if (ALPHABETICS.indexOf(current) !== -1 && ALPHABETICS.indexOf(next) !== -1) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB29 Do not break between numeric punctuation and alphabetics (“e.g.”).
      if (current === IS && ALPHABETICS.indexOf(next) !== -1) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB30 Do not break between letters, numbers, or ordinary symbols and opening or closing parentheses.
      if ((ALPHABETICS.concat(NU).indexOf(current) !== -1 &&
          next === OP &&
          ea_OP.indexOf(codePoints[afterIndex]) === -1) ||
          (ALPHABETICS.concat(NU).indexOf(next) !== -1 && current === CP)) {
          return BREAK_NOT_ALLOWED$1;
      }
      // LB30a Break between two regional indicator symbols if and only if there are an even number of regional
      // indicators preceding the position of the break.
      if (current === RI$1 && next === RI$1) {
          var i = indicies[currentIndex];
          var count = 1;
          while (i > 0) {
              i--;
              if (classTypes[i] === RI$1) {
                  count++;
              }
              else {
                  break;
              }
          }
          if (count % 2 !== 0) {
              return BREAK_NOT_ALLOWED$1;
          }
      }
      // LB30b Do not break between an emoji base and an emoji modifier.
      if (current === EB && next === EM) {
          return BREAK_NOT_ALLOWED$1;
      }
      return BREAK_ALLOWED$1;
  };
  var cssFormattedClasses = function (codePoints, options) {
      if (!options) {
          options = { lineBreak: 'normal', wordBreak: 'normal' };
      }
      var _a = codePointsToCharacterClasses(codePoints, options.lineBreak), indicies = _a[0], classTypes = _a[1], isLetterNumber = _a[2];
      if (options.wordBreak === 'break-all' || options.wordBreak === 'break-word') {
          classTypes = classTypes.map(function (type) { return ([NU, AL, SA].indexOf(type) !== -1 ? ID : type); });
      }
      var forbiddenBreakpoints = options.wordBreak === 'keep-all'
          ? isLetterNumber.map(function (letterNumber, i) {
              return letterNumber && codePoints[i] >= 0x4e00 && codePoints[i] <= 0x9fff;
          })
          : undefined;
      return [indicies, classTypes, forbiddenBreakpoints];
  };
  var Break = /** @class */ (function () {
      function Break(codePoints, lineBreak, start, end) {
          this.codePoints = codePoints;
          this.required = lineBreak === BREAK_MANDATORY;
          this.start = start;
          this.end = end;
      }
      Break.prototype.slice = function () {
          return fromCodePoint$1.apply(void 0, this.codePoints.slice(this.start, this.end));
      };
      return Break;
  }());
  var LineBreaker = function (str, options) {
      var codePoints = toCodePoints$1(str);
      var _a = cssFormattedClasses(codePoints, options), indicies = _a[0], classTypes = _a[1], forbiddenBreakpoints = _a[2];
      var length = codePoints.length;
      var lastEnd = 0;
      var nextIndex = 0;
      return {
          next: function () {
              if (nextIndex >= length) {
                  return { done: true, value: null };
              }
              var lineBreak = BREAK_NOT_ALLOWED$1;
              while (nextIndex < length &&
                  (lineBreak = _lineBreakAtIndex(codePoints, classTypes, indicies, ++nextIndex, forbiddenBreakpoints)) ===
                      BREAK_NOT_ALLOWED$1) { }
              if (lineBreak !== BREAK_NOT_ALLOWED$1 || nextIndex === length) {
                  var value = new Break(codePoints, lineBreak, lastEnd, nextIndex);
                  lastEnd = nextIndex;
                  return { value: value, done: false };
              }
              return { done: true, value: null };
          },
      };
  };

  // https://www.w3.org/TR/css-syntax-3
  var FLAG_UNRESTRICTED = 1 << 0;
  var FLAG_ID = 1 << 1;
  var FLAG_INTEGER = 1 << 2;
  var FLAG_NUMBER = 1 << 3;
  var LINE_FEED = 0x000a;
  var SOLIDUS = 0x002f;
  var REVERSE_SOLIDUS = 0x005c;
  var CHARACTER_TABULATION = 0x0009;
  var SPACE = 0x0020;
  var QUOTATION_MARK = 0x0022;
  var EQUALS_SIGN = 0x003d;
  var NUMBER_SIGN = 0x0023;
  var DOLLAR_SIGN = 0x0024;
  var PERCENTAGE_SIGN = 0x0025;
  var APOSTROPHE = 0x0027;
  var LEFT_PARENTHESIS = 0x0028;
  var RIGHT_PARENTHESIS = 0x0029;
  var LOW_LINE = 0x005f;
  var HYPHEN_MINUS = 0x002d;
  var EXCLAMATION_MARK = 0x0021;
  var LESS_THAN_SIGN = 0x003c;
  var GREATER_THAN_SIGN = 0x003e;
  var COMMERCIAL_AT = 0x0040;
  var LEFT_SQUARE_BRACKET = 0x005b;
  var RIGHT_SQUARE_BRACKET = 0x005d;
  var CIRCUMFLEX_ACCENT = 0x003d;
  var LEFT_CURLY_BRACKET = 0x007b;
  var QUESTION_MARK = 0x003f;
  var RIGHT_CURLY_BRACKET = 0x007d;
  var VERTICAL_LINE = 0x007c;
  var TILDE = 0x007e;
  var CONTROL = 0x0080;
  var REPLACEMENT_CHARACTER = 0xfffd;
  var ASTERISK = 0x002a;
  var PLUS_SIGN = 0x002b;
  var COMMA = 0x002c;
  var COLON = 0x003a;
  var SEMICOLON = 0x003b;
  var FULL_STOP = 0x002e;
  var NULL = 0x0000;
  var BACKSPACE = 0x0008;
  var LINE_TABULATION = 0x000b;
  var SHIFT_OUT = 0x000e;
  var INFORMATION_SEPARATOR_ONE = 0x001f;
  var DELETE = 0x007f;
  var EOF = -1;
  var ZERO = 0x0030;
  var a = 0x0061;
  var e = 0x0065;
  var f = 0x0066;
  var u = 0x0075;
  var z = 0x007a;
  var A = 0x0041;
  var E = 0x0045;
  var F = 0x0046;
  var U = 0x0055;
  var Z = 0x005a;
  var isDigit = function (codePoint) { return codePoint >= ZERO && codePoint <= 0x0039; };
  var isSurrogateCodePoint = function (codePoint) { return codePoint >= 0xd800 && codePoint <= 0xdfff; };
  var isHex = function (codePoint) {
      return isDigit(codePoint) || (codePoint >= A && codePoint <= F) || (codePoint >= a && codePoint <= f);
  };
  var isLowerCaseLetter = function (codePoint) { return codePoint >= a && codePoint <= z; };
  var isUpperCaseLetter = function (codePoint) { return codePoint >= A && codePoint <= Z; };
  var isLetter = function (codePoint) { return isLowerCaseLetter(codePoint) || isUpperCaseLetter(codePoint); };
  var isNonASCIICodePoint = function (codePoint) { return codePoint >= CONTROL; };
  var isWhiteSpace = function (codePoint) {
      return codePoint === LINE_FEED || codePoint === CHARACTER_TABULATION || codePoint === SPACE;
  };
  var isNameStartCodePoint = function (codePoint) {
      return isLetter(codePoint) || isNonASCIICodePoint(codePoint) || codePoint === LOW_LINE;
  };
  var isNameCodePoint = function (codePoint) {
      return isNameStartCodePoint(codePoint) || isDigit(codePoint) || codePoint === HYPHEN_MINUS;
  };
  var isNonPrintableCodePoint = function (codePoint) {
      return ((codePoint >= NULL && codePoint <= BACKSPACE) ||
          codePoint === LINE_TABULATION ||
          (codePoint >= SHIFT_OUT && codePoint <= INFORMATION_SEPARATOR_ONE) ||
          codePoint === DELETE);
  };
  var isValidEscape = function (c1, c2) {
      if (c1 !== REVERSE_SOLIDUS) {
          return false;
      }
      return c2 !== LINE_FEED;
  };
  var isIdentifierStart = function (c1, c2, c3) {
      if (c1 === HYPHEN_MINUS) {
          return isNameStartCodePoint(c2) || isValidEscape(c2, c3);
      }
      else if (isNameStartCodePoint(c1)) {
          return true;
      }
      else if (c1 === REVERSE_SOLIDUS && isValidEscape(c1, c2)) {
          return true;
      }
      return false;
  };
  var isNumberStart = function (c1, c2, c3) {
      if (c1 === PLUS_SIGN || c1 === HYPHEN_MINUS) {
          if (isDigit(c2)) {
              return true;
          }
          return c2 === FULL_STOP && isDigit(c3);
      }
      if (c1 === FULL_STOP) {
          return isDigit(c2);
      }
      return isDigit(c1);
  };
  var stringToNumber = function (codePoints) {
      var c = 0;
      var sign = 1;
      if (codePoints[c] === PLUS_SIGN || codePoints[c] === HYPHEN_MINUS) {
          if (codePoints[c] === HYPHEN_MINUS) {
              sign = -1;
          }
          c++;
      }
      var integers = [];
      while (isDigit(codePoints[c])) {
          integers.push(codePoints[c++]);
      }
      var int = integers.length ? parseInt(fromCodePoint$1.apply(void 0, integers), 10) : 0;
      if (codePoints[c] === FULL_STOP) {
          c++;
      }
      var fraction = [];
      while (isDigit(codePoints[c])) {
          fraction.push(codePoints[c++]);
      }
      var fracd = fraction.length;
      var frac = fracd ? parseInt(fromCodePoint$1.apply(void 0, fraction), 10) : 0;
      if (codePoints[c] === E || codePoints[c] === e) {
          c++;
      }
      var expsign = 1;
      if (codePoints[c] === PLUS_SIGN || codePoints[c] === HYPHEN_MINUS) {
          if (codePoints[c] === HYPHEN_MINUS) {
              expsign = -1;
          }
          c++;
      }
      var exponent = [];
      while (isDigit(codePoints[c])) {
          exponent.push(codePoints[c++]);
      }
      var exp = exponent.length ? parseInt(fromCodePoint$1.apply(void 0, exponent), 10) : 0;
      return sign * (int + frac * Math.pow(10, -fracd)) * Math.pow(10, expsign * exp);
  };
  var LEFT_PARENTHESIS_TOKEN = {
      type: 2 /* LEFT_PARENTHESIS_TOKEN */
  };
  var RIGHT_PARENTHESIS_TOKEN = {
      type: 3 /* RIGHT_PARENTHESIS_TOKEN */
  };
  var COMMA_TOKEN = { type: 4 /* COMMA_TOKEN */ };
  var SUFFIX_MATCH_TOKEN = { type: 13 /* SUFFIX_MATCH_TOKEN */ };
  var PREFIX_MATCH_TOKEN = { type: 8 /* PREFIX_MATCH_TOKEN */ };
  var COLUMN_TOKEN = { type: 21 /* COLUMN_TOKEN */ };
  var DASH_MATCH_TOKEN = { type: 9 /* DASH_MATCH_TOKEN */ };
  var INCLUDE_MATCH_TOKEN = { type: 10 /* INCLUDE_MATCH_TOKEN */ };
  var LEFT_CURLY_BRACKET_TOKEN = {
      type: 11 /* LEFT_CURLY_BRACKET_TOKEN */
  };
  var RIGHT_CURLY_BRACKET_TOKEN = {
      type: 12 /* RIGHT_CURLY_BRACKET_TOKEN */
  };
  var SUBSTRING_MATCH_TOKEN = { type: 14 /* SUBSTRING_MATCH_TOKEN */ };
  var BAD_URL_TOKEN = { type: 23 /* BAD_URL_TOKEN */ };
  var BAD_STRING_TOKEN = { type: 1 /* BAD_STRING_TOKEN */ };
  var CDO_TOKEN = { type: 25 /* CDO_TOKEN */ };
  var CDC_TOKEN = { type: 24 /* CDC_TOKEN */ };
  var COLON_TOKEN = { type: 26 /* COLON_TOKEN */ };
  var SEMICOLON_TOKEN = { type: 27 /* SEMICOLON_TOKEN */ };
  var LEFT_SQUARE_BRACKET_TOKEN = {
      type: 28 /* LEFT_SQUARE_BRACKET_TOKEN */
  };
  var RIGHT_SQUARE_BRACKET_TOKEN = {
      type: 29 /* RIGHT_SQUARE_BRACKET_TOKEN */
  };
  var WHITESPACE_TOKEN = { type: 31 /* WHITESPACE_TOKEN */ };
  var EOF_TOKEN = { type: 32 /* EOF_TOKEN */ };
  var Tokenizer = /** @class */ (function () {
      function Tokenizer() {
          this._value = [];
      }
      Tokenizer.prototype.write = function (chunk) {
          this._value = this._value.concat(toCodePoints$1(chunk));
      };
      Tokenizer.prototype.read = function () {
          var tokens = [];
          var token = this.consumeToken();
          while (token !== EOF_TOKEN) {
              tokens.push(token);
              token = this.consumeToken();
          }
          return tokens;
      };
      Tokenizer.prototype.consumeToken = function () {
          var codePoint = this.consumeCodePoint();
          switch (codePoint) {
              case QUOTATION_MARK:
                  return this.consumeStringToken(QUOTATION_MARK);
              case NUMBER_SIGN:
                  var c1 = this.peekCodePoint(0);
                  var c2 = this.peekCodePoint(1);
                  var c3 = this.peekCodePoint(2);
                  if (isNameCodePoint(c1) || isValidEscape(c2, c3)) {
                      var flags = isIdentifierStart(c1, c2, c3) ? FLAG_ID : FLAG_UNRESTRICTED;
                      var value = this.consumeName();
                      return { type: 5 /* HASH_TOKEN */, value: value, flags: flags };
                  }
                  break;
              case DOLLAR_SIGN:
                  if (this.peekCodePoint(0) === EQUALS_SIGN) {
                      this.consumeCodePoint();
                      return SUFFIX_MATCH_TOKEN;
                  }
                  break;
              case APOSTROPHE:
                  return this.consumeStringToken(APOSTROPHE);
              case LEFT_PARENTHESIS:
                  return LEFT_PARENTHESIS_TOKEN;
              case RIGHT_PARENTHESIS:
                  return RIGHT_PARENTHESIS_TOKEN;
              case ASTERISK:
                  if (this.peekCodePoint(0) === EQUALS_SIGN) {
                      this.consumeCodePoint();
                      return SUBSTRING_MATCH_TOKEN;
                  }
                  break;
              case PLUS_SIGN:
                  if (isNumberStart(codePoint, this.peekCodePoint(0), this.peekCodePoint(1))) {
                      this.reconsumeCodePoint(codePoint);
                      return this.consumeNumericToken();
                  }
                  break;
              case COMMA:
                  return COMMA_TOKEN;
              case HYPHEN_MINUS:
                  var e1 = codePoint;
                  var e2 = this.peekCodePoint(0);
                  var e3 = this.peekCodePoint(1);
                  if (isNumberStart(e1, e2, e3)) {
                      this.reconsumeCodePoint(codePoint);
                      return this.consumeNumericToken();
                  }
                  if (isIdentifierStart(e1, e2, e3)) {
                      this.reconsumeCodePoint(codePoint);
                      return this.consumeIdentLikeToken();
                  }
                  if (e2 === HYPHEN_MINUS && e3 === GREATER_THAN_SIGN) {
                      this.consumeCodePoint();
                      this.consumeCodePoint();
                      return CDC_TOKEN;
                  }
                  break;
              case FULL_STOP:
                  if (isNumberStart(codePoint, this.peekCodePoint(0), this.peekCodePoint(1))) {
                      this.reconsumeCodePoint(codePoint);
                      return this.consumeNumericToken();
                  }
                  break;
              case SOLIDUS:
                  if (this.peekCodePoint(0) === ASTERISK) {
                      this.consumeCodePoint();
                      while (true) {
                          var c = this.consumeCodePoint();
                          if (c === ASTERISK) {
                              c = this.consumeCodePoint();
                              if (c === SOLIDUS) {
                                  return this.consumeToken();
                              }
                          }
                          if (c === EOF) {
                              return this.consumeToken();
                          }
                      }
                  }
                  break;
              case COLON:
                  return COLON_TOKEN;
              case SEMICOLON:
                  return SEMICOLON_TOKEN;
              case LESS_THAN_SIGN:
                  if (this.peekCodePoint(0) === EXCLAMATION_MARK &&
                      this.peekCodePoint(1) === HYPHEN_MINUS &&
                      this.peekCodePoint(2) === HYPHEN_MINUS) {
                      this.consumeCodePoint();
                      this.consumeCodePoint();
                      return CDO_TOKEN;
                  }
                  break;
              case COMMERCIAL_AT:
                  var a1 = this.peekCodePoint(0);
                  var a2 = this.peekCodePoint(1);
                  var a3 = this.peekCodePoint(2);
                  if (isIdentifierStart(a1, a2, a3)) {
                      var value = this.consumeName();
                      return { type: 7 /* AT_KEYWORD_TOKEN */, value: value };
                  }
                  break;
              case LEFT_SQUARE_BRACKET:
                  return LEFT_SQUARE_BRACKET_TOKEN;
              case REVERSE_SOLIDUS:
                  if (isValidEscape(codePoint, this.peekCodePoint(0))) {
                      this.reconsumeCodePoint(codePoint);
                      return this.consumeIdentLikeToken();
                  }
                  break;
              case RIGHT_SQUARE_BRACKET:
                  return RIGHT_SQUARE_BRACKET_TOKEN;
              case CIRCUMFLEX_ACCENT:
                  if (this.peekCodePoint(0) === EQUALS_SIGN) {
                      this.consumeCodePoint();
                      return PREFIX_MATCH_TOKEN;
                  }
                  break;
              case LEFT_CURLY_BRACKET:
                  return LEFT_CURLY_BRACKET_TOKEN;
              case RIGHT_CURLY_BRACKET:
                  return RIGHT_CURLY_BRACKET_TOKEN;
              case u:
              case U:
                  var u1 = this.peekCodePoint(0);
                  var u2 = this.peekCodePoint(1);
                  if (u1 === PLUS_SIGN && (isHex(u2) || u2 === QUESTION_MARK)) {
                      this.consumeCodePoint();
                      this.consumeUnicodeRangeToken();
                  }
                  this.reconsumeCodePoint(codePoint);
                  return this.consumeIdentLikeToken();
              case VERTICAL_LINE:
                  if (this.peekCodePoint(0) === EQUALS_SIGN) {
                      this.consumeCodePoint();
                      return DASH_MATCH_TOKEN;
                  }
                  if (this.peekCodePoint(0) === VERTICAL_LINE) {
                      this.consumeCodePoint();
                      return COLUMN_TOKEN;
                  }
                  break;
              case TILDE:
                  if (this.peekCodePoint(0) === EQUALS_SIGN) {
                      this.consumeCodePoint();
                      return INCLUDE_MATCH_TOKEN;
                  }
                  break;
              case EOF:
                  return EOF_TOKEN;
          }
          if (isWhiteSpace(codePoint)) {
              this.consumeWhiteSpace();
              return WHITESPACE_TOKEN;
          }
          if (isDigit(codePoint)) {
              this.reconsumeCodePoint(codePoint);
              return this.consumeNumericToken();
          }
          if (isNameStartCodePoint(codePoint)) {
              this.reconsumeCodePoint(codePoint);
              return this.consumeIdentLikeToken();
          }
          return { type: 6 /* DELIM_TOKEN */, value: fromCodePoint$1(codePoint) };
      };
      Tokenizer.prototype.consumeCodePoint = function () {
          var value = this._value.shift();
          return typeof value === 'undefined' ? -1 : value;
      };
      Tokenizer.prototype.reconsumeCodePoint = function (codePoint) {
          this._value.unshift(codePoint);
      };
      Tokenizer.prototype.peekCodePoint = function (delta) {
          if (delta >= this._value.length) {
              return -1;
          }
          return this._value[delta];
      };
      Tokenizer.prototype.consumeUnicodeRangeToken = function () {
          var digits = [];
          var codePoint = this.consumeCodePoint();
          while (isHex(codePoint) && digits.length < 6) {
              digits.push(codePoint);
              codePoint = this.consumeCodePoint();
          }
          var questionMarks = false;
          while (codePoint === QUESTION_MARK && digits.length < 6) {
              digits.push(codePoint);
              codePoint = this.consumeCodePoint();
              questionMarks = true;
          }
          if (questionMarks) {
              var start_1 = parseInt(fromCodePoint$1.apply(void 0, digits.map(function (digit) { return (digit === QUESTION_MARK ? ZERO : digit); })), 16);
              var end = parseInt(fromCodePoint$1.apply(void 0, digits.map(function (digit) { return (digit === QUESTION_MARK ? F : digit); })), 16);
              return { type: 30 /* UNICODE_RANGE_TOKEN */, start: start_1, end: end };
          }
          var start = parseInt(fromCodePoint$1.apply(void 0, digits), 16);
          if (this.peekCodePoint(0) === HYPHEN_MINUS && isHex(this.peekCodePoint(1))) {
              this.consumeCodePoint();
              codePoint = this.consumeCodePoint();
              var endDigits = [];
              while (isHex(codePoint) && endDigits.length < 6) {
                  endDigits.push(codePoint);
                  codePoint = this.consumeCodePoint();
              }
              var end = parseInt(fromCodePoint$1.apply(void 0, endDigits), 16);
              return { type: 30 /* UNICODE_RANGE_TOKEN */, start: start, end: end };
          }
          else {
              return { type: 30 /* UNICODE_RANGE_TOKEN */, start: start, end: start };
          }
      };
      Tokenizer.prototype.consumeIdentLikeToken = function () {
          var value = this.consumeName();
          if (value.toLowerCase() === 'url' && this.peekCodePoint(0) === LEFT_PARENTHESIS) {
              this.consumeCodePoint();
              return this.consumeUrlToken();
          }
          else if (this.peekCodePoint(0) === LEFT_PARENTHESIS) {
              this.consumeCodePoint();
              return { type: 19 /* FUNCTION_TOKEN */, value: value };
          }
          return { type: 20 /* IDENT_TOKEN */, value: value };
      };
      Tokenizer.prototype.consumeUrlToken = function () {
          var value = [];
          this.consumeWhiteSpace();
          if (this.peekCodePoint(0) === EOF) {
              return { type: 22 /* URL_TOKEN */, value: '' };
          }
          var next = this.peekCodePoint(0);
          if (next === APOSTROPHE || next === QUOTATION_MARK) {
              var stringToken = this.consumeStringToken(this.consumeCodePoint());
              if (stringToken.type === 0 /* STRING_TOKEN */) {
                  this.consumeWhiteSpace();
                  if (this.peekCodePoint(0) === EOF || this.peekCodePoint(0) === RIGHT_PARENTHESIS) {
                      this.consumeCodePoint();
                      return { type: 22 /* URL_TOKEN */, value: stringToken.value };
                  }
              }
              this.consumeBadUrlRemnants();
              return BAD_URL_TOKEN;
          }
          while (true) {
              var codePoint = this.consumeCodePoint();
              if (codePoint === EOF || codePoint === RIGHT_PARENTHESIS) {
                  return { type: 22 /* URL_TOKEN */, value: fromCodePoint$1.apply(void 0, value) };
              }
              else if (isWhiteSpace(codePoint)) {
                  this.consumeWhiteSpace();
                  if (this.peekCodePoint(0) === EOF || this.peekCodePoint(0) === RIGHT_PARENTHESIS) {
                      this.consumeCodePoint();
                      return { type: 22 /* URL_TOKEN */, value: fromCodePoint$1.apply(void 0, value) };
                  }
                  this.consumeBadUrlRemnants();
                  return BAD_URL_TOKEN;
              }
              else if (codePoint === QUOTATION_MARK ||
                  codePoint === APOSTROPHE ||
                  codePoint === LEFT_PARENTHESIS ||
                  isNonPrintableCodePoint(codePoint)) {
                  this.consumeBadUrlRemnants();
                  return BAD_URL_TOKEN;
              }
              else if (codePoint === REVERSE_SOLIDUS) {
                  if (isValidEscape(codePoint, this.peekCodePoint(0))) {
                      value.push(this.consumeEscapedCodePoint());
                  }
                  else {
                      this.consumeBadUrlRemnants();
                      return BAD_URL_TOKEN;
                  }
              }
              else {
                  value.push(codePoint);
              }
          }
      };
      Tokenizer.prototype.consumeWhiteSpace = function () {
          while (isWhiteSpace(this.peekCodePoint(0))) {
              this.consumeCodePoint();
          }
      };
      Tokenizer.prototype.consumeBadUrlRemnants = function () {
          while (true) {
              var codePoint = this.consumeCodePoint();
              if (codePoint === RIGHT_PARENTHESIS || codePoint === EOF) {
                  return;
              }
              if (isValidEscape(codePoint, this.peekCodePoint(0))) {
                  this.consumeEscapedCodePoint();
              }
          }
      };
      Tokenizer.prototype.consumeStringSlice = function (count) {
          var SLICE_STACK_SIZE = 50000;
          var value = '';
          while (count > 0) {
              var amount = Math.min(SLICE_STACK_SIZE, count);
              value += fromCodePoint$1.apply(void 0, this._value.splice(0, amount));
              count -= amount;
          }
          this._value.shift();
          return value;
      };
      Tokenizer.prototype.consumeStringToken = function (endingCodePoint) {
          var value = '';
          var i = 0;
          do {
              var codePoint = this._value[i];
              if (codePoint === EOF || codePoint === undefined || codePoint === endingCodePoint) {
                  value += this.consumeStringSlice(i);
                  return { type: 0 /* STRING_TOKEN */, value: value };
              }
              if (codePoint === LINE_FEED) {
                  this._value.splice(0, i);
                  return BAD_STRING_TOKEN;
              }
              if (codePoint === REVERSE_SOLIDUS) {
                  var next = this._value[i + 1];
                  if (next !== EOF && next !== undefined) {
                      if (next === LINE_FEED) {
                          value += this.consumeStringSlice(i);
                          i = -1;
                          this._value.shift();
                      }
                      else if (isValidEscape(codePoint, next)) {
                          value += this.consumeStringSlice(i);
                          value += fromCodePoint$1(this.consumeEscapedCodePoint());
                          i = -1;
                      }
                  }
              }
              i++;
          } while (true);
      };
      Tokenizer.prototype.consumeNumber = function () {
          var repr = [];
          var type = FLAG_INTEGER;
          var c1 = this.peekCodePoint(0);
          if (c1 === PLUS_SIGN || c1 === HYPHEN_MINUS) {
              repr.push(this.consumeCodePoint());
          }
          while (isDigit(this.peekCodePoint(0))) {
              repr.push(this.consumeCodePoint());
          }
          c1 = this.peekCodePoint(0);
          var c2 = this.peekCodePoint(1);
          if (c1 === FULL_STOP && isDigit(c2)) {
              repr.push(this.consumeCodePoint(), this.consumeCodePoint());
              type = FLAG_NUMBER;
              while (isDigit(this.peekCodePoint(0))) {
                  repr.push(this.consumeCodePoint());
              }
          }
          c1 = this.peekCodePoint(0);
          c2 = this.peekCodePoint(1);
          var c3 = this.peekCodePoint(2);
          if ((c1 === E || c1 === e) && (((c2 === PLUS_SIGN || c2 === HYPHEN_MINUS) && isDigit(c3)) || isDigit(c2))) {
              repr.push(this.consumeCodePoint(), this.consumeCodePoint());
              type = FLAG_NUMBER;
              while (isDigit(this.peekCodePoint(0))) {
                  repr.push(this.consumeCodePoint());
              }
          }
          return [stringToNumber(repr), type];
      };
      Tokenizer.prototype.consumeNumericToken = function () {
          var _a = this.consumeNumber(), number = _a[0], flags = _a[1];
          var c1 = this.peekCodePoint(0);
          var c2 = this.peekCodePoint(1);
          var c3 = this.peekCodePoint(2);
          if (isIdentifierStart(c1, c2, c3)) {
              var unit = this.consumeName();
              return { type: 15 /* DIMENSION_TOKEN */, number: number, flags: flags, unit: unit };
          }
          if (c1 === PERCENTAGE_SIGN) {
              this.consumeCodePoint();
              return { type: 16 /* PERCENTAGE_TOKEN */, number: number, flags: flags };
          }
          return { type: 17 /* NUMBER_TOKEN */, number: number, flags: flags };
      };
      Tokenizer.prototype.consumeEscapedCodePoint = function () {
          var codePoint = this.consumeCodePoint();
          if (isHex(codePoint)) {
              var hex = fromCodePoint$1(codePoint);
              while (isHex(this.peekCodePoint(0)) && hex.length < 6) {
                  hex += fromCodePoint$1(this.consumeCodePoint());
              }
              if (isWhiteSpace(this.peekCodePoint(0))) {
                  this.consumeCodePoint();
              }
              var hexCodePoint = parseInt(hex, 16);
              if (hexCodePoint === 0 || isSurrogateCodePoint(hexCodePoint) || hexCodePoint > 0x10ffff) {
                  return REPLACEMENT_CHARACTER;
              }
              return hexCodePoint;
          }
          if (codePoint === EOF) {
              return REPLACEMENT_CHARACTER;
          }
          return codePoint;
      };
      Tokenizer.prototype.consumeName = function () {
          var result = '';
          while (true) {
              var codePoint = this.consumeCodePoint();
              if (isNameCodePoint(codePoint)) {
                  result += fromCodePoint$1(codePoint);
              }
              else if (isValidEscape(codePoint, this.peekCodePoint(0))) {
                  result += fromCodePoint$1(this.consumeEscapedCodePoint());
              }
              else {
                  this.reconsumeCodePoint(codePoint);
                  return result;
              }
          }
      };
      return Tokenizer;
  }());

  var Parser = /** @class */ (function () {
      function Parser(tokens) {
          this._tokens = tokens;
      }
      Parser.create = function (value) {
          var tokenizer = new Tokenizer();
          tokenizer.write(value);
          return new Parser(tokenizer.read());
      };
      Parser.parseValue = function (value) {
          return Parser.create(value).parseComponentValue();
      };
      Parser.parseValues = function (value) {
          return Parser.create(value).parseComponentValues();
      };
      Parser.prototype.parseComponentValue = function () {
          var token = this.consumeToken();
          while (token.type === 31 /* WHITESPACE_TOKEN */) {
              token = this.consumeToken();
          }
          if (token.type === 32 /* EOF_TOKEN */) {
              throw new SyntaxError("Error parsing CSS component value, unexpected EOF");
          }
          this.reconsumeToken(token);
          var value = this.consumeComponentValue();
          do {
              token = this.consumeToken();
          } while (token.type === 31 /* WHITESPACE_TOKEN */);
          if (token.type === 32 /* EOF_TOKEN */) {
              return value;
          }
          throw new SyntaxError("Error parsing CSS component value, multiple values found when expecting only one");
      };
      Parser.prototype.parseComponentValues = function () {
          var values = [];
          while (true) {
              var value = this.consumeComponentValue();
              if (value.type === 32 /* EOF_TOKEN */) {
                  return values;
              }
              values.push(value);
              values.push();
          }
      };
      Parser.prototype.consumeComponentValue = function () {
          var token = this.consumeToken();
          switch (token.type) {
              case 11 /* LEFT_CURLY_BRACKET_TOKEN */:
              case 28 /* LEFT_SQUARE_BRACKET_TOKEN */:
              case 2 /* LEFT_PARENTHESIS_TOKEN */:
                  return this.consumeSimpleBlock(token.type);
              case 19 /* FUNCTION_TOKEN */:
                  return this.consumeFunction(token);
          }
          return token;
      };
      Parser.prototype.consumeSimpleBlock = function (type) {
          var block = { type: type, values: [] };
          var token = this.consumeToken();
          while (true) {
              if (token.type === 32 /* EOF_TOKEN */ || isEndingTokenFor(token, type)) {
                  return block;
              }
              this.reconsumeToken(token);
              block.values.push(this.consumeComponentValue());
              token = this.consumeToken();
          }
      };
      Parser.prototype.consumeFunction = function (functionToken) {
          var cssFunction = {
              name: functionToken.value,
              values: [],
              type: 18 /* FUNCTION */
          };
          while (true) {
              var token = this.consumeToken();
              if (token.type === 32 /* EOF_TOKEN */ || token.type === 3 /* RIGHT_PARENTHESIS_TOKEN */) {
                  return cssFunction;
              }
              this.reconsumeToken(token);
              cssFunction.values.push(this.consumeComponentValue());
          }
      };
      Parser.prototype.consumeToken = function () {
          var token = this._tokens.shift();
          return typeof token === 'undefined' ? EOF_TOKEN : token;
      };
      Parser.prototype.reconsumeToken = function (token) {
          this._tokens.unshift(token);
      };
      return Parser;
  }());
  var isDimensionToken = function (token) { return token.type === 15 /* DIMENSION_TOKEN */; };
  var isNumberToken = function (token) { return token.type === 17 /* NUMBER_TOKEN */; };
  var isIdentToken = function (token) { return token.type === 20 /* IDENT_TOKEN */; };
  var isIdentWithValue = function (token, value) {
      return isIdentToken(token) && token.value === value;
  };
  var nonFunctionArgSeparator = function (token) {
      return token.type !== 31 /* WHITESPACE_TOKEN */ && token.type !== 4 /* COMMA_TOKEN */;
  };
  var parseFunctionArgs = function (tokens) {
      var args = [];
      var arg = [];
      tokens.forEach(function (token) {
          if (token.type === 4 /* COMMA_TOKEN */) {
              if (arg.length === 0) {
                  throw new Error("Error parsing function args, zero tokens for arg");
              }
              args.push(arg);
              arg = [];
              return;
          }
          if (token.type !== 31 /* WHITESPACE_TOKEN */) {
              arg.push(token);
          }
      });
      if (arg.length) {
          args.push(arg);
      }
      return args;
  };
  var isEndingTokenFor = function (token, type) {
      if (type === 11 /* LEFT_CURLY_BRACKET_TOKEN */ && token.type === 12 /* RIGHT_CURLY_BRACKET_TOKEN */) {
          return true;
      }
      if (type === 28 /* LEFT_SQUARE_BRACKET_TOKEN */ && token.type === 29 /* RIGHT_SQUARE_BRACKET_TOKEN */) {
          return true;
      }
      return type === 2 /* LEFT_PARENTHESIS_TOKEN */ && token.type === 3 /* RIGHT_PARENTHESIS_TOKEN */;
  };

  var isLength = function (token) {
      return token.type === 17 /* NUMBER_TOKEN */ || token.type === 15 /* DIMENSION_TOKEN */;
  };

  var isLengthPercentage = function (token) {
      return token.type === 16 /* PERCENTAGE_TOKEN */ || isLength(token);
  };
  var parseLengthPercentageTuple = function (tokens) {
      return tokens.length > 1 ? [tokens[0], tokens[1]] : [tokens[0]];
  };
  var ZERO_LENGTH = {
      type: 17 /* NUMBER_TOKEN */,
      number: 0,
      flags: FLAG_INTEGER
  };
  var FIFTY_PERCENT = {
      type: 16 /* PERCENTAGE_TOKEN */,
      number: 50,
      flags: FLAG_INTEGER
  };
  var HUNDRED_PERCENT = {
      type: 16 /* PERCENTAGE_TOKEN */,
      number: 100,
      flags: FLAG_INTEGER
  };
  var getAbsoluteValueForTuple = function (tuple, width, height) {
      var x = tuple[0], y = tuple[1];
      return [getAbsoluteValue(x, width), getAbsoluteValue(typeof y !== 'undefined' ? y : x, height)];
  };
  var getAbsoluteValue = function (token, parent) {
      if (token.type === 16 /* PERCENTAGE_TOKEN */) {
          return (token.number / 100) * parent;
      }
      if (isDimensionToken(token)) {
          switch (token.unit) {
              case 'rem':
              case 'em':
                  return 16 * token.number; // TODO use correct font-size
              case 'px':
              default:
                  return token.number;
          }
      }
      return token.number;
  };

  var DEG = 'deg';
  var GRAD = 'grad';
  var RAD = 'rad';
  var TURN = 'turn';
  var angle = {
      name: 'angle',
      parse: function (_context, value) {
          if (value.type === 15 /* DIMENSION_TOKEN */) {
              switch (value.unit) {
                  case DEG:
                      return (Math.PI * value.number) / 180;
                  case GRAD:
                      return (Math.PI / 200) * value.number;
                  case RAD:
                      return value.number;
                  case TURN:
                      return Math.PI * 2 * value.number;
              }
          }
          throw new Error("Unsupported angle type");
      }
  };
  var isAngle = function (value) {
      if (value.type === 15 /* DIMENSION_TOKEN */) {
          if (value.unit === DEG || value.unit === GRAD || value.unit === RAD || value.unit === TURN) {
              return true;
          }
      }
      return false;
  };
  var parseNamedSide = function (tokens) {
      var sideOrCorner = tokens
          .filter(isIdentToken)
          .map(function (ident) { return ident.value; })
          .join(' ');
      switch (sideOrCorner) {
          case 'to bottom right':
          case 'to right bottom':
          case 'left top':
          case 'top left':
              return [ZERO_LENGTH, ZERO_LENGTH];
          case 'to top':
          case 'bottom':
              return deg(0);
          case 'to bottom left':
          case 'to left bottom':
          case 'right top':
          case 'top right':
              return [ZERO_LENGTH, HUNDRED_PERCENT];
          case 'to right':
          case 'left':
              return deg(90);
          case 'to top left':
          case 'to left top':
          case 'right bottom':
          case 'bottom right':
              return [HUNDRED_PERCENT, HUNDRED_PERCENT];
          case 'to bottom':
          case 'top':
              return deg(180);
          case 'to top right':
          case 'to right top':
          case 'left bottom':
          case 'bottom left':
              return [HUNDRED_PERCENT, ZERO_LENGTH];
          case 'to left':
          case 'right':
              return deg(270);
      }
      return 0;
  };
  var deg = function (deg) { return (Math.PI * deg) / 180; };

  var color$1 = {
      name: 'color',
      parse: function (context, value) {
          if (value.type === 18 /* FUNCTION */) {
              var colorFunction = SUPPORTED_COLOR_FUNCTIONS[value.name];
              if (typeof colorFunction === 'undefined') {
                  throw new Error("Attempting to parse an unsupported color function \"" + value.name + "\"");
              }
              return colorFunction(context, value.values);
          }
          if (value.type === 5 /* HASH_TOKEN */) {
              if (value.value.length === 3) {
                  var r = value.value.substring(0, 1);
                  var g = value.value.substring(1, 2);
                  var b = value.value.substring(2, 3);
                  return pack(parseInt(r + r, 16), parseInt(g + g, 16), parseInt(b + b, 16), 1);
              }
              if (value.value.length === 4) {
                  var r = value.value.substring(0, 1);
                  var g = value.value.substring(1, 2);
                  var b = value.value.substring(2, 3);
                  var a = value.value.substring(3, 4);
                  return pack(parseInt(r + r, 16), parseInt(g + g, 16), parseInt(b + b, 16), parseInt(a + a, 16) / 255);
              }
              if (value.value.length === 6) {
                  var r = value.value.substring(0, 2);
                  var g = value.value.substring(2, 4);
                  var b = value.value.substring(4, 6);
                  return pack(parseInt(r, 16), parseInt(g, 16), parseInt(b, 16), 1);
              }
              if (value.value.length === 8) {
                  var r = value.value.substring(0, 2);
                  var g = value.value.substring(2, 4);
                  var b = value.value.substring(4, 6);
                  var a = value.value.substring(6, 8);
                  return pack(parseInt(r, 16), parseInt(g, 16), parseInt(b, 16), parseInt(a, 16) / 255);
              }
          }
          if (value.type === 20 /* IDENT_TOKEN */) {
              var namedColor = COLORS[value.value.toUpperCase()];
              if (typeof namedColor !== 'undefined') {
                  return namedColor;
              }
          }
          return COLORS.TRANSPARENT;
      }
  };
  var isTransparent = function (color) { return (0xff & color) === 0; };
  var asString = function (color) {
      var alpha = 0xff & color;
      var blue = 0xff & (color >> 8);
      var green = 0xff & (color >> 16);
      var red = 0xff & (color >> 24);
      return alpha < 255 ? "rgba(" + red + "," + green + "," + blue + "," + alpha / 255 + ")" : "rgb(" + red + "," + green + "," + blue + ")";
  };
  var pack = function (r, g, b, a) {
      return ((r << 24) | (g << 16) | (b << 8) | (Math.round(a * 255) << 0)) >>> 0;
  };
  var getTokenColorValue = function (token, i) {
      if (token.type === 17 /* NUMBER_TOKEN */) {
          return token.number;
      }
      if (token.type === 16 /* PERCENTAGE_TOKEN */) {
          var max = i === 3 ? 1 : 255;
          return i === 3 ? (token.number / 100) * max : Math.round((token.number / 100) * max);
      }
      return 0;
  };
  var rgb = function (_context, args) {
      var tokens = args.filter(nonFunctionArgSeparator);
      if (tokens.length === 3) {
          var _a = tokens.map(getTokenColorValue), r = _a[0], g = _a[1], b = _a[2];
          return pack(r, g, b, 1);
      }
      if (tokens.length === 4) {
          var _b = tokens.map(getTokenColorValue), r = _b[0], g = _b[1], b = _b[2], a = _b[3];
          return pack(r, g, b, a);
      }
      return 0;
  };
  function hue2rgb(t1, t2, hue) {
      if (hue < 0) {
          hue += 1;
      }
      if (hue >= 1) {
          hue -= 1;
      }
      if (hue < 1 / 6) {
          return (t2 - t1) * hue * 6 + t1;
      }
      else if (hue < 1 / 2) {
          return t2;
      }
      else if (hue < 2 / 3) {
          return (t2 - t1) * 6 * (2 / 3 - hue) + t1;
      }
      else {
          return t1;
      }
  }
  var hsl = function (context, args) {
      var tokens = args.filter(nonFunctionArgSeparator);
      var hue = tokens[0], saturation = tokens[1], lightness = tokens[2], alpha = tokens[3];
      var h = (hue.type === 17 /* NUMBER_TOKEN */ ? deg(hue.number) : angle.parse(context, hue)) / (Math.PI * 2);
      var s = isLengthPercentage(saturation) ? saturation.number / 100 : 0;
      var l = isLengthPercentage(lightness) ? lightness.number / 100 : 0;
      var a = typeof alpha !== 'undefined' && isLengthPercentage(alpha) ? getAbsoluteValue(alpha, 1) : 1;
      if (s === 0) {
          return pack(l * 255, l * 255, l * 255, 1);
      }
      var t2 = l <= 0.5 ? l * (s + 1) : l + s - l * s;
      var t1 = l * 2 - t2;
      var r = hue2rgb(t1, t2, h + 1 / 3);
      var g = hue2rgb(t1, t2, h);
      var b = hue2rgb(t1, t2, h - 1 / 3);
      return pack(r * 255, g * 255, b * 255, a);
  };
  var SUPPORTED_COLOR_FUNCTIONS = {
      hsl: hsl,
      hsla: hsl,
      rgb: rgb,
      rgba: rgb
  };
  var parseColor = function (context, value) {
      return color$1.parse(context, Parser.create(value).parseComponentValue());
  };
  var COLORS = {
      ALICEBLUE: 0xf0f8ffff,
      ANTIQUEWHITE: 0xfaebd7ff,
      AQUA: 0x00ffffff,
      AQUAMARINE: 0x7fffd4ff,
      AZURE: 0xf0ffffff,
      BEIGE: 0xf5f5dcff,
      BISQUE: 0xffe4c4ff,
      BLACK: 0x000000ff,
      BLANCHEDALMOND: 0xffebcdff,
      BLUE: 0x0000ffff,
      BLUEVIOLET: 0x8a2be2ff,
      BROWN: 0xa52a2aff,
      BURLYWOOD: 0xdeb887ff,
      CADETBLUE: 0x5f9ea0ff,
      CHARTREUSE: 0x7fff00ff,
      CHOCOLATE: 0xd2691eff,
      CORAL: 0xff7f50ff,
      CORNFLOWERBLUE: 0x6495edff,
      CORNSILK: 0xfff8dcff,
      CRIMSON: 0xdc143cff,
      CYAN: 0x00ffffff,
      DARKBLUE: 0x00008bff,
      DARKCYAN: 0x008b8bff,
      DARKGOLDENROD: 0xb886bbff,
      DARKGRAY: 0xa9a9a9ff,
      DARKGREEN: 0x006400ff,
      DARKGREY: 0xa9a9a9ff,
      DARKKHAKI: 0xbdb76bff,
      DARKMAGENTA: 0x8b008bff,
      DARKOLIVEGREEN: 0x556b2fff,
      DARKORANGE: 0xff8c00ff,
      DARKORCHID: 0x9932ccff,
      DARKRED: 0x8b0000ff,
      DARKSALMON: 0xe9967aff,
      DARKSEAGREEN: 0x8fbc8fff,
      DARKSLATEBLUE: 0x483d8bff,
      DARKSLATEGRAY: 0x2f4f4fff,
      DARKSLATEGREY: 0x2f4f4fff,
      DARKTURQUOISE: 0x00ced1ff,
      DARKVIOLET: 0x9400d3ff,
      DEEPPINK: 0xff1493ff,
      DEEPSKYBLUE: 0x00bfffff,
      DIMGRAY: 0x696969ff,
      DIMGREY: 0x696969ff,
      DODGERBLUE: 0x1e90ffff,
      FIREBRICK: 0xb22222ff,
      FLORALWHITE: 0xfffaf0ff,
      FORESTGREEN: 0x228b22ff,
      FUCHSIA: 0xff00ffff,
      GAINSBORO: 0xdcdcdcff,
      GHOSTWHITE: 0xf8f8ffff,
      GOLD: 0xffd700ff,
      GOLDENROD: 0xdaa520ff,
      GRAY: 0x808080ff,
      GREEN: 0x008000ff,
      GREENYELLOW: 0xadff2fff,
      GREY: 0x808080ff,
      HONEYDEW: 0xf0fff0ff,
      HOTPINK: 0xff69b4ff,
      INDIANRED: 0xcd5c5cff,
      INDIGO: 0x4b0082ff,
      IVORY: 0xfffff0ff,
      KHAKI: 0xf0e68cff,
      LAVENDER: 0xe6e6faff,
      LAVENDERBLUSH: 0xfff0f5ff,
      LAWNGREEN: 0x7cfc00ff,
      LEMONCHIFFON: 0xfffacdff,
      LIGHTBLUE: 0xadd8e6ff,
      LIGHTCORAL: 0xf08080ff,
      LIGHTCYAN: 0xe0ffffff,
      LIGHTGOLDENRODYELLOW: 0xfafad2ff,
      LIGHTGRAY: 0xd3d3d3ff,
      LIGHTGREEN: 0x90ee90ff,
      LIGHTGREY: 0xd3d3d3ff,
      LIGHTPINK: 0xffb6c1ff,
      LIGHTSALMON: 0xffa07aff,
      LIGHTSEAGREEN: 0x20b2aaff,
      LIGHTSKYBLUE: 0x87cefaff,
      LIGHTSLATEGRAY: 0x778899ff,
      LIGHTSLATEGREY: 0x778899ff,
      LIGHTSTEELBLUE: 0xb0c4deff,
      LIGHTYELLOW: 0xffffe0ff,
      LIME: 0x00ff00ff,
      LIMEGREEN: 0x32cd32ff,
      LINEN: 0xfaf0e6ff,
      MAGENTA: 0xff00ffff,
      MAROON: 0x800000ff,
      MEDIUMAQUAMARINE: 0x66cdaaff,
      MEDIUMBLUE: 0x0000cdff,
      MEDIUMORCHID: 0xba55d3ff,
      MEDIUMPURPLE: 0x9370dbff,
      MEDIUMSEAGREEN: 0x3cb371ff,
      MEDIUMSLATEBLUE: 0x7b68eeff,
      MEDIUMSPRINGGREEN: 0x00fa9aff,
      MEDIUMTURQUOISE: 0x48d1ccff,
      MEDIUMVIOLETRED: 0xc71585ff,
      MIDNIGHTBLUE: 0x191970ff,
      MINTCREAM: 0xf5fffaff,
      MISTYROSE: 0xffe4e1ff,
      MOCCASIN: 0xffe4b5ff,
      NAVAJOWHITE: 0xffdeadff,
      NAVY: 0x000080ff,
      OLDLACE: 0xfdf5e6ff,
      OLIVE: 0x808000ff,
      OLIVEDRAB: 0x6b8e23ff,
      ORANGE: 0xffa500ff,
      ORANGERED: 0xff4500ff,
      ORCHID: 0xda70d6ff,
      PALEGOLDENROD: 0xeee8aaff,
      PALEGREEN: 0x98fb98ff,
      PALETURQUOISE: 0xafeeeeff,
      PALEVIOLETRED: 0xdb7093ff,
      PAPAYAWHIP: 0xffefd5ff,
      PEACHPUFF: 0xffdab9ff,
      PERU: 0xcd853fff,
      PINK: 0xffc0cbff,
      PLUM: 0xdda0ddff,
      POWDERBLUE: 0xb0e0e6ff,
      PURPLE: 0x800080ff,
      REBECCAPURPLE: 0x663399ff,
      RED: 0xff0000ff,
      ROSYBROWN: 0xbc8f8fff,
      ROYALBLUE: 0x4169e1ff,
      SADDLEBROWN: 0x8b4513ff,
      SALMON: 0xfa8072ff,
      SANDYBROWN: 0xf4a460ff,
      SEAGREEN: 0x2e8b57ff,
      SEASHELL: 0xfff5eeff,
      SIENNA: 0xa0522dff,
      SILVER: 0xc0c0c0ff,
      SKYBLUE: 0x87ceebff,
      SLATEBLUE: 0x6a5acdff,
      SLATEGRAY: 0x708090ff,
      SLATEGREY: 0x708090ff,
      SNOW: 0xfffafaff,
      SPRINGGREEN: 0x00ff7fff,
      STEELBLUE: 0x4682b4ff,
      TAN: 0xd2b48cff,
      TEAL: 0x008080ff,
      THISTLE: 0xd8bfd8ff,
      TOMATO: 0xff6347ff,
      TRANSPARENT: 0x00000000,
      TURQUOISE: 0x40e0d0ff,
      VIOLET: 0xee82eeff,
      WHEAT: 0xf5deb3ff,
      WHITE: 0xffffffff,
      WHITESMOKE: 0xf5f5f5ff,
      YELLOW: 0xffff00ff,
      YELLOWGREEN: 0x9acd32ff
  };

  var backgroundClip = {
      name: 'background-clip',
      initialValue: 'border-box',
      prefix: false,
      type: 1 /* LIST */,
      parse: function (_context, tokens) {
          return tokens.map(function (token) {
              if (isIdentToken(token)) {
                  switch (token.value) {
                      case 'padding-box':
                          return 1 /* PADDING_BOX */;
                      case 'content-box':
                          return 2 /* CONTENT_BOX */;
                  }
              }
              return 0 /* BORDER_BOX */;
          });
      }
  };

  var backgroundColor = {
      name: "background-color",
      initialValue: 'transparent',
      prefix: false,
      type: 3 /* TYPE_VALUE */,
      format: 'color'
  };

  var parseColorStop = function (context, args) {
      var color = color$1.parse(context, args[0]);
      var stop = args[1];
      return stop && isLengthPercentage(stop) ? { color: color, stop: stop } : { color: color, stop: null };
  };
  var processColorStops = function (stops, lineLength) {
      var first = stops[0];
      var last = stops[stops.length - 1];
      if (first.stop === null) {
          first.stop = ZERO_LENGTH;
      }
      if (last.stop === null) {
          last.stop = HUNDRED_PERCENT;
      }
      var processStops = [];
      var previous = 0;
      for (var i = 0; i < stops.length; i++) {
          var stop_1 = stops[i].stop;
          if (stop_1 !== null) {
              var absoluteValue = getAbsoluteValue(stop_1, lineLength);
              if (absoluteValue > previous) {
                  processStops.push(absoluteValue);
              }
              else {
                  processStops.push(previous);
              }
              previous = absoluteValue;
          }
          else {
              processStops.push(null);
          }
      }
      var gapBegin = null;
      for (var i = 0; i < processStops.length; i++) {
          var stop_2 = processStops[i];
          if (stop_2 === null) {
              if (gapBegin === null) {
                  gapBegin = i;
              }
          }
          else if (gapBegin !== null) {
              var gapLength = i - gapBegin;
              var beforeGap = processStops[gapBegin - 1];
              var gapValue = (stop_2 - beforeGap) / (gapLength + 1);
              for (var g = 1; g <= gapLength; g++) {
                  processStops[gapBegin + g - 1] = gapValue * g;
              }
              gapBegin = null;
          }
      }
      return stops.map(function (_a, i) {
          var color = _a.color;
          return { color: color, stop: Math.max(Math.min(1, processStops[i] / lineLength), 0) };
      });
  };
  var getAngleFromCorner = function (corner, width, height) {
      var centerX = width / 2;
      var centerY = height / 2;
      var x = getAbsoluteValue(corner[0], width) - centerX;
      var y = centerY - getAbsoluteValue(corner[1], height);
      return (Math.atan2(y, x) + Math.PI * 2) % (Math.PI * 2);
  };
  var calculateGradientDirection = function (angle, width, height) {
      var radian = typeof angle === 'number' ? angle : getAngleFromCorner(angle, width, height);
      var lineLength = Math.abs(width * Math.sin(radian)) + Math.abs(height * Math.cos(radian));
      var halfWidth = width / 2;
      var halfHeight = height / 2;
      var halfLineLength = lineLength / 2;
      var yDiff = Math.sin(radian - Math.PI / 2) * halfLineLength;
      var xDiff = Math.cos(radian - Math.PI / 2) * halfLineLength;
      return [lineLength, halfWidth - xDiff, halfWidth + xDiff, halfHeight - yDiff, halfHeight + yDiff];
  };
  var distance = function (a, b) { return Math.sqrt(a * a + b * b); };
  var findCorner = function (width, height, x, y, closest) {
      var corners = [
          [0, 0],
          [0, height],
          [width, 0],
          [width, height]
      ];
      return corners.reduce(function (stat, corner) {
          var cx = corner[0], cy = corner[1];
          var d = distance(x - cx, y - cy);
          if (closest ? d < stat.optimumDistance : d > stat.optimumDistance) {
              return {
                  optimumCorner: corner,
                  optimumDistance: d
              };
          }
          return stat;
      }, {
          optimumDistance: closest ? Infinity : -Infinity,
          optimumCorner: null
      }).optimumCorner;
  };
  var calculateRadius = function (gradient, x, y, width, height) {
      var rx = 0;
      var ry = 0;
      switch (gradient.size) {
          case 0 /* CLOSEST_SIDE */:
              // The ending shape is sized so that that it exactly meets the side of the gradient box closest to the gradient’s center.
              // If the shape is an ellipse, it exactly meets the closest side in each dimension.
              if (gradient.shape === 0 /* CIRCLE */) {
                  rx = ry = Math.min(Math.abs(x), Math.abs(x - width), Math.abs(y), Math.abs(y - height));
              }
              else if (gradient.shape === 1 /* ELLIPSE */) {
                  rx = Math.min(Math.abs(x), Math.abs(x - width));
                  ry = Math.min(Math.abs(y), Math.abs(y - height));
              }
              break;
          case 2 /* CLOSEST_CORNER */:
              // The ending shape is sized so that that it passes through the corner of the gradient box closest to the gradient’s center.
              // If the shape is an ellipse, the ending shape is given the same aspect-ratio it would have if closest-side were specified.
              if (gradient.shape === 0 /* CIRCLE */) {
                  rx = ry = Math.min(distance(x, y), distance(x, y - height), distance(x - width, y), distance(x - width, y - height));
              }
              else if (gradient.shape === 1 /* ELLIPSE */) {
                  // Compute the ratio ry/rx (which is to be the same as for "closest-side")
                  var c = Math.min(Math.abs(y), Math.abs(y - height)) / Math.min(Math.abs(x), Math.abs(x - width));
                  var _a = findCorner(width, height, x, y, true), cx = _a[0], cy = _a[1];
                  rx = distance(cx - x, (cy - y) / c);
                  ry = c * rx;
              }
              break;
          case 1 /* FARTHEST_SIDE */:
              // Same as closest-side, except the ending shape is sized based on the farthest side(s)
              if (gradient.shape === 0 /* CIRCLE */) {
                  rx = ry = Math.max(Math.abs(x), Math.abs(x - width), Math.abs(y), Math.abs(y - height));
              }
              else if (gradient.shape === 1 /* ELLIPSE */) {
                  rx = Math.max(Math.abs(x), Math.abs(x - width));
                  ry = Math.max(Math.abs(y), Math.abs(y - height));
              }
              break;
          case 3 /* FARTHEST_CORNER */:
              // Same as closest-corner, except the ending shape is sized based on the farthest corner.
              // If the shape is an ellipse, the ending shape is given the same aspect ratio it would have if farthest-side were specified.
              if (gradient.shape === 0 /* CIRCLE */) {
                  rx = ry = Math.max(distance(x, y), distance(x, y - height), distance(x - width, y), distance(x - width, y - height));
              }
              else if (gradient.shape === 1 /* ELLIPSE */) {
                  // Compute the ratio ry/rx (which is to be the same as for "farthest-side")
                  var c = Math.max(Math.abs(y), Math.abs(y - height)) / Math.max(Math.abs(x), Math.abs(x - width));
                  var _b = findCorner(width, height, x, y, false), cx = _b[0], cy = _b[1];
                  rx = distance(cx - x, (cy - y) / c);
                  ry = c * rx;
              }
              break;
      }
      if (Array.isArray(gradient.size)) {
          rx = getAbsoluteValue(gradient.size[0], width);
          ry = gradient.size.length === 2 ? getAbsoluteValue(gradient.size[1], height) : rx;
      }
      return [rx, ry];
  };

  var linearGradient = function (context, tokens) {
      var angle$1 = deg(180);
      var stops = [];
      parseFunctionArgs(tokens).forEach(function (arg, i) {
          if (i === 0) {
              var firstToken = arg[0];
              if (firstToken.type === 20 /* IDENT_TOKEN */ && firstToken.value === 'to') {
                  angle$1 = parseNamedSide(arg);
                  return;
              }
              else if (isAngle(firstToken)) {
                  angle$1 = angle.parse(context, firstToken);
                  return;
              }
          }
          var colorStop = parseColorStop(context, arg);
          stops.push(colorStop);
      });
      return { angle: angle$1, stops: stops, type: 1 /* LINEAR_GRADIENT */ };
  };

  var prefixLinearGradient = function (context, tokens) {
      var angle$1 = deg(180);
      var stops = [];
      parseFunctionArgs(tokens).forEach(function (arg, i) {
          if (i === 0) {
              var firstToken = arg[0];
              if (firstToken.type === 20 /* IDENT_TOKEN */ &&
                  ['top', 'left', 'right', 'bottom'].indexOf(firstToken.value) !== -1) {
                  angle$1 = parseNamedSide(arg);
                  return;
              }
              else if (isAngle(firstToken)) {
                  angle$1 = (angle.parse(context, firstToken) + deg(270)) % deg(360);
                  return;
              }
          }
          var colorStop = parseColorStop(context, arg);
          stops.push(colorStop);
      });
      return {
          angle: angle$1,
          stops: stops,
          type: 1 /* LINEAR_GRADIENT */
      };
  };

  var webkitGradient = function (context, tokens) {
      var angle = deg(180);
      var stops = [];
      var type = 1 /* LINEAR_GRADIENT */;
      var shape = 0 /* CIRCLE */;
      var size = 3 /* FARTHEST_CORNER */;
      var position = [];
      parseFunctionArgs(tokens).forEach(function (arg, i) {
          var firstToken = arg[0];
          if (i === 0) {
              if (isIdentToken(firstToken) && firstToken.value === 'linear') {
                  type = 1 /* LINEAR_GRADIENT */;
                  return;
              }
              else if (isIdentToken(firstToken) && firstToken.value === 'radial') {
                  type = 2 /* RADIAL_GRADIENT */;
                  return;
              }
          }
          if (firstToken.type === 18 /* FUNCTION */) {
              if (firstToken.name === 'from') {
                  var color = color$1.parse(context, firstToken.values[0]);
                  stops.push({ stop: ZERO_LENGTH, color: color });
              }
              else if (firstToken.name === 'to') {
                  var color = color$1.parse(context, firstToken.values[0]);
                  stops.push({ stop: HUNDRED_PERCENT, color: color });
              }
              else if (firstToken.name === 'color-stop') {
                  var values = firstToken.values.filter(nonFunctionArgSeparator);
                  if (values.length === 2) {
                      var color = color$1.parse(context, values[1]);
                      var stop_1 = values[0];
                      if (isNumberToken(stop_1)) {
                          stops.push({
                              stop: { type: 16 /* PERCENTAGE_TOKEN */, number: stop_1.number * 100, flags: stop_1.flags },
                              color: color
                          });
                      }
                  }
              }
          }
      });
      return type === 1 /* LINEAR_GRADIENT */
          ? {
              angle: (angle + deg(180)) % deg(360),
              stops: stops,
              type: type
          }
          : { size: size, shape: shape, stops: stops, position: position, type: type };
  };

  var CLOSEST_SIDE = 'closest-side';
  var FARTHEST_SIDE = 'farthest-side';
  var CLOSEST_CORNER = 'closest-corner';
  var FARTHEST_CORNER = 'farthest-corner';
  var CIRCLE = 'circle';
  var ELLIPSE = 'ellipse';
  var COVER = 'cover';
  var CONTAIN = 'contain';
  var radialGradient = function (context, tokens) {
      var shape = 0 /* CIRCLE */;
      var size = 3 /* FARTHEST_CORNER */;
      var stops = [];
      var position = [];
      parseFunctionArgs(tokens).forEach(function (arg, i) {
          var isColorStop = true;
          if (i === 0) {
              var isAtPosition_1 = false;
              isColorStop = arg.reduce(function (acc, token) {
                  if (isAtPosition_1) {
                      if (isIdentToken(token)) {
                          switch (token.value) {
                              case 'center':
                                  position.push(FIFTY_PERCENT);
                                  return acc;
                              case 'top':
                              case 'left':
                                  position.push(ZERO_LENGTH);
                                  return acc;
                              case 'right':
                              case 'bottom':
                                  position.push(HUNDRED_PERCENT);
                                  return acc;
                          }
                      }
                      else if (isLengthPercentage(token) || isLength(token)) {
                          position.push(token);
                      }
                  }
                  else if (isIdentToken(token)) {
                      switch (token.value) {
                          case CIRCLE:
                              shape = 0 /* CIRCLE */;
                              return false;
                          case ELLIPSE:
                              shape = 1 /* ELLIPSE */;
                              return false;
                          case 'at':
                              isAtPosition_1 = true;
                              return false;
                          case CLOSEST_SIDE:
                              size = 0 /* CLOSEST_SIDE */;
                              return false;
                          case COVER:
                          case FARTHEST_SIDE:
                              size = 1 /* FARTHEST_SIDE */;
                              return false;
                          case CONTAIN:
                          case CLOSEST_CORNER:
                              size = 2 /* CLOSEST_CORNER */;
                              return false;
                          case FARTHEST_CORNER:
                              size = 3 /* FARTHEST_CORNER */;
                              return false;
                      }
                  }
                  else if (isLength(token) || isLengthPercentage(token)) {
                      if (!Array.isArray(size)) {
                          size = [];
                      }
                      size.push(token);
                      return false;
                  }
                  return acc;
              }, isColorStop);
          }
          if (isColorStop) {
              var colorStop = parseColorStop(context, arg);
              stops.push(colorStop);
          }
      });
      return { size: size, shape: shape, stops: stops, position: position, type: 2 /* RADIAL_GRADIENT */ };
  };

  var prefixRadialGradient = function (context, tokens) {
      var shape = 0 /* CIRCLE */;
      var size = 3 /* FARTHEST_CORNER */;
      var stops = [];
      var position = [];
      parseFunctionArgs(tokens).forEach(function (arg, i) {
          var isColorStop = true;
          if (i === 0) {
              isColorStop = arg.reduce(function (acc, token) {
                  if (isIdentToken(token)) {
                      switch (token.value) {
                          case 'center':
                              position.push(FIFTY_PERCENT);
                              return false;
                          case 'top':
                          case 'left':
                              position.push(ZERO_LENGTH);
                              return false;
                          case 'right':
                          case 'bottom':
                              position.push(HUNDRED_PERCENT);
                              return false;
                      }
                  }
                  else if (isLengthPercentage(token) || isLength(token)) {
                      position.push(token);
                      return false;
                  }
                  return acc;
              }, isColorStop);
          }
          else if (i === 1) {
              isColorStop = arg.reduce(function (acc, token) {
                  if (isIdentToken(token)) {
                      switch (token.value) {
                          case CIRCLE:
                              shape = 0 /* CIRCLE */;
                              return false;
                          case ELLIPSE:
                              shape = 1 /* ELLIPSE */;
                              return false;
                          case CONTAIN:
                          case CLOSEST_SIDE:
                              size = 0 /* CLOSEST_SIDE */;
                              return false;
                          case FARTHEST_SIDE:
                              size = 1 /* FARTHEST_SIDE */;
                              return false;
                          case CLOSEST_CORNER:
                              size = 2 /* CLOSEST_CORNER */;
                              return false;
                          case COVER:
                          case FARTHEST_CORNER:
                              size = 3 /* FARTHEST_CORNER */;
                              return false;
                      }
                  }
                  else if (isLength(token) || isLengthPercentage(token)) {
                      if (!Array.isArray(size)) {
                          size = [];
                      }
                      size.push(token);
                      return false;
                  }
                  return acc;
              }, isColorStop);
          }
          if (isColorStop) {
              var colorStop = parseColorStop(context, arg);
              stops.push(colorStop);
          }
      });
      return { size: size, shape: shape, stops: stops, position: position, type: 2 /* RADIAL_GRADIENT */ };
  };

  var isLinearGradient = function (background) {
      return background.type === 1 /* LINEAR_GRADIENT */;
  };
  var isRadialGradient = function (background) {
      return background.type === 2 /* RADIAL_GRADIENT */;
  };
  var image = {
      name: 'image',
      parse: function (context, value) {
          if (value.type === 22 /* URL_TOKEN */) {
              var image_1 = { url: value.value, type: 0 /* URL */ };
              context.cache.addImage(value.value);
              return image_1;
          }
          if (value.type === 18 /* FUNCTION */) {
              var imageFunction = SUPPORTED_IMAGE_FUNCTIONS[value.name];
              if (typeof imageFunction === 'undefined') {
                  throw new Error("Attempting to parse an unsupported image function \"" + value.name + "\"");
              }
              return imageFunction(context, value.values);
          }
          throw new Error("Unsupported image type " + value.type);
      }
  };
  function isSupportedImage(value) {
      return (!(value.type === 20 /* IDENT_TOKEN */ && value.value === 'none') &&
          (value.type !== 18 /* FUNCTION */ || !!SUPPORTED_IMAGE_FUNCTIONS[value.name]));
  }
  var SUPPORTED_IMAGE_FUNCTIONS = {
      'linear-gradient': linearGradient,
      '-moz-linear-gradient': prefixLinearGradient,
      '-ms-linear-gradient': prefixLinearGradient,
      '-o-linear-gradient': prefixLinearGradient,
      '-webkit-linear-gradient': prefixLinearGradient,
      'radial-gradient': radialGradient,
      '-moz-radial-gradient': prefixRadialGradient,
      '-ms-radial-gradient': prefixRadialGradient,
      '-o-radial-gradient': prefixRadialGradient,
      '-webkit-radial-gradient': prefixRadialGradient,
      '-webkit-gradient': webkitGradient
  };

  var backgroundImage = {
      name: 'background-image',
      initialValue: 'none',
      type: 1 /* LIST */,
      prefix: false,
      parse: function (context, tokens) {
          if (tokens.length === 0) {
              return [];
          }
          var first = tokens[0];
          if (first.type === 20 /* IDENT_TOKEN */ && first.value === 'none') {
              return [];
          }
          return tokens
              .filter(function (value) { return nonFunctionArgSeparator(value) && isSupportedImage(value); })
              .map(function (value) { return image.parse(context, value); });
      }
  };

  var backgroundOrigin = {
      name: 'background-origin',
      initialValue: 'border-box',
      prefix: false,
      type: 1 /* LIST */,
      parse: function (_context, tokens) {
          return tokens.map(function (token) {
              if (isIdentToken(token)) {
                  switch (token.value) {
                      case 'padding-box':
                          return 1 /* PADDING_BOX */;
                      case 'content-box':
                          return 2 /* CONTENT_BOX */;
                  }
              }
              return 0 /* BORDER_BOX */;
          });
      }
  };

  var backgroundPosition = {
      name: 'background-position',
      initialValue: '0% 0%',
      type: 1 /* LIST */,
      prefix: false,
      parse: function (_context, tokens) {
          return parseFunctionArgs(tokens)
              .map(function (values) { return values.filter(isLengthPercentage); })
              .map(parseLengthPercentageTuple);
      }
  };

  var backgroundRepeat = {
      name: 'background-repeat',
      initialValue: 'repeat',
      prefix: false,
      type: 1 /* LIST */,
      parse: function (_context, tokens) {
          return parseFunctionArgs(tokens)
              .map(function (values) {
              return values
                  .filter(isIdentToken)
                  .map(function (token) { return token.value; })
                  .join(' ');
          })
              .map(parseBackgroundRepeat);
      }
  };
  var parseBackgroundRepeat = function (value) {
      switch (value) {
          case 'no-repeat':
              return 1 /* NO_REPEAT */;
          case 'repeat-x':
          case 'repeat no-repeat':
              return 2 /* REPEAT_X */;
          case 'repeat-y':
          case 'no-repeat repeat':
              return 3 /* REPEAT_Y */;
          case 'repeat':
          default:
              return 0 /* REPEAT */;
      }
  };

  var BACKGROUND_SIZE;
  (function (BACKGROUND_SIZE) {
      BACKGROUND_SIZE["AUTO"] = "auto";
      BACKGROUND_SIZE["CONTAIN"] = "contain";
      BACKGROUND_SIZE["COVER"] = "cover";
  })(BACKGROUND_SIZE || (BACKGROUND_SIZE = {}));
  var backgroundSize = {
      name: 'background-size',
      initialValue: '0',
      prefix: false,
      type: 1 /* LIST */,
      parse: function (_context, tokens) {
          return parseFunctionArgs(tokens).map(function (values) { return values.filter(isBackgroundSizeInfoToken); });
      }
  };
  var isBackgroundSizeInfoToken = function (value) {
      return isIdentToken(value) || isLengthPercentage(value);
  };

  var borderColorForSide = function (side) { return ({
      name: "border-" + side + "-color",
      initialValue: 'transparent',
      prefix: false,
      type: 3 /* TYPE_VALUE */,
      format: 'color'
  }); };
  var borderTopColor = borderColorForSide('top');
  var borderRightColor = borderColorForSide('right');
  var borderBottomColor = borderColorForSide('bottom');
  var borderLeftColor = borderColorForSide('left');

  var borderRadiusForSide = function (side) { return ({
      name: "border-radius-" + side,
      initialValue: '0 0',
      prefix: false,
      type: 1 /* LIST */,
      parse: function (_context, tokens) {
          return parseLengthPercentageTuple(tokens.filter(isLengthPercentage));
      }
  }); };
  var borderTopLeftRadius = borderRadiusForSide('top-left');
  var borderTopRightRadius = borderRadiusForSide('top-right');
  var borderBottomRightRadius = borderRadiusForSide('bottom-right');
  var borderBottomLeftRadius = borderRadiusForSide('bottom-left');

  var borderStyleForSide = function (side) { return ({
      name: "border-" + side + "-style",
      initialValue: 'solid',
      prefix: false,
      type: 2 /* IDENT_VALUE */,
      parse: function (_context, style) {
          switch (style) {
              case 'none':
                  return 0 /* NONE */;
              case 'dashed':
                  return 2 /* DASHED */;
              case 'dotted':
                  return 3 /* DOTTED */;
              case 'double':
                  return 4 /* DOUBLE */;
          }
          return 1 /* SOLID */;
      }
  }); };
  var borderTopStyle = borderStyleForSide('top');
  var borderRightStyle = borderStyleForSide('right');
  var borderBottomStyle = borderStyleForSide('bottom');
  var borderLeftStyle = borderStyleForSide('left');

  var borderWidthForSide = function (side) { return ({
      name: "border-" + side + "-width",
      initialValue: '0',
      type: 0 /* VALUE */,
      prefix: false,
      parse: function (_context, token) {
          if (isDimensionToken(token)) {
              return token.number;
          }
          return 0;
      }
  }); };
  var borderTopWidth = borderWidthForSide('top');
  var borderRightWidth = borderWidthForSide('right');
  var borderBottomWidth = borderWidthForSide('bottom');
  var borderLeftWidth = borderWidthForSide('left');

  var color = {
      name: "color",
      initialValue: 'transparent',
      prefix: false,
      type: 3 /* TYPE_VALUE */,
      format: 'color'
  };

  var direction = {
      name: 'direction',
      initialValue: 'ltr',
      prefix: false,
      type: 2 /* IDENT_VALUE */,
      parse: function (_context, direction) {
          switch (direction) {
              case 'rtl':
                  return 1 /* RTL */;
              case 'ltr':
              default:
                  return 0 /* LTR */;
          }
      }
  };

  var display = {
      name: 'display',
      initialValue: 'inline-block',
      prefix: false,
      type: 1 /* LIST */,
      parse: function (_context, tokens) {
          return tokens.filter(isIdentToken).reduce(function (bit, token) {
              return bit | parseDisplayValue(token.value);
          }, 0 /* NONE */);
      }
  };
  var parseDisplayValue = function (display) {
      switch (display) {
          case 'block':
          case '-webkit-box':
              return 2 /* BLOCK */;
          case 'inline':
              return 4 /* INLINE */;
          case 'run-in':
              return 8 /* RUN_IN */;
          case 'flow':
              return 16 /* FLOW */;
          case 'flow-root':
              return 32 /* FLOW_ROOT */;
          case 'table':
              return 64 /* TABLE */;
          case 'flex':
          case '-webkit-flex':
              return 128 /* FLEX */;
          case 'grid':
          case '-ms-grid':
              return 256 /* GRID */;
          case 'ruby':
              return 512 /* RUBY */;
          case 'subgrid':
              return 1024 /* SUBGRID */;
          case 'list-item':
              return 2048 /* LIST_ITEM */;
          case 'table-row-group':
              return 4096 /* TABLE_ROW_GROUP */;
          case 'table-header-group':
              return 8192 /* TABLE_HEADER_GROUP */;
          case 'table-footer-group':
              return 16384 /* TABLE_FOOTER_GROUP */;
          case 'table-row':
              return 32768 /* TABLE_ROW */;
          case 'table-cell':
              return 65536 /* TABLE_CELL */;
          case 'table-column-group':
              return 131072 /* TABLE_COLUMN_GROUP */;
          case 'table-column':
              return 262144 /* TABLE_COLUMN */;
          case 'table-caption':
              return 524288 /* TABLE_CAPTION */;
          case 'ruby-base':
              return 1048576 /* RUBY_BASE */;
          case 'ruby-text':
              return 2097152 /* RUBY_TEXT */;
          case 'ruby-base-container':
              return 4194304 /* RUBY_BASE_CONTAINER */;
          case 'ruby-text-container':
              return 8388608 /* RUBY_TEXT_CONTAINER */;
          case 'contents':
              return 16777216 /* CONTENTS */;
          case 'inline-block':
              return 33554432 /* INLINE_BLOCK */;
          case 'inline-list-item':
              return 67108864 /* INLINE_LIST_ITEM */;
          case 'inline-table':
              return 134217728 /* INLINE_TABLE */;
          case 'inline-flex':
              return 268435456 /* INLINE_FLEX */;
          case 'inline-grid':
              return 536870912 /* INLINE_GRID */;
      }
      return 0 /* NONE */;
  };

  var float = {
      name: 'float',
      initialValue: 'none',
      prefix: false,
      type: 2 /* IDENT_VALUE */,
      parse: function (_context, float) {
          switch (float) {
              case 'left':
                  return 1 /* LEFT */;
              case 'right':
                  return 2 /* RIGHT */;
              case 'inline-start':
                  return 3 /* INLINE_START */;
              case 'inline-end':
                  return 4 /* INLINE_END */;
          }
          return 0 /* NONE */;
      }
  };

  var letterSpacing = {
      name: 'letter-spacing',
      initialValue: '0',
      prefix: false,
      type: 0 /* VALUE */,
      parse: function (_context, token) {
          if (token.type === 20 /* IDENT_TOKEN */ && token.value === 'normal') {
              return 0;
          }
          if (token.type === 17 /* NUMBER_TOKEN */) {
              return token.number;
          }
          if (token.type === 15 /* DIMENSION_TOKEN */) {
              return token.number;
          }
          return 0;
      }
  };

  var LINE_BREAK;
  (function (LINE_BREAK) {
      LINE_BREAK["NORMAL"] = "normal";
      LINE_BREAK["STRICT"] = "strict";
  })(LINE_BREAK || (LINE_BREAK = {}));
  var lineBreak = {
      name: 'line-break',
      initialValue: 'normal',
      prefix: false,
      type: 2 /* IDENT_VALUE */,
      parse: function (_context, lineBreak) {
          switch (lineBreak) {
              case 'strict':
                  return LINE_BREAK.STRICT;
              case 'normal':
              default:
                  return LINE_BREAK.NORMAL;
          }
      }
  };

  var lineHeight = {
      name: 'line-height',
      initialValue: 'normal',
      prefix: false,
      type: 4 /* TOKEN_VALUE */
  };
  var computeLineHeight = function (token, fontSize) {
      if (isIdentToken(token) && token.value === 'normal') {
          return 1.2 * fontSize;
      }
      else if (token.type === 17 /* NUMBER_TOKEN */) {
          return fontSize * token.number;
      }
      else if (isLengthPercentage(token)) {
          return getAbsoluteValue(token, fontSize);
      }
      return fontSize;
  };

  var listStyleImage = {
      name: 'list-style-image',
      initialValue: 'none',
      type: 0 /* VALUE */,
      prefix: false,
      parse: function (context, token) {
          if (token.type === 20 /* IDENT_TOKEN */ && token.value === 'none') {
              return null;
          }
          return image.parse(context, token);
      }
  };

  var listStylePosition = {
      name: 'list-style-position',
      initialValue: 'outside',
      prefix: false,
      type: 2 /* IDENT_VALUE */,
      parse: function (_context, position) {
          switch (position) {
              case 'inside':
                  return 0 /* INSIDE */;
              case 'outside':
              default:
                  return 1 /* OUTSIDE */;
          }
      }
  };

  var listStyleType = {
      name: 'list-style-type',
      initialValue: 'none',
      prefix: false,
      type: 2 /* IDENT_VALUE */,
      parse: function (_context, type) {
          switch (type) {
              case 'disc':
                  return 0 /* DISC */;
              case 'circle':
                  return 1 /* CIRCLE */;
              case 'square':
                  return 2 /* SQUARE */;
              case 'decimal':
                  return 3 /* DECIMAL */;
              case 'cjk-decimal':
                  return 4 /* CJK_DECIMAL */;
              case 'decimal-leading-zero':
                  return 5 /* DECIMAL_LEADING_ZERO */;
              case 'lower-roman':
                  return 6 /* LOWER_ROMAN */;
              case 'upper-roman':
                  return 7 /* UPPER_ROMAN */;
              case 'lower-greek':
                  return 8 /* LOWER_GREEK */;
              case 'lower-alpha':
                  return 9 /* LOWER_ALPHA */;
              case 'upper-alpha':
                  return 10 /* UPPER_ALPHA */;
              case 'arabic-indic':
                  return 11 /* ARABIC_INDIC */;
              case 'armenian':
                  return 12 /* ARMENIAN */;
              case 'bengali':
                  return 13 /* BENGALI */;
              case 'cambodian':
                  return 14 /* CAMBODIAN */;
              case 'cjk-earthly-branch':
                  return 15 /* CJK_EARTHLY_BRANCH */;
              case 'cjk-heavenly-stem':
                  return 16 /* CJK_HEAVENLY_STEM */;
              case 'cjk-ideographic':
                  return 17 /* CJK_IDEOGRAPHIC */;
              case 'devanagari':
                  return 18 /* DEVANAGARI */;
              case 'ethiopic-numeric':
                  return 19 /* ETHIOPIC_NUMERIC */;
              case 'georgian':
                  return 20 /* GEORGIAN */;
              case 'gujarati':
                  return 21 /* GUJARATI */;
              case 'gurmukhi':
                  return 22 /* GURMUKHI */;
              case 'hebrew':
                  return 22 /* HEBREW */;
              case 'hiragana':
                  return 23 /* HIRAGANA */;
              case 'hiragana-iroha':
                  return 24 /* HIRAGANA_IROHA */;
              case 'japanese-formal':
                  return 25 /* JAPANESE_FORMAL */;
              case 'japanese-informal':
                  return 26 /* JAPANESE_INFORMAL */;
              case 'kannada':
                  return 27 /* KANNADA */;
              case 'katakana':
                  return 28 /* KATAKANA */;
              case 'katakana-iroha':
                  return 29 /* KATAKANA_IROHA */;
              case 'khmer':
                  return 30 /* KHMER */;
              case 'korean-hangul-formal':
                  return 31 /* KOREAN_HANGUL_FORMAL */;
              case 'korean-hanja-formal':
                  return 32 /* KOREAN_HANJA_FORMAL */;
              case 'korean-hanja-informal':
                  return 33 /* KOREAN_HANJA_INFORMAL */;
              case 'lao':
                  return 34 /* LAO */;
              case 'lower-armenian':
                  return 35 /* LOWER_ARMENIAN */;
              case 'malayalam':
                  return 36 /* MALAYALAM */;
              case 'mongolian':
                  return 37 /* MONGOLIAN */;
              case 'myanmar':
                  return 38 /* MYANMAR */;
              case 'oriya':
                  return 39 /* ORIYA */;
              case 'persian':
                  return 40 /* PERSIAN */;
              case 'simp-chinese-formal':
                  return 41 /* SIMP_CHINESE_FORMAL */;
              case 'simp-chinese-informal':
                  return 42 /* SIMP_CHINESE_INFORMAL */;
              case 'tamil':
                  return 43 /* TAMIL */;
              case 'telugu':
                  return 44 /* TELUGU */;
              case 'thai':
                  return 45 /* THAI */;
              case 'tibetan':
                  return 46 /* TIBETAN */;
              case 'trad-chinese-formal':
                  return 47 /* TRAD_CHINESE_FORMAL */;
              case 'trad-chinese-informal':
                  return 48 /* TRAD_CHINESE_INFORMAL */;
              case 'upper-armenian':
                  return 49 /* UPPER_ARMENIAN */;
              case 'disclosure-open':
                  return 50 /* DISCLOSURE_OPEN */;
              case 'disclosure-closed':
                  return 51 /* DISCLOSURE_CLOSED */;
              case 'none':
              default:
                  return -1 /* NONE */;
          }
      }
  };

  var marginForSide = function (side) { return ({
      name: "margin-" + side,
      initialValue: '0',
      prefix: false,
      type: 4 /* TOKEN_VALUE */
  }); };
  var marginTop = marginForSide('top');
  var marginRight = marginForSide('right');
  var marginBottom = marginForSide('bottom');
  var marginLeft = marginForSide('left');

  var overflow = {
      name: 'overflow',
      initialValue: 'visible',
      prefix: false,
      type: 1 /* LIST */,
      parse: function (_context, tokens) {
          return tokens.filter(isIdentToken).map(function (overflow) {
              switch (overflow.value) {
                  case 'hidden':
                      return 1 /* HIDDEN */;
                  case 'scroll':
                      return 2 /* SCROLL */;
                  case 'clip':
                      return 3 /* CLIP */;
                  case 'auto':
                      return 4 /* AUTO */;
                  case 'visible':
                  default:
                      return 0 /* VISIBLE */;
              }
          });
      }
  };

  var overflowWrap = {
      name: 'overflow-wrap',
      initialValue: 'normal',
      prefix: false,
      type: 2 /* IDENT_VALUE */,
      parse: function (_context, overflow) {
          switch (overflow) {
              case 'break-word':
                  return "break-word" /* BREAK_WORD */;
              case 'normal':
              default:
                  return "normal" /* NORMAL */;
          }
      }
  };

  var paddingForSide = function (side) { return ({
      name: "padding-" + side,
      initialValue: '0',
      prefix: false,
      type: 3 /* TYPE_VALUE */,
      format: 'length-percentage'
  }); };
  var paddingTop = paddingForSide('top');
  var paddingRight = paddingForSide('right');
  var paddingBottom = paddingForSide('bottom');
  var paddingLeft = paddingForSide('left');

  var textAlign = {
      name: 'text-align',
      initialValue: 'left',
      prefix: false,
      type: 2 /* IDENT_VALUE */,
      parse: function (_context, textAlign) {
          switch (textAlign) {
              case 'right':
                  return 2 /* RIGHT */;
              case 'center':
              case 'justify':
                  return 1 /* CENTER */;
              case 'left':
              default:
                  return 0 /* LEFT */;
          }
      }
  };

  var position = {
      name: 'position',
      initialValue: 'static',
      prefix: false,
      type: 2 /* IDENT_VALUE */,
      parse: function (_context, position) {
          switch (position) {
              case 'relative':
                  return 1 /* RELATIVE */;
              case 'absolute':
                  return 2 /* ABSOLUTE */;
              case 'fixed':
                  return 3 /* FIXED */;
              case 'sticky':
                  return 4 /* STICKY */;
          }
          return 0 /* STATIC */;
      }
  };

  var textShadow = {
      name: 'text-shadow',
      initialValue: 'none',
      type: 1 /* LIST */,
      prefix: false,
      parse: function (context, tokens) {
          if (tokens.length === 1 && isIdentWithValue(tokens[0], 'none')) {
              return [];
          }
          return parseFunctionArgs(tokens).map(function (values) {
              var shadow = {
                  color: COLORS.TRANSPARENT,
                  offsetX: ZERO_LENGTH,
                  offsetY: ZERO_LENGTH,
                  blur: ZERO_LENGTH
              };
              var c = 0;
              for (var i = 0; i < values.length; i++) {
                  var token = values[i];
                  if (isLength(token)) {
                      if (c === 0) {
                          shadow.offsetX = token;
                      }
                      else if (c === 1) {
                          shadow.offsetY = token;
                      }
                      else {
                          shadow.blur = token;
                      }
                      c++;
                  }
                  else {
                      shadow.color = color$1.parse(context, token);
                  }
              }
              return shadow;
          });
      }
  };

  var textTransform = {
      name: 'text-transform',
      initialValue: 'none',
      prefix: false,
      type: 2 /* IDENT_VALUE */,
      parse: function (_context, textTransform) {
          switch (textTransform) {
              case 'uppercase':
                  return 2 /* UPPERCASE */;
              case 'lowercase':
                  return 1 /* LOWERCASE */;
              case 'capitalize':
                  return 3 /* CAPITALIZE */;
          }
          return 0 /* NONE */;
      }
  };

  var transform$1 = {
      name: 'transform',
      initialValue: 'none',
      prefix: true,
      type: 0 /* VALUE */,
      parse: function (_context, token) {
          if (token.type === 20 /* IDENT_TOKEN */ && token.value === 'none') {
              return null;
          }
          if (token.type === 18 /* FUNCTION */) {
              var transformFunction = SUPPORTED_TRANSFORM_FUNCTIONS[token.name];
              if (typeof transformFunction === 'undefined') {
                  throw new Error("Attempting to parse an unsupported transform function \"" + token.name + "\"");
              }
              return transformFunction(token.values);
          }
          return null;
      }
  };
  var matrix = function (args) {
      var values = args.filter(function (arg) { return arg.type === 17 /* NUMBER_TOKEN */; }).map(function (arg) { return arg.number; });
      return values.length === 6 ? values : null;
  };
  // doesn't support 3D transforms at the moment
  var matrix3d = function (args) {
      var values = args.filter(function (arg) { return arg.type === 17 /* NUMBER_TOKEN */; }).map(function (arg) { return arg.number; });
      var a1 = values[0], b1 = values[1]; values[2]; values[3]; var a2 = values[4], b2 = values[5]; values[6]; values[7]; values[8]; values[9]; values[10]; values[11]; var a4 = values[12], b4 = values[13]; values[14]; values[15];
      return values.length === 16 ? [a1, b1, a2, b2, a4, b4] : null;
  };
  var SUPPORTED_TRANSFORM_FUNCTIONS = {
      matrix: matrix,
      matrix3d: matrix3d
  };

  var DEFAULT_VALUE = {
      type: 16 /* PERCENTAGE_TOKEN */,
      number: 50,
      flags: FLAG_INTEGER
  };
  var DEFAULT = [DEFAULT_VALUE, DEFAULT_VALUE];
  var transformOrigin = {
      name: 'transform-origin',
      initialValue: '50% 50%',
      prefix: true,
      type: 1 /* LIST */,
      parse: function (_context, tokens) {
          var origins = tokens.filter(isLengthPercentage);
          if (origins.length !== 2) {
              return DEFAULT;
          }
          return [origins[0], origins[1]];
      }
  };

  var visibility = {
      name: 'visible',
      initialValue: 'none',
      prefix: false,
      type: 2 /* IDENT_VALUE */,
      parse: function (_context, visibility) {
          switch (visibility) {
              case 'hidden':
                  return 1 /* HIDDEN */;
              case 'collapse':
                  return 2 /* COLLAPSE */;
              case 'visible':
              default:
                  return 0 /* VISIBLE */;
          }
      }
  };

  var WORD_BREAK;
  (function (WORD_BREAK) {
      WORD_BREAK["NORMAL"] = "normal";
      WORD_BREAK["BREAK_ALL"] = "break-all";
      WORD_BREAK["KEEP_ALL"] = "keep-all";
  })(WORD_BREAK || (WORD_BREAK = {}));
  var wordBreak = {
      name: 'word-break',
      initialValue: 'normal',
      prefix: false,
      type: 2 /* IDENT_VALUE */,
      parse: function (_context, wordBreak) {
          switch (wordBreak) {
              case 'break-all':
                  return WORD_BREAK.BREAK_ALL;
              case 'keep-all':
                  return WORD_BREAK.KEEP_ALL;
              case 'normal':
              default:
                  return WORD_BREAK.NORMAL;
          }
      }
  };

  var zIndex = {
      name: 'z-index',
      initialValue: 'auto',
      prefix: false,
      type: 0 /* VALUE */,
      parse: function (_context, token) {
          if (token.type === 20 /* IDENT_TOKEN */) {
              return { auto: true, order: 0 };
          }
          if (isNumberToken(token)) {
              return { auto: false, order: token.number };
          }
          throw new Error("Invalid z-index number parsed");
      }
  };

  var time = {
      name: 'time',
      parse: function (_context, value) {
          if (value.type === 15 /* DIMENSION_TOKEN */) {
              switch (value.unit.toLowerCase()) {
                  case 's':
                      return 1000 * value.number;
                  case 'ms':
                      return value.number;
              }
          }
          throw new Error("Unsupported time type");
      }
  };

  var opacity = {
      name: 'opacity',
      initialValue: '1',
      type: 0 /* VALUE */,
      prefix: false,
      parse: function (_context, token) {
          if (isNumberToken(token)) {
              return token.number;
          }
          return 1;
      }
  };

  var textDecorationColor = {
      name: "text-decoration-color",
      initialValue: 'transparent',
      prefix: false,
      type: 3 /* TYPE_VALUE */,
      format: 'color'
  };

  var textDecorationLine = {
      name: 'text-decoration-line',
      initialValue: 'none',
      prefix: false,
      type: 1 /* LIST */,
      parse: function (_context, tokens) {
          return tokens
              .filter(isIdentToken)
              .map(function (token) {
              switch (token.value) {
                  case 'underline':
                      return 1 /* UNDERLINE */;
                  case 'overline':
                      return 2 /* OVERLINE */;
                  case 'line-through':
                      return 3 /* LINE_THROUGH */;
                  case 'none':
                      return 4 /* BLINK */;
              }
              return 0 /* NONE */;
          })
              .filter(function (line) { return line !== 0 /* NONE */; });
      }
  };

  var fontFamily = {
      name: "font-family",
      initialValue: '',
      prefix: false,
      type: 1 /* LIST */,
      parse: function (_context, tokens) {
          var accumulator = [];
          var results = [];
          tokens.forEach(function (token) {
              switch (token.type) {
                  case 20 /* IDENT_TOKEN */:
                  case 0 /* STRING_TOKEN */:
                      accumulator.push(token.value);
                      break;
                  case 17 /* NUMBER_TOKEN */:
                      accumulator.push(token.number.toString());
                      break;
                  case 4 /* COMMA_TOKEN */:
                      results.push(accumulator.join(' '));
                      accumulator.length = 0;
                      break;
              }
          });
          if (accumulator.length) {
              results.push(accumulator.join(' '));
          }
          return results.map(function (result) { return (result.indexOf(' ') === -1 ? result : "'" + result + "'"); });
      }
  };

  var fontSize = {
      name: "font-size",
      initialValue: '0',
      prefix: false,
      type: 3 /* TYPE_VALUE */,
      format: 'length'
  };

  var fontWeight = {
      name: 'font-weight',
      initialValue: 'normal',
      type: 0 /* VALUE */,
      prefix: false,
      parse: function (_context, token) {
          if (isNumberToken(token)) {
              return token.number;
          }
          if (isIdentToken(token)) {
              switch (token.value) {
                  case 'bold':
                      return 700;
                  case 'normal':
                  default:
                      return 400;
              }
          }
          return 400;
      }
  };

  var fontVariant = {
      name: 'font-variant',
      initialValue: 'none',
      type: 1 /* LIST */,
      prefix: false,
      parse: function (_context, tokens) {
          return tokens.filter(isIdentToken).map(function (token) { return token.value; });
      }
  };

  var fontStyle = {
      name: 'font-style',
      initialValue: 'normal',
      prefix: false,
      type: 2 /* IDENT_VALUE */,
      parse: function (_context, overflow) {
          switch (overflow) {
              case 'oblique':
                  return "oblique" /* OBLIQUE */;
              case 'italic':
                  return "italic" /* ITALIC */;
              case 'normal':
              default:
                  return "normal" /* NORMAL */;
          }
      }
  };

  var contains = function (bit, value) { return (bit & value) !== 0; };

  var duration = {
      name: 'duration',
      initialValue: '0s',
      prefix: false,
      type: 1 /* LIST */,
      parse: function (context, tokens) {
          return tokens.filter(isDimensionToken).map(function (token) { return time.parse(context, token); });
      }
  };

  var boxShadow = {
      name: 'box-shadow',
      initialValue: 'none',
      type: 1 /* LIST */,
      prefix: false,
      parse: function (context, tokens) {
          if (tokens.length === 1 && isIdentWithValue(tokens[0], 'none')) {
              return [];
          }
          return parseFunctionArgs(tokens).map(function (values) {
              var shadow = {
                  color: 0x000000ff,
                  offsetX: ZERO_LENGTH,
                  offsetY: ZERO_LENGTH,
                  blur: ZERO_LENGTH,
                  spread: ZERO_LENGTH,
                  inset: false
              };
              var c = 0;
              for (var i = 0; i < values.length; i++) {
                  var token = values[i];
                  if (isIdentWithValue(token, 'inset')) {
                      shadow.inset = true;
                  }
                  else if (isLength(token)) {
                      if (c === 0) {
                          shadow.offsetX = token;
                      }
                      else if (c === 1) {
                          shadow.offsetY = token;
                      }
                      else if (c === 2) {
                          shadow.blur = token;
                      }
                      else {
                          shadow.spread = token;
                      }
                      c++;
                  }
                  else {
                      shadow.color = color$1.parse(context, token);
                  }
              }
              return shadow;
          });
      }
  };

  var paintOrder = {
      name: 'paint-order',
      initialValue: 'normal',
      prefix: false,
      type: 1 /* LIST */,
      parse: function (_context, tokens) {
          var DEFAULT_VALUE = [0 /* FILL */, 1 /* STROKE */, 2 /* MARKERS */];
          var layers = [];
          tokens.filter(isIdentToken).forEach(function (token) {
              switch (token.value) {
                  case 'stroke':
                      layers.push(1 /* STROKE */);
                      break;
                  case 'fill':
                      layers.push(0 /* FILL */);
                      break;
                  case 'markers':
                      layers.push(2 /* MARKERS */);
                      break;
              }
          });
          DEFAULT_VALUE.forEach(function (value) {
              if (layers.indexOf(value) === -1) {
                  layers.push(value);
              }
          });
          return layers;
      }
  };

  var webkitTextStrokeColor = {
      name: "-webkit-text-stroke-color",
      initialValue: 'currentcolor',
      prefix: false,
      type: 3 /* TYPE_VALUE */,
      format: 'color'
  };

  var webkitTextStrokeWidth = {
      name: "-webkit-text-stroke-width",
      initialValue: '0',
      type: 0 /* VALUE */,
      prefix: false,
      parse: function (_context, token) {
          if (isDimensionToken(token)) {
              return token.number;
          }
          return 0;
      }
  };

  var CSSParsedDeclaration = /** @class */ (function () {
      function CSSParsedDeclaration(context, declaration) {
          var _a, _b;
          this.animationDuration = parse(context, duration, declaration.animationDuration);
          this.backgroundClip = parse(context, backgroundClip, declaration.backgroundClip);
          this.backgroundColor = parse(context, backgroundColor, declaration.backgroundColor);
          this.backgroundImage = parse(context, backgroundImage, declaration.backgroundImage);
          this.backgroundOrigin = parse(context, backgroundOrigin, declaration.backgroundOrigin);
          this.backgroundPosition = parse(context, backgroundPosition, declaration.backgroundPosition);
          this.backgroundRepeat = parse(context, backgroundRepeat, declaration.backgroundRepeat);
          this.backgroundSize = parse(context, backgroundSize, declaration.backgroundSize);
          this.borderTopColor = parse(context, borderTopColor, declaration.borderTopColor);
          this.borderRightColor = parse(context, borderRightColor, declaration.borderRightColor);
          this.borderBottomColor = parse(context, borderBottomColor, declaration.borderBottomColor);
          this.borderLeftColor = parse(context, borderLeftColor, declaration.borderLeftColor);
          this.borderTopLeftRadius = parse(context, borderTopLeftRadius, declaration.borderTopLeftRadius);
          this.borderTopRightRadius = parse(context, borderTopRightRadius, declaration.borderTopRightRadius);
          this.borderBottomRightRadius = parse(context, borderBottomRightRadius, declaration.borderBottomRightRadius);
          this.borderBottomLeftRadius = parse(context, borderBottomLeftRadius, declaration.borderBottomLeftRadius);
          this.borderTopStyle = parse(context, borderTopStyle, declaration.borderTopStyle);
          this.borderRightStyle = parse(context, borderRightStyle, declaration.borderRightStyle);
          this.borderBottomStyle = parse(context, borderBottomStyle, declaration.borderBottomStyle);
          this.borderLeftStyle = parse(context, borderLeftStyle, declaration.borderLeftStyle);
          this.borderTopWidth = parse(context, borderTopWidth, declaration.borderTopWidth);
          this.borderRightWidth = parse(context, borderRightWidth, declaration.borderRightWidth);
          this.borderBottomWidth = parse(context, borderBottomWidth, declaration.borderBottomWidth);
          this.borderLeftWidth = parse(context, borderLeftWidth, declaration.borderLeftWidth);
          this.boxShadow = parse(context, boxShadow, declaration.boxShadow);
          this.color = parse(context, color, declaration.color);
          this.direction = parse(context, direction, declaration.direction);
          this.display = parse(context, display, declaration.display);
          this.float = parse(context, float, declaration.cssFloat);
          this.fontFamily = parse(context, fontFamily, declaration.fontFamily);
          this.fontSize = parse(context, fontSize, declaration.fontSize);
          this.fontStyle = parse(context, fontStyle, declaration.fontStyle);
          this.fontVariant = parse(context, fontVariant, declaration.fontVariant);
          this.fontWeight = parse(context, fontWeight, declaration.fontWeight);
          this.letterSpacing = parse(context, letterSpacing, declaration.letterSpacing);
          this.lineBreak = parse(context, lineBreak, declaration.lineBreak);
          this.lineHeight = parse(context, lineHeight, declaration.lineHeight);
          this.listStyleImage = parse(context, listStyleImage, declaration.listStyleImage);
          this.listStylePosition = parse(context, listStylePosition, declaration.listStylePosition);
          this.listStyleType = parse(context, listStyleType, declaration.listStyleType);
          this.marginTop = parse(context, marginTop, declaration.marginTop);
          this.marginRight = parse(context, marginRight, declaration.marginRight);
          this.marginBottom = parse(context, marginBottom, declaration.marginBottom);
          this.marginLeft = parse(context, marginLeft, declaration.marginLeft);
          this.opacity = parse(context, opacity, declaration.opacity);
          var overflowTuple = parse(context, overflow, declaration.overflow);
          this.overflowX = overflowTuple[0];
          this.overflowY = overflowTuple[overflowTuple.length > 1 ? 1 : 0];
          this.overflowWrap = parse(context, overflowWrap, declaration.overflowWrap);
          this.paddingTop = parse(context, paddingTop, declaration.paddingTop);
          this.paddingRight = parse(context, paddingRight, declaration.paddingRight);
          this.paddingBottom = parse(context, paddingBottom, declaration.paddingBottom);
          this.paddingLeft = parse(context, paddingLeft, declaration.paddingLeft);
          this.paintOrder = parse(context, paintOrder, declaration.paintOrder);
          this.position = parse(context, position, declaration.position);
          this.textAlign = parse(context, textAlign, declaration.textAlign);
          this.textDecorationColor = parse(context, textDecorationColor, (_a = declaration.textDecorationColor) !== null && _a !== void 0 ? _a : declaration.color);
          this.textDecorationLine = parse(context, textDecorationLine, (_b = declaration.textDecorationLine) !== null && _b !== void 0 ? _b : declaration.textDecoration);
          this.textShadow = parse(context, textShadow, declaration.textShadow);
          this.textTransform = parse(context, textTransform, declaration.textTransform);
          this.transform = parse(context, transform$1, declaration.transform);
          this.transformOrigin = parse(context, transformOrigin, declaration.transformOrigin);
          this.visibility = parse(context, visibility, declaration.visibility);
          this.webkitTextStrokeColor = parse(context, webkitTextStrokeColor, declaration.webkitTextStrokeColor);
          this.webkitTextStrokeWidth = parse(context, webkitTextStrokeWidth, declaration.webkitTextStrokeWidth);
          this.wordBreak = parse(context, wordBreak, declaration.wordBreak);
          this.zIndex = parse(context, zIndex, declaration.zIndex);
      }
      CSSParsedDeclaration.prototype.isVisible = function () {
          return this.display > 0 && this.opacity > 0 && this.visibility === 0 /* VISIBLE */;
      };
      CSSParsedDeclaration.prototype.isTransparent = function () {
          return isTransparent(this.backgroundColor);
      };
      CSSParsedDeclaration.prototype.isTransformed = function () {
          return this.transform !== null;
      };
      CSSParsedDeclaration.prototype.isPositioned = function () {
          return this.position !== 0 /* STATIC */;
      };
      CSSParsedDeclaration.prototype.isPositionedWithZIndex = function () {
          return this.isPositioned() && !this.zIndex.auto;
      };
      CSSParsedDeclaration.prototype.isFloating = function () {
          return this.float !== 0 /* NONE */;
      };
      CSSParsedDeclaration.prototype.isInlineLevel = function () {
          return (contains(this.display, 4 /* INLINE */) ||
              contains(this.display, 33554432 /* INLINE_BLOCK */) ||
              contains(this.display, 268435456 /* INLINE_FLEX */) ||
              contains(this.display, 536870912 /* INLINE_GRID */) ||
              contains(this.display, 67108864 /* INLINE_LIST_ITEM */) ||
              contains(this.display, 134217728 /* INLINE_TABLE */));
      };
      return CSSParsedDeclaration;
  }());
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  var parse = function (context, descriptor, style) {
      var tokenizer = new Tokenizer();
      var value = style !== null && typeof style !== 'undefined' ? style.toString() : descriptor.initialValue;
      tokenizer.write(value);
      var parser = new Parser(tokenizer.read());
      switch (descriptor.type) {
          case 2 /* IDENT_VALUE */:
              var token = parser.parseComponentValue();
              return descriptor.parse(context, isIdentToken(token) ? token.value : descriptor.initialValue);
          case 0 /* VALUE */:
              return descriptor.parse(context, parser.parseComponentValue());
          case 1 /* LIST */:
              return descriptor.parse(context, parser.parseComponentValues());
          case 4 /* TOKEN_VALUE */:
              return parser.parseComponentValue();
          case 3 /* TYPE_VALUE */:
              switch (descriptor.format) {
                  case 'angle':
                      return angle.parse(context, parser.parseComponentValue());
                  case 'color':
                      return color$1.parse(context, parser.parseComponentValue());
                  case 'image':
                      return image.parse(context, parser.parseComponentValue());
                  case 'length':
                      var length_1 = parser.parseComponentValue();
                      return isLength(length_1) ? length_1 : ZERO_LENGTH;
                  case 'length-percentage':
                      var value_1 = parser.parseComponentValue();
                      return isLengthPercentage(value_1) ? value_1 : ZERO_LENGTH;
                  case 'time':
                      return time.parse(context, parser.parseComponentValue());
              }
              break;
      }
  };

  var elementDebuggerAttribute = 'data-html2canvas-debug';
  var getElementDebugType = function (element) {
      var attribute = element.getAttribute(elementDebuggerAttribute);
      switch (attribute) {
          case 'all':
              return 1 /* ALL */;
          case 'clone':
              return 2 /* CLONE */;
          case 'parse':
              return 3 /* PARSE */;
          case 'render':
              return 4 /* RENDER */;
          default:
              return 0 /* NONE */;
      }
  };
  var isDebugging = function (element, type) {
      var elementType = getElementDebugType(element);
      return elementType === 1 /* ALL */ || type === elementType;
  };

  var ElementContainer = /** @class */ (function () {
      function ElementContainer(context, element) {
          this.context = context;
          this.textNodes = [];
          this.elements = [];
          this.flags = 0;
          if (isDebugging(element, 3 /* PARSE */)) {
              debugger;
          }
          this.styles = new CSSParsedDeclaration(context, window.getComputedStyle(element, null));
          if (isHTMLElementNode(element)) {
              if (this.styles.animationDuration.some(function (duration) { return duration > 0; })) {
                  element.style.animationDuration = '0s';
              }
              if (this.styles.transform !== null) {
                  // getBoundingClientRect takes transforms into account
                  element.style.transform = 'none';
              }
          }
          this.bounds = parseBounds(this.context, element);
          if (isDebugging(element, 4 /* RENDER */)) {
              this.flags |= 16 /* DEBUG_RENDER */;
          }
      }
      return ElementContainer;
  }());

  /*
   * text-segmentation 1.0.3 <https://github.com/niklasvh/text-segmentation>
   * Copyright (c) 2022 Niklas von Hertzen <https://hertzen.com>
   * Released under MIT License
   */
  var base64 = 'AAAAAAAAAAAAEA4AGBkAAFAaAAACAAAAAAAIABAAGAAwADgACAAQAAgAEAAIABAACAAQAAgAEAAIABAACAAQAAgAEAAIABAAQABIAEQATAAIABAACAAQAAgAEAAIABAAVABcAAgAEAAIABAACAAQAGAAaABwAHgAgACIAI4AlgAIABAAmwCjAKgAsAC2AL4AvQDFAMoA0gBPAVYBWgEIAAgACACMANoAYgFkAWwBdAF8AX0BhQGNAZUBlgGeAaMBlQGWAasBswF8AbsBwwF0AcsBYwHTAQgA2wG/AOMBdAF8AekB8QF0AfkB+wHiAHQBfAEIAAMC5gQIAAsCEgIIAAgAFgIeAggAIgIpAggAMQI5AkACygEIAAgASAJQAlgCYAIIAAgACAAKBQoFCgUTBRMFGQUrBSsFCAAIAAgACAAIAAgACAAIAAgACABdAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACABoAmgCrwGvAQgAbgJ2AggAHgEIAAgACADnAXsCCAAIAAgAgwIIAAgACAAIAAgACACKAggAkQKZAggAPADJAAgAoQKkAqwCsgK6AsICCADJAggA0AIIAAgACAAIANYC3gIIAAgACAAIAAgACABAAOYCCAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAkASoB+QIEAAgACAA8AEMCCABCBQgACABJBVAFCAAIAAgACAAIAAgACAAIAAgACABTBVoFCAAIAFoFCABfBWUFCAAIAAgACAAIAAgAbQUIAAgACAAIAAgACABzBXsFfQWFBYoFigWKBZEFigWKBYoFmAWfBaYFrgWxBbkFCAAIAAgACAAIAAgACAAIAAgACAAIAMEFCAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAMgFCADQBQgACAAIAAgACAAIAAgACAAIAAgACAAIAO4CCAAIAAgAiQAIAAgACABAAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAD0AggACAD8AggACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIANYFCAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAMDvwAIAAgAJAIIAAgACAAIAAgACAAIAAgACwMTAwgACAB9BOsEGwMjAwgAKwMyAwsFYgE3A/MEPwMIAEUDTQNRAwgAWQOsAGEDCAAIAAgACAAIAAgACABpAzQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFIQUoBSwFCAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACABtAwgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACABMAEwACAAIAAgACAAIABgACAAIAAgACAC/AAgACAAyAQgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACACAAIAAwAAgACAAIAAgACAAIAAgACAAIAAAARABIAAgACAAIABQASAAIAAgAIABwAEAAjgCIABsAqAC2AL0AigDQAtwC+IJIQqVAZUBWQqVAZUBlQGVAZUBlQGrC5UBlQGVAZUBlQGVAZUBlQGVAXsKlQGVAbAK6wsrDGUMpQzlDJUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAfAKAAuZA64AtwCJALoC6ADwAAgAuACgA/oEpgO6AqsD+AAIAAgAswMIAAgACAAIAIkAuwP5AfsBwwPLAwgACAAIAAgACADRA9kDCAAIAOED6QMIAAgACAAIAAgACADuA/YDCAAIAP4DyQAIAAgABgQIAAgAXQAOBAgACAAIAAgACAAIABMECAAIAAgACAAIAAgACAD8AAQBCAAIAAgAGgQiBCoECAExBAgAEAEIAAgACAAIAAgACAAIAAgACAAIAAgACAA4BAgACABABEYECAAIAAgATAQYAQgAVAQIAAgACAAIAAgACAAIAAgACAAIAFoECAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAOQEIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAB+BAcACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAEABhgSMBAgACAAIAAgAlAQIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAwAEAAQABAADAAMAAwADAAQABAAEAAQABAAEAAQABHATAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAdQMIAAgACAAIAAgACAAIAMkACAAIAAgAfQMIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACACFA4kDCAAIAAgACAAIAOcBCAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAIcDCAAIAAgACAAIAAgACAAIAAgACAAIAJEDCAAIAAgACADFAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACABgBAgAZgQIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAbAQCBXIECAAIAHkECAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACABAAJwEQACjBKoEsgQIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAC6BMIECAAIAAgACAAIAAgACABmBAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAxwQIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAGYECAAIAAgAzgQIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAigWKBYoFigWKBYoFigWKBd0FXwUIAOIF6gXxBYoF3gT5BQAGCAaKBYoFigWKBYoFigWKBYoFigWKBYoFigXWBIoFigWKBYoFigWKBYoFigWKBYsFEAaKBYoFigWKBYoFigWKBRQGCACKBYoFigWKBQgACAAIANEECAAIABgGigUgBggAJgYIAC4GMwaKBYoF0wQ3Bj4GigWKBYoFigWKBYoFigWKBYoFigWKBYoFigUIAAgACAAIAAgACAAIAAgAigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWLBf///////wQABAAEAAQABAAEAAQABAAEAAQAAwAEAAQAAgAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAQADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAUAAAAFAAUAAAAFAAUAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAEAAQABAAEAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUAAQAAAAUABQAFAAUABQAFAAAAAAAFAAUAAAAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAFAAUAAQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABwAFAAUABQAFAAAABwAHAAcAAAAHAAcABwAFAAEAAAAAAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAFAAUABQAFAAcABwAFAAUAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAAAAQABAAAAAAAAAAAAAAAFAAUABQAFAAAABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAHAAcABwAHAAcAAAAHAAcAAAAAAAUABQAHAAUAAQAHAAEABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABwABAAUABQAFAAUAAAAAAAAAAAAAAAEAAQABAAEAAQABAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABwAFAAUAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUAAQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQABQANAAQABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQABAAEAAQABAAEAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAEAAQABAAEAAQABAAEAAQABAAEAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAQABAAEAAQABAAEAAQABAAAAAAAAAAAAAAAAAAAAAAABQAHAAUABQAFAAAAAAAAAAcABQAFAAUABQAFAAQABAAEAAQABAAEAAQABAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUAAAAFAAUABQAFAAUAAAAFAAUABQAAAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAAAAAAAAAAAAUABQAFAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAHAAUAAAAHAAcABwAFAAUABQAFAAUABQAFAAUABwAHAAcABwAFAAcABwAAAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABwAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAUABwAHAAUABQAFAAUAAAAAAAcABwAAAAAABwAHAAUAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAABQAFAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAABwAHAAcABQAFAAAAAAAAAAAABQAFAAAAAAAFAAUABQAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAFAAUABQAFAAUAAAAFAAUABwAAAAcABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAFAAUABwAFAAUABQAFAAAAAAAHAAcAAAAAAAcABwAFAAAAAAAAAAAAAAAAAAAABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAcABwAAAAAAAAAHAAcABwAAAAcABwAHAAUAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAABQAHAAcABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABwAHAAcABwAAAAUABQAFAAAABQAFAAUABQAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAcABQAHAAcABQAHAAcAAAAFAAcABwAAAAcABwAFAAUAAAAAAAAAAAAAAAAAAAAFAAUAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAUABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAFAAcABwAFAAUABQAAAAUAAAAHAAcABwAHAAcABwAHAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAHAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAABwAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAUAAAAFAAAAAAAAAAAABwAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABwAFAAUABQAFAAUAAAAFAAUAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABwAFAAUABQAFAAUABQAAAAUABQAHAAcABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABQAFAAAAAAAAAAAABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAcABQAFAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAHAAUABQAFAAUABQAFAAUABwAHAAcABwAHAAcABwAHAAUABwAHAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABwAHAAcABwAFAAUABwAHAAcAAAAAAAAAAAAHAAcABQAHAAcABwAHAAcABwAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAcABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABQAHAAUABQAFAAUABQAFAAUAAAAFAAAABQAAAAAABQAFAAUABQAFAAUABQAFAAcABwAHAAcABwAHAAUABQAFAAUABQAFAAUABQAFAAUAAAAAAAUABQAFAAUABQAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABwAFAAcABwAHAAcABwAFAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAUABQAFAAUABwAHAAUABQAHAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAcABQAFAAcABwAHAAUABwAFAAUABQAHAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAcABwAHAAcABwAHAAUABQAFAAUABQAFAAUABQAHAAcABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUAAAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAcABQAFAAUABQAFAAUABQAAAAAAAAAAAAUAAAAAAAAAAAAAAAAABQAAAAAABwAFAAUAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAAABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUAAAAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAABQAAAAAAAAAFAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAUABQAHAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABwAHAAcABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAFAAUABQAHAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAcABwAFAAUABQAFAAcABwAFAAUABwAHAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAcABwAFAAUABwAHAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAFAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAFAAUABQAAAAAABQAFAAAAAAAAAAAAAAAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABQAFAAcABwAAAAAAAAAAAAAABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABwAFAAcABwAFAAcABwAAAAcABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAAAAAAAAAAAAAAAAAFAAUABQAAAAUABQAAAAAAAAAAAAAABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAAAAAAAAAAAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABQAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABwAFAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAcABQAFAAUABQAFAAUABQAFAAUABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAFAAUABQAHAAcABQAHAAUABQAAAAAAAAAAAAAAAAAFAAAABwAHAAcABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABwAHAAcABwAAAAAABwAHAAAAAAAHAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAAAAAAFAAUABQAFAAUABQAFAAAAAAAAAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAFAAUABQAFAAUABQAFAAUABwAHAAUABQAFAAcABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAHAAcABQAFAAUABQAFAAUABwAFAAcABwAFAAcABQAFAAcABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAHAAcABQAFAAUABQAAAAAABwAHAAcABwAFAAUABwAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABwAHAAUABQAFAAUABQAFAAUABQAHAAcABQAHAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABwAFAAcABwAFAAUABQAFAAUABQAHAAUAAAAAAAAAAAAAAAAAAAAAAAcABwAFAAUABQAFAAcABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAFAAUABQAFAAUABQAFAAUABQAHAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAFAAUABQAFAAAAAAAFAAUABwAHAAcABwAFAAAAAAAAAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABwAHAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABQAFAAUABQAFAAUABQAAAAUABQAFAAUABQAFAAcABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAAAHAAUABQAFAAUABQAFAAUABwAFAAUABwAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUAAAAAAAAABQAAAAUABQAAAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAHAAcAAAAFAAUAAAAHAAcABQAHAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABwAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAAAAAAAAAAAAAAAAAAABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAUABQAFAAAAAAAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAAAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAAAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAAABQAFAAUABQAFAAUABQAAAAUABQAAAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAFAAUABQAFAAUADgAOAA4ADgAOAA4ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAAAAAAAAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAMAAwADAAMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkAAAAAAAAAAAAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAAAAAAAAAAAAsADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwACwAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAAAAAAAAAAAAAAAAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAOAAAAAAAAAAAADgAOAA4AAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAAAA4ADgAOAA4ADgAOAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4AAAAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4AAAAAAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAAAA4AAAAOAAAAAAAAAAAAAAAAAA4AAAAAAAAAAAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAADgAAAAAAAAAAAA4AAAAOAAAAAAAAAAAADgAOAA4AAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAA4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAAAAAAAA4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAAAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4AAAAAAA4ADgAOAA4ADgAOAA4ADgAOAAAADgAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4AAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4AAAAAAAAAAAAAAAAAAAAAAA4ADgAOAA4ADgAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4AAAAOAA4ADgAOAA4ADgAAAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4AAAAAAAAAAAA=';

  /*
   * utrie 1.0.2 <https://github.com/niklasvh/utrie>
   * Copyright (c) 2022 Niklas von Hertzen <https://hertzen.com>
   * Released under MIT License
   */
  var chars$1 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  // Use a lookup table to find the index.
  var lookup$1 = typeof Uint8Array === 'undefined' ? [] : new Uint8Array(256);
  for (var i$1 = 0; i$1 < chars$1.length; i$1++) {
      lookup$1[chars$1.charCodeAt(i$1)] = i$1;
  }
  var decode = function (base64) {
      var bufferLength = base64.length * 0.75, len = base64.length, i, p = 0, encoded1, encoded2, encoded3, encoded4;
      if (base64[base64.length - 1] === '=') {
          bufferLength--;
          if (base64[base64.length - 2] === '=') {
              bufferLength--;
          }
      }
      var buffer = typeof ArrayBuffer !== 'undefined' &&
          typeof Uint8Array !== 'undefined' &&
          typeof Uint8Array.prototype.slice !== 'undefined'
          ? new ArrayBuffer(bufferLength)
          : new Array(bufferLength);
      var bytes = Array.isArray(buffer) ? buffer : new Uint8Array(buffer);
      for (i = 0; i < len; i += 4) {
          encoded1 = lookup$1[base64.charCodeAt(i)];
          encoded2 = lookup$1[base64.charCodeAt(i + 1)];
          encoded3 = lookup$1[base64.charCodeAt(i + 2)];
          encoded4 = lookup$1[base64.charCodeAt(i + 3)];
          bytes[p++] = (encoded1 << 2) | (encoded2 >> 4);
          bytes[p++] = ((encoded2 & 15) << 4) | (encoded3 >> 2);
          bytes[p++] = ((encoded3 & 3) << 6) | (encoded4 & 63);
      }
      return buffer;
  };
  var polyUint16Array = function (buffer) {
      var length = buffer.length;
      var bytes = [];
      for (var i = 0; i < length; i += 2) {
          bytes.push((buffer[i + 1] << 8) | buffer[i]);
      }
      return bytes;
  };
  var polyUint32Array = function (buffer) {
      var length = buffer.length;
      var bytes = [];
      for (var i = 0; i < length; i += 4) {
          bytes.push((buffer[i + 3] << 24) | (buffer[i + 2] << 16) | (buffer[i + 1] << 8) | buffer[i]);
      }
      return bytes;
  };

  /** Shift size for getting the index-2 table offset. */
  var UTRIE2_SHIFT_2 = 5;
  /** Shift size for getting the index-1 table offset. */
  var UTRIE2_SHIFT_1 = 6 + 5;
  /**
   * Shift size for shifting left the index array values.
   * Increases possible data size with 16-bit index values at the cost
   * of compactability.
   * This requires data blocks to be aligned by UTRIE2_DATA_GRANULARITY.
   */
  var UTRIE2_INDEX_SHIFT = 2;
  /**
   * Difference between the two shift sizes,
   * for getting an index-1 offset from an index-2 offset. 6=11-5
   */
  var UTRIE2_SHIFT_1_2 = UTRIE2_SHIFT_1 - UTRIE2_SHIFT_2;
  /**
   * The part of the index-2 table for U+D800..U+DBFF stores values for
   * lead surrogate code _units_ not code _points_.
   * Values for lead surrogate code _points_ are indexed with this portion of the table.
   * Length=32=0x20=0x400>>UTRIE2_SHIFT_2. (There are 1024=0x400 lead surrogates.)
   */
  var UTRIE2_LSCP_INDEX_2_OFFSET = 0x10000 >> UTRIE2_SHIFT_2;
  /** Number of entries in a data block. 32=0x20 */
  var UTRIE2_DATA_BLOCK_LENGTH = 1 << UTRIE2_SHIFT_2;
  /** Mask for getting the lower bits for the in-data-block offset. */
  var UTRIE2_DATA_MASK = UTRIE2_DATA_BLOCK_LENGTH - 1;
  var UTRIE2_LSCP_INDEX_2_LENGTH = 0x400 >> UTRIE2_SHIFT_2;
  /** Count the lengths of both BMP pieces. 2080=0x820 */
  var UTRIE2_INDEX_2_BMP_LENGTH = UTRIE2_LSCP_INDEX_2_OFFSET + UTRIE2_LSCP_INDEX_2_LENGTH;
  /**
   * The 2-byte UTF-8 version of the index-2 table follows at offset 2080=0x820.
   * Length 32=0x20 for lead bytes C0..DF, regardless of UTRIE2_SHIFT_2.
   */
  var UTRIE2_UTF8_2B_INDEX_2_OFFSET = UTRIE2_INDEX_2_BMP_LENGTH;
  var UTRIE2_UTF8_2B_INDEX_2_LENGTH = 0x800 >> 6; /* U+0800 is the first code point after 2-byte UTF-8 */
  /**
   * The index-1 table, only used for supplementary code points, at offset 2112=0x840.
   * Variable length, for code points up to highStart, where the last single-value range starts.
   * Maximum length 512=0x200=0x100000>>UTRIE2_SHIFT_1.
   * (For 0x100000 supplementary code points U+10000..U+10ffff.)
   *
   * The part of the index-2 table for supplementary code points starts
   * after this index-1 table.
   *
   * Both the index-1 table and the following part of the index-2 table
   * are omitted completely if there is only BMP data.
   */
  var UTRIE2_INDEX_1_OFFSET = UTRIE2_UTF8_2B_INDEX_2_OFFSET + UTRIE2_UTF8_2B_INDEX_2_LENGTH;
  /**
   * Number of index-1 entries for the BMP. 32=0x20
   * This part of the index-1 table is omitted from the serialized form.
   */
  var UTRIE2_OMITTED_BMP_INDEX_1_LENGTH = 0x10000 >> UTRIE2_SHIFT_1;
  /** Number of entries in an index-2 block. 64=0x40 */
  var UTRIE2_INDEX_2_BLOCK_LENGTH = 1 << UTRIE2_SHIFT_1_2;
  /** Mask for getting the lower bits for the in-index-2-block offset. */
  var UTRIE2_INDEX_2_MASK = UTRIE2_INDEX_2_BLOCK_LENGTH - 1;
  var slice16 = function (view, start, end) {
      if (view.slice) {
          return view.slice(start, end);
      }
      return new Uint16Array(Array.prototype.slice.call(view, start, end));
  };
  var slice32 = function (view, start, end) {
      if (view.slice) {
          return view.slice(start, end);
      }
      return new Uint32Array(Array.prototype.slice.call(view, start, end));
  };
  var createTrieFromBase64 = function (base64, _byteLength) {
      var buffer = decode(base64);
      var view32 = Array.isArray(buffer) ? polyUint32Array(buffer) : new Uint32Array(buffer);
      var view16 = Array.isArray(buffer) ? polyUint16Array(buffer) : new Uint16Array(buffer);
      var headerLength = 24;
      var index = slice16(view16, headerLength / 2, view32[4] / 2);
      var data = view32[5] === 2
          ? slice16(view16, (headerLength + view32[4]) / 2)
          : slice32(view32, Math.ceil((headerLength + view32[4]) / 4));
      return new Trie(view32[0], view32[1], view32[2], view32[3], index, data);
  };
  var Trie = /** @class */ (function () {
      function Trie(initialValue, errorValue, highStart, highValueIndex, index, data) {
          this.initialValue = initialValue;
          this.errorValue = errorValue;
          this.highStart = highStart;
          this.highValueIndex = highValueIndex;
          this.index = index;
          this.data = data;
      }
      /**
       * Get the value for a code point as stored in the Trie.
       *
       * @param codePoint the code point
       * @return the value
       */
      Trie.prototype.get = function (codePoint) {
          var ix;
          if (codePoint >= 0) {
              if (codePoint < 0x0d800 || (codePoint > 0x0dbff && codePoint <= 0x0ffff)) {
                  // Ordinary BMP code point, excluding leading surrogates.
                  // BMP uses a single level lookup.  BMP index starts at offset 0 in the Trie2 index.
                  // 16 bit data is stored in the index array itself.
                  ix = this.index[codePoint >> UTRIE2_SHIFT_2];
                  ix = (ix << UTRIE2_INDEX_SHIFT) + (codePoint & UTRIE2_DATA_MASK);
                  return this.data[ix];
              }
              if (codePoint <= 0xffff) {
                  // Lead Surrogate Code Point.  A Separate index section is stored for
                  // lead surrogate code units and code points.
                  //   The main index has the code unit data.
                  //   For this function, we need the code point data.
                  // Note: this expression could be refactored for slightly improved efficiency, but
                  //       surrogate code points will be so rare in practice that it's not worth it.
                  ix = this.index[UTRIE2_LSCP_INDEX_2_OFFSET + ((codePoint - 0xd800) >> UTRIE2_SHIFT_2)];
                  ix = (ix << UTRIE2_INDEX_SHIFT) + (codePoint & UTRIE2_DATA_MASK);
                  return this.data[ix];
              }
              if (codePoint < this.highStart) {
                  // Supplemental code point, use two-level lookup.
                  ix = UTRIE2_INDEX_1_OFFSET - UTRIE2_OMITTED_BMP_INDEX_1_LENGTH + (codePoint >> UTRIE2_SHIFT_1);
                  ix = this.index[ix];
                  ix += (codePoint >> UTRIE2_SHIFT_2) & UTRIE2_INDEX_2_MASK;
                  ix = this.index[ix];
                  ix = (ix << UTRIE2_INDEX_SHIFT) + (codePoint & UTRIE2_DATA_MASK);
                  return this.data[ix];
              }
              if (codePoint <= 0x10ffff) {
                  return this.data[this.highValueIndex];
              }
          }
          // Fall through.  The code point is outside of the legal range of 0..0x10ffff.
          return this.errorValue;
      };
      return Trie;
  }());

  /*
   * base64-arraybuffer 1.0.2 <https://github.com/niklasvh/base64-arraybuffer>
   * Copyright (c) 2022 Niklas von Hertzen <https://hertzen.com>
   * Released under MIT License
   */
  var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  // Use a lookup table to find the index.
  var lookup = typeof Uint8Array === 'undefined' ? [] : new Uint8Array(256);
  for (var i = 0; i < chars.length; i++) {
      lookup[chars.charCodeAt(i)] = i;
  }

  var Prepend = 1;
  var CR = 2;
  var LF = 3;
  var Control = 4;
  var Extend = 5;
  var SpacingMark = 7;
  var L = 8;
  var V = 9;
  var T = 10;
  var LV = 11;
  var LVT = 12;
  var ZWJ = 13;
  var Extended_Pictographic = 14;
  var RI = 15;
  var toCodePoints = function (str) {
      var codePoints = [];
      var i = 0;
      var length = str.length;
      while (i < length) {
          var value = str.charCodeAt(i++);
          if (value >= 0xd800 && value <= 0xdbff && i < length) {
              var extra = str.charCodeAt(i++);
              if ((extra & 0xfc00) === 0xdc00) {
                  codePoints.push(((value & 0x3ff) << 10) + (extra & 0x3ff) + 0x10000);
              }
              else {
                  codePoints.push(value);
                  i--;
              }
          }
          else {
              codePoints.push(value);
          }
      }
      return codePoints;
  };
  var fromCodePoint = function () {
      var codePoints = [];
      for (var _i = 0; _i < arguments.length; _i++) {
          codePoints[_i] = arguments[_i];
      }
      if (String.fromCodePoint) {
          return String.fromCodePoint.apply(String, codePoints);
      }
      var length = codePoints.length;
      if (!length) {
          return '';
      }
      var codeUnits = [];
      var index = -1;
      var result = '';
      while (++index < length) {
          var codePoint = codePoints[index];
          if (codePoint <= 0xffff) {
              codeUnits.push(codePoint);
          }
          else {
              codePoint -= 0x10000;
              codeUnits.push((codePoint >> 10) + 0xd800, (codePoint % 0x400) + 0xdc00);
          }
          if (index + 1 === length || codeUnits.length > 0x4000) {
              result += String.fromCharCode.apply(String, codeUnits);
              codeUnits.length = 0;
          }
      }
      return result;
  };
  var UnicodeTrie = createTrieFromBase64(base64);
  var BREAK_NOT_ALLOWED = '×';
  var BREAK_ALLOWED = '÷';
  var codePointToClass = function (codePoint) { return UnicodeTrie.get(codePoint); };
  var _graphemeBreakAtIndex = function (_codePoints, classTypes, index) {
      var prevIndex = index - 2;
      var prev = classTypes[prevIndex];
      var current = classTypes[index - 1];
      var next = classTypes[index];
      // GB3 Do not break between a CR and LF
      if (current === CR && next === LF) {
          return BREAK_NOT_ALLOWED;
      }
      // GB4 Otherwise, break before and after controls.
      if (current === CR || current === LF || current === Control) {
          return BREAK_ALLOWED;
      }
      // GB5
      if (next === CR || next === LF || next === Control) {
          return BREAK_ALLOWED;
      }
      // Do not break Hangul syllable sequences.
      // GB6
      if (current === L && [L, V, LV, LVT].indexOf(next) !== -1) {
          return BREAK_NOT_ALLOWED;
      }
      // GB7
      if ((current === LV || current === V) && (next === V || next === T)) {
          return BREAK_NOT_ALLOWED;
      }
      // GB8
      if ((current === LVT || current === T) && next === T) {
          return BREAK_NOT_ALLOWED;
      }
      // GB9 Do not break before extending characters or ZWJ.
      if (next === ZWJ || next === Extend) {
          return BREAK_NOT_ALLOWED;
      }
      // Do not break before SpacingMarks, or after Prepend characters.
      // GB9a
      if (next === SpacingMark) {
          return BREAK_NOT_ALLOWED;
      }
      // GB9a
      if (current === Prepend) {
          return BREAK_NOT_ALLOWED;
      }
      // GB11 Do not break within emoji modifier sequences or emoji zwj sequences.
      if (current === ZWJ && next === Extended_Pictographic) {
          while (prev === Extend) {
              prev = classTypes[--prevIndex];
          }
          if (prev === Extended_Pictographic) {
              return BREAK_NOT_ALLOWED;
          }
      }
      // GB12 Do not break within emoji flag sequences.
      // That is, do not break between regional indicator (RI) symbols
      // if there is an odd number of RI characters before the break point.
      if (current === RI && next === RI) {
          var countRI = 0;
          while (prev === RI) {
              countRI++;
              prev = classTypes[--prevIndex];
          }
          if (countRI % 2 === 0) {
              return BREAK_NOT_ALLOWED;
          }
      }
      return BREAK_ALLOWED;
  };
  var GraphemeBreaker = function (str) {
      var codePoints = toCodePoints(str);
      var length = codePoints.length;
      var index = 0;
      var lastEnd = 0;
      var classTypes = codePoints.map(codePointToClass);
      return {
          next: function () {
              if (index >= length) {
                  return { done: true, value: null };
              }
              var graphemeBreak = BREAK_NOT_ALLOWED;
              while (index < length &&
                  (graphemeBreak = _graphemeBreakAtIndex(codePoints, classTypes, ++index)) === BREAK_NOT_ALLOWED) { }
              if (graphemeBreak !== BREAK_NOT_ALLOWED || index === length) {
                  var value = fromCodePoint.apply(null, codePoints.slice(lastEnd, index));
                  lastEnd = index;
                  return { value: value, done: false };
              }
              return { done: true, value: null };
          },
      };
  };
  var splitGraphemes = function (str) {
      var breaker = GraphemeBreaker(str);
      var graphemes = [];
      var bk;
      while (!(bk = breaker.next()).done) {
          if (bk.value) {
              graphemes.push(bk.value.slice());
          }
      }
      return graphemes;
  };

  var testRangeBounds = function (document) {
      var TEST_HEIGHT = 123;
      if (document.createRange) {
          var range = document.createRange();
          if (range.getBoundingClientRect) {
              var testElement = document.createElement('boundtest');
              testElement.style.height = TEST_HEIGHT + "px";
              testElement.style.display = 'block';
              document.body.appendChild(testElement);
              range.selectNode(testElement);
              var rangeBounds = range.getBoundingClientRect();
              var rangeHeight = Math.round(rangeBounds.height);
              document.body.removeChild(testElement);
              if (rangeHeight === TEST_HEIGHT) {
                  return true;
              }
          }
      }
      return false;
  };
  var testIOSLineBreak = function (document) {
      var testElement = document.createElement('boundtest');
      testElement.style.width = '50px';
      testElement.style.display = 'block';
      testElement.style.fontSize = '12px';
      testElement.style.letterSpacing = '0px';
      testElement.style.wordSpacing = '0px';
      document.body.appendChild(testElement);
      var range = document.createRange();
      testElement.innerHTML = typeof ''.repeat === 'function' ? '&#128104;'.repeat(10) : '';
      var node = testElement.firstChild;
      var textList = toCodePoints$1(node.data).map(function (i) { return fromCodePoint$1(i); });
      var offset = 0;
      var prev = {};
      // ios 13 does not handle range getBoundingClientRect line changes correctly #2177
      var supports = textList.every(function (text, i) {
          range.setStart(node, offset);
          range.setEnd(node, offset + text.length);
          var rect = range.getBoundingClientRect();
          offset += text.length;
          var boundAhead = rect.x > prev.x || rect.y > prev.y;
          prev = rect;
          if (i === 0) {
              return true;
          }
          return boundAhead;
      });
      document.body.removeChild(testElement);
      return supports;
  };
  var testCORS = function () { return typeof new Image().crossOrigin !== 'undefined'; };
  var testResponseType = function () { return typeof new XMLHttpRequest().responseType === 'string'; };
  var testSVG = function (document) {
      var img = new Image();
      var canvas = document.createElement('canvas');
      var ctx = canvas.getContext('2d');
      if (!ctx) {
          return false;
      }
      img.src = "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg'></svg>";
      try {
          ctx.drawImage(img, 0, 0);
          canvas.toDataURL();
      }
      catch (e) {
          return false;
      }
      return true;
  };
  var isGreenPixel = function (data) {
      return data[0] === 0 && data[1] === 255 && data[2] === 0 && data[3] === 255;
  };
  var testForeignObject = function (document) {
      var canvas = document.createElement('canvas');
      var size = 100;
      canvas.width = size;
      canvas.height = size;
      var ctx = canvas.getContext('2d');
      if (!ctx) {
          return Promise.reject(false);
      }
      ctx.fillStyle = 'rgb(0, 255, 0)';
      ctx.fillRect(0, 0, size, size);
      var img = new Image();
      var greenImageSrc = canvas.toDataURL();
      img.src = greenImageSrc;
      var svg = createForeignObjectSVG(size, size, 0, 0, img);
      ctx.fillStyle = 'red';
      ctx.fillRect(0, 0, size, size);
      return loadSerializedSVG$1(svg)
          .then(function (img) {
          ctx.drawImage(img, 0, 0);
          var data = ctx.getImageData(0, 0, size, size).data;
          ctx.fillStyle = 'red';
          ctx.fillRect(0, 0, size, size);
          var node = document.createElement('div');
          node.style.backgroundImage = "url(" + greenImageSrc + ")";
          node.style.height = size + "px";
          // Firefox 55 does not render inline <img /> tags
          return isGreenPixel(data)
              ? loadSerializedSVG$1(createForeignObjectSVG(size, size, 0, 0, node))
              : Promise.reject(false);
      })
          .then(function (img) {
          ctx.drawImage(img, 0, 0);
          // Edge does not render background-images
          return isGreenPixel(ctx.getImageData(0, 0, size, size).data);
      })
          .catch(function () { return false; });
  };
  var createForeignObjectSVG = function (width, height, x, y, node) {
      var xmlns = 'http://www.w3.org/2000/svg';
      var svg = document.createElementNS(xmlns, 'svg');
      var foreignObject = document.createElementNS(xmlns, 'foreignObject');
      svg.setAttributeNS(null, 'width', width.toString());
      svg.setAttributeNS(null, 'height', height.toString());
      foreignObject.setAttributeNS(null, 'width', '100%');
      foreignObject.setAttributeNS(null, 'height', '100%');
      foreignObject.setAttributeNS(null, 'x', x.toString());
      foreignObject.setAttributeNS(null, 'y', y.toString());
      foreignObject.setAttributeNS(null, 'externalResourcesRequired', 'true');
      svg.appendChild(foreignObject);
      foreignObject.appendChild(node);
      return svg;
  };
  var loadSerializedSVG$1 = function (svg) {
      return new Promise(function (resolve, reject) {
          var img = new Image();
          img.onload = function () { return resolve(img); };
          img.onerror = reject;
          img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(new XMLSerializer().serializeToString(svg));
      });
  };
  var FEATURES = {
      get SUPPORT_RANGE_BOUNDS() {
          var value = testRangeBounds(document);
          Object.defineProperty(FEATURES, 'SUPPORT_RANGE_BOUNDS', { value: value });
          return value;
      },
      get SUPPORT_WORD_BREAKING() {
          var value = FEATURES.SUPPORT_RANGE_BOUNDS && testIOSLineBreak(document);
          Object.defineProperty(FEATURES, 'SUPPORT_WORD_BREAKING', { value: value });
          return value;
      },
      get SUPPORT_SVG_DRAWING() {
          var value = testSVG(document);
          Object.defineProperty(FEATURES, 'SUPPORT_SVG_DRAWING', { value: value });
          return value;
      },
      get SUPPORT_FOREIGNOBJECT_DRAWING() {
          var value = typeof Array.from === 'function' && typeof window.fetch === 'function'
              ? testForeignObject(document)
              : Promise.resolve(false);
          Object.defineProperty(FEATURES, 'SUPPORT_FOREIGNOBJECT_DRAWING', { value: value });
          return value;
      },
      get SUPPORT_CORS_IMAGES() {
          var value = testCORS();
          Object.defineProperty(FEATURES, 'SUPPORT_CORS_IMAGES', { value: value });
          return value;
      },
      get SUPPORT_RESPONSE_TYPE() {
          var value = testResponseType();
          Object.defineProperty(FEATURES, 'SUPPORT_RESPONSE_TYPE', { value: value });
          return value;
      },
      get SUPPORT_CORS_XHR() {
          var value = 'withCredentials' in new XMLHttpRequest();
          Object.defineProperty(FEATURES, 'SUPPORT_CORS_XHR', { value: value });
          return value;
      },
      get SUPPORT_NATIVE_TEXT_SEGMENTATION() {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          var value = !!(typeof Intl !== 'undefined' && Intl.Segmenter);
          Object.defineProperty(FEATURES, 'SUPPORT_NATIVE_TEXT_SEGMENTATION', { value: value });
          return value;
      }
  };

  var TextBounds = /** @class */ (function () {
      function TextBounds(text, bounds) {
          this.text = text;
          this.bounds = bounds;
      }
      return TextBounds;
  }());
  var parseTextBounds = function (context, value, styles, node) {
      var textList = breakText(value, styles);
      var textBounds = [];
      var offset = 0;
      textList.forEach(function (text) {
          if (styles.textDecorationLine.length || text.trim().length > 0) {
              if (FEATURES.SUPPORT_RANGE_BOUNDS) {
                  var clientRects = createRange(node, offset, text.length).getClientRects();
                  if (clientRects.length > 1) {
                      var subSegments = segmentGraphemes(text);
                      var subOffset_1 = 0;
                      subSegments.forEach(function (subSegment) {
                          textBounds.push(new TextBounds(subSegment, Bounds.fromDOMRectList(context, createRange(node, subOffset_1 + offset, subSegment.length).getClientRects())));
                          subOffset_1 += subSegment.length;
                      });
                  }
                  else {
                      textBounds.push(new TextBounds(text, Bounds.fromDOMRectList(context, clientRects)));
                  }
              }
              else {
                  var replacementNode = node.splitText(text.length);
                  textBounds.push(new TextBounds(text, getWrapperBounds(context, node)));
                  node = replacementNode;
              }
          }
          else if (!FEATURES.SUPPORT_RANGE_BOUNDS) {
              node = node.splitText(text.length);
          }
          offset += text.length;
      });
      return textBounds;
  };
  var getWrapperBounds = function (context, node) {
      var ownerDocument = node.ownerDocument;
      if (ownerDocument) {
          var wrapper = ownerDocument.createElement('html2canvaswrapper');
          wrapper.appendChild(node.cloneNode(true));
          var parentNode = node.parentNode;
          if (parentNode) {
              parentNode.replaceChild(wrapper, node);
              var bounds = parseBounds(context, wrapper);
              if (wrapper.firstChild) {
                  parentNode.replaceChild(wrapper.firstChild, wrapper);
              }
              return bounds;
          }
      }
      return Bounds.EMPTY;
  };
  var createRange = function (node, offset, length) {
      var ownerDocument = node.ownerDocument;
      if (!ownerDocument) {
          throw new Error('Node has no owner document');
      }
      var range = ownerDocument.createRange();
      range.setStart(node, offset);
      range.setEnd(node, offset + length);
      return range;
  };
  var segmentGraphemes = function (value) {
      if (FEATURES.SUPPORT_NATIVE_TEXT_SEGMENTATION) {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          var segmenter = new Intl.Segmenter(void 0, { granularity: 'grapheme' });
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          return Array.from(segmenter.segment(value)).map(function (segment) { return segment.segment; });
      }
      return splitGraphemes(value);
  };
  var segmentWords = function (value, styles) {
      if (FEATURES.SUPPORT_NATIVE_TEXT_SEGMENTATION) {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          var segmenter = new Intl.Segmenter(void 0, {
              granularity: 'word'
          });
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          return Array.from(segmenter.segment(value)).map(function (segment) { return segment.segment; });
      }
      return breakWords(value, styles);
  };
  var breakText = function (value, styles) {
      return styles.letterSpacing !== 0 ? segmentGraphemes(value) : segmentWords(value, styles);
  };
  // https://drafts.csswg.org/css-text/#word-separator
  var wordSeparators = [0x0020, 0x00a0, 0x1361, 0x10100, 0x10101, 0x1039, 0x1091];
  var breakWords = function (str, styles) {
      var breaker = LineBreaker(str, {
          lineBreak: styles.lineBreak,
          wordBreak: styles.overflowWrap === "break-word" /* BREAK_WORD */ ? 'break-word' : styles.wordBreak
      });
      var words = [];
      var bk;
      var _loop_1 = function () {
          if (bk.value) {
              var value = bk.value.slice();
              var codePoints = toCodePoints$1(value);
              var word_1 = '';
              codePoints.forEach(function (codePoint) {
                  if (wordSeparators.indexOf(codePoint) === -1) {
                      word_1 += fromCodePoint$1(codePoint);
                  }
                  else {
                      if (word_1.length) {
                          words.push(word_1);
                      }
                      words.push(fromCodePoint$1(codePoint));
                      word_1 = '';
                  }
              });
              if (word_1.length) {
                  words.push(word_1);
              }
          }
      };
      while (!(bk = breaker.next()).done) {
          _loop_1();
      }
      return words;
  };

  var TextContainer = /** @class */ (function () {
      function TextContainer(context, node, styles) {
          this.text = transform(node.data, styles.textTransform);
          this.textBounds = parseTextBounds(context, this.text, styles, node);
      }
      return TextContainer;
  }());
  var transform = function (text, transform) {
      switch (transform) {
          case 1 /* LOWERCASE */:
              return text.toLowerCase();
          case 3 /* CAPITALIZE */:
              return text.replace(CAPITALIZE, capitalize);
          case 2 /* UPPERCASE */:
              return text.toUpperCase();
          default:
              return text;
      }
  };
  var CAPITALIZE = /(^|\s|:|-|\(|\))([a-z])/g;
  var capitalize = function (m, p1, p2) {
      if (m.length > 0) {
          return p1 + p2.toUpperCase();
      }
      return m;
  };

  var ImageElementContainer = /** @class */ (function (_super) {
      __extends(ImageElementContainer, _super);
      function ImageElementContainer(context, img) {
          var _this = _super.call(this, context, img) || this;
          _this.src = img.currentSrc || img.src;
          _this.intrinsicWidth = img.naturalWidth;
          _this.intrinsicHeight = img.naturalHeight;
          _this.context.cache.addImage(_this.src);
          return _this;
      }
      return ImageElementContainer;
  }(ElementContainer));

  var CanvasElementContainer = /** @class */ (function (_super) {
      __extends(CanvasElementContainer, _super);
      function CanvasElementContainer(context, canvas) {
          var _this = _super.call(this, context, canvas) || this;
          _this.canvas = canvas;
          _this.intrinsicWidth = canvas.width;
          _this.intrinsicHeight = canvas.height;
          return _this;
      }
      return CanvasElementContainer;
  }(ElementContainer));

  var SVGElementContainer = /** @class */ (function (_super) {
      __extends(SVGElementContainer, _super);
      function SVGElementContainer(context, img) {
          var _this = _super.call(this, context, img) || this;
          var s = new XMLSerializer();
          var bounds = parseBounds(context, img);
          img.setAttribute('width', bounds.width + "px");
          img.setAttribute('height', bounds.height + "px");
          _this.svg = "data:image/svg+xml," + encodeURIComponent(s.serializeToString(img));
          _this.intrinsicWidth = img.width.baseVal.value;
          _this.intrinsicHeight = img.height.baseVal.value;
          _this.context.cache.addImage(_this.svg);
          return _this;
      }
      return SVGElementContainer;
  }(ElementContainer));

  var LIElementContainer = /** @class */ (function (_super) {
      __extends(LIElementContainer, _super);
      function LIElementContainer(context, element) {
          var _this = _super.call(this, context, element) || this;
          _this.value = element.value;
          return _this;
      }
      return LIElementContainer;
  }(ElementContainer));

  var OLElementContainer = /** @class */ (function (_super) {
      __extends(OLElementContainer, _super);
      function OLElementContainer(context, element) {
          var _this = _super.call(this, context, element) || this;
          _this.start = element.start;
          _this.reversed = typeof element.reversed === 'boolean' && element.reversed === true;
          return _this;
      }
      return OLElementContainer;
  }(ElementContainer));

  var CHECKBOX_BORDER_RADIUS = [
      {
          type: 15 /* DIMENSION_TOKEN */,
          flags: 0,
          unit: 'px',
          number: 3
      }
  ];
  var RADIO_BORDER_RADIUS = [
      {
          type: 16 /* PERCENTAGE_TOKEN */,
          flags: 0,
          number: 50
      }
  ];
  var reformatInputBounds = function (bounds) {
      if (bounds.width > bounds.height) {
          return new Bounds(bounds.left + (bounds.width - bounds.height) / 2, bounds.top, bounds.height, bounds.height);
      }
      else if (bounds.width < bounds.height) {
          return new Bounds(bounds.left, bounds.top + (bounds.height - bounds.width) / 2, bounds.width, bounds.width);
      }
      return bounds;
  };
  var getInputValue = function (node) {
      var value = node.type === PASSWORD ? new Array(node.value.length + 1).join('\u2022') : node.value;
      return value.length === 0 ? node.placeholder || '' : value;
  };
  var CHECKBOX = 'checkbox';
  var RADIO = 'radio';
  var PASSWORD = 'password';
  var INPUT_COLOR = 0x2a2a2aff;
  var InputElementContainer = /** @class */ (function (_super) {
      __extends(InputElementContainer, _super);
      function InputElementContainer(context, input) {
          var _this = _super.call(this, context, input) || this;
          _this.type = input.type.toLowerCase();
          _this.checked = input.checked;
          _this.value = getInputValue(input);
          if (_this.type === CHECKBOX || _this.type === RADIO) {
              _this.styles.backgroundColor = 0xdededeff;
              _this.styles.borderTopColor =
                  _this.styles.borderRightColor =
                      _this.styles.borderBottomColor =
                          _this.styles.borderLeftColor =
                              0xa5a5a5ff;
              _this.styles.borderTopWidth =
                  _this.styles.borderRightWidth =
                      _this.styles.borderBottomWidth =
                          _this.styles.borderLeftWidth =
                              1;
              _this.styles.borderTopStyle =
                  _this.styles.borderRightStyle =
                      _this.styles.borderBottomStyle =
                          _this.styles.borderLeftStyle =
                              1 /* SOLID */;
              _this.styles.backgroundClip = [0 /* BORDER_BOX */];
              _this.styles.backgroundOrigin = [0 /* BORDER_BOX */];
              _this.bounds = reformatInputBounds(_this.bounds);
          }
          switch (_this.type) {
              case CHECKBOX:
                  _this.styles.borderTopRightRadius =
                      _this.styles.borderTopLeftRadius =
                          _this.styles.borderBottomRightRadius =
                              _this.styles.borderBottomLeftRadius =
                                  CHECKBOX_BORDER_RADIUS;
                  break;
              case RADIO:
                  _this.styles.borderTopRightRadius =
                      _this.styles.borderTopLeftRadius =
                          _this.styles.borderBottomRightRadius =
                              _this.styles.borderBottomLeftRadius =
                                  RADIO_BORDER_RADIUS;
                  break;
          }
          return _this;
      }
      return InputElementContainer;
  }(ElementContainer));

  var SelectElementContainer = /** @class */ (function (_super) {
      __extends(SelectElementContainer, _super);
      function SelectElementContainer(context, element) {
          var _this = _super.call(this, context, element) || this;
          var option = element.options[element.selectedIndex || 0];
          _this.value = option ? option.text || '' : '';
          return _this;
      }
      return SelectElementContainer;
  }(ElementContainer));

  var TextareaElementContainer = /** @class */ (function (_super) {
      __extends(TextareaElementContainer, _super);
      function TextareaElementContainer(context, element) {
          var _this = _super.call(this, context, element) || this;
          _this.value = element.value;
          return _this;
      }
      return TextareaElementContainer;
  }(ElementContainer));

  var IFrameElementContainer = /** @class */ (function (_super) {
      __extends(IFrameElementContainer, _super);
      function IFrameElementContainer(context, iframe) {
          var _this = _super.call(this, context, iframe) || this;
          _this.src = iframe.src;
          _this.width = parseInt(iframe.width, 10) || 0;
          _this.height = parseInt(iframe.height, 10) || 0;
          _this.backgroundColor = _this.styles.backgroundColor;
          try {
              if (iframe.contentWindow &&
                  iframe.contentWindow.document &&
                  iframe.contentWindow.document.documentElement) {
                  _this.tree = parseTree(context, iframe.contentWindow.document.documentElement);
                  // http://www.w3.org/TR/css3-background/#special-backgrounds
                  var documentBackgroundColor = iframe.contentWindow.document.documentElement
                      ? parseColor(context, getComputedStyle(iframe.contentWindow.document.documentElement).backgroundColor)
                      : COLORS.TRANSPARENT;
                  var bodyBackgroundColor = iframe.contentWindow.document.body
                      ? parseColor(context, getComputedStyle(iframe.contentWindow.document.body).backgroundColor)
                      : COLORS.TRANSPARENT;
                  _this.backgroundColor = isTransparent(documentBackgroundColor)
                      ? isTransparent(bodyBackgroundColor)
                          ? _this.styles.backgroundColor
                          : bodyBackgroundColor
                      : documentBackgroundColor;
              }
          }
          catch (e) { }
          return _this;
      }
      return IFrameElementContainer;
  }(ElementContainer));

  var LIST_OWNERS = ['OL', 'UL', 'MENU'];
  var parseNodeTree = function (context, node, parent, root) {
      for (var childNode = node.firstChild, nextNode = void 0; childNode; childNode = nextNode) {
          nextNode = childNode.nextSibling;
          if (isTextNode(childNode) && childNode.data.trim().length > 0) {
              parent.textNodes.push(new TextContainer(context, childNode, parent.styles));
          }
          else if (isElementNode(childNode)) {
              if (isSlotElement(childNode) && childNode.assignedNodes) {
                  childNode.assignedNodes().forEach(function (childNode) { return parseNodeTree(context, childNode, parent, root); });
              }
              else {
                  var container = createContainer(context, childNode);
                  if (container.styles.isVisible()) {
                      if (createsRealStackingContext(childNode, container, root)) {
                          container.flags |= 4 /* CREATES_REAL_STACKING_CONTEXT */;
                      }
                      else if (createsStackingContext(container.styles)) {
                          container.flags |= 2 /* CREATES_STACKING_CONTEXT */;
                      }
                      if (LIST_OWNERS.indexOf(childNode.tagName) !== -1) {
                          container.flags |= 8 /* IS_LIST_OWNER */;
                      }
                      parent.elements.push(container);
                      childNode.slot;
                      if (childNode.shadowRoot) {
                          parseNodeTree(context, childNode.shadowRoot, container, root);
                      }
                      else if (!isTextareaElement(childNode) &&
                          !isSVGElement(childNode) &&
                          !isSelectElement(childNode)) {
                          parseNodeTree(context, childNode, container, root);
                      }
                  }
              }
          }
      }
  };
  var createContainer = function (context, element) {
      if (isImageElement(element)) {
          return new ImageElementContainer(context, element);
      }
      if (isCanvasElement(element)) {
          return new CanvasElementContainer(context, element);
      }
      if (isSVGElement(element)) {
          return new SVGElementContainer(context, element);
      }
      if (isLIElement(element)) {
          return new LIElementContainer(context, element);
      }
      if (isOLElement(element)) {
          return new OLElementContainer(context, element);
      }
      if (isInputElement(element)) {
          return new InputElementContainer(context, element);
      }
      if (isSelectElement(element)) {
          return new SelectElementContainer(context, element);
      }
      if (isTextareaElement(element)) {
          return new TextareaElementContainer(context, element);
      }
      if (isIFrameElement(element)) {
          return new IFrameElementContainer(context, element);
      }
      return new ElementContainer(context, element);
  };
  var parseTree = function (context, element) {
      var container = createContainer(context, element);
      container.flags |= 4 /* CREATES_REAL_STACKING_CONTEXT */;
      parseNodeTree(context, element, container, container);
      return container;
  };
  var createsRealStackingContext = function (node, container, root) {
      return (container.styles.isPositionedWithZIndex() ||
          container.styles.opacity < 1 ||
          container.styles.isTransformed() ||
          (isBodyElement(node) && root.styles.isTransparent()));
  };
  var createsStackingContext = function (styles) { return styles.isPositioned() || styles.isFloating(); };
  var isTextNode = function (node) { return node.nodeType === Node.TEXT_NODE; };
  var isElementNode = function (node) { return node.nodeType === Node.ELEMENT_NODE; };
  var isHTMLElementNode = function (node) {
      return isElementNode(node) && typeof node.style !== 'undefined' && !isSVGElementNode(node);
  };
  var isSVGElementNode = function (element) {
      return typeof element.className === 'object';
  };
  var isLIElement = function (node) { return node.tagName === 'LI'; };
  var isOLElement = function (node) { return node.tagName === 'OL'; };
  var isInputElement = function (node) { return node.tagName === 'INPUT'; };
  var isSVGElement = function (node) { return node.tagName === 'svg'; };
  var isBodyElement = function (node) { return node.tagName === 'BODY'; };
  var isCanvasElement = function (node) { return node.tagName === 'CANVAS'; };
  var isImageElement = function (node) { return node.tagName === 'IMG'; };
  var isIFrameElement = function (node) { return node.tagName === 'IFRAME'; };
  var isTextareaElement = function (node) { return node.tagName === 'TEXTAREA'; };
  var isSelectElement = function (node) { return node.tagName === 'SELECT'; };
  var isSlotElement = function (node) { return node.tagName === 'SLOT'; };
  var ROMAN_UPPER = {
      integers: [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1],
      values: ['M', 'CM', 'D', 'CD', 'C', 'XC', 'L', 'XL', 'X', 'IX', 'V', 'IV', 'I']
  };
  var ARMENIAN = {
      integers: [
          9000, 8000, 7000, 6000, 5000, 4000, 3000, 2000, 1000, 900, 800, 700, 600, 500, 400, 300, 200, 100, 90, 80, 70,
          60, 50, 40, 30, 20, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1
      ],
      values: [
          'Ք',
          'Փ',
          'Ւ',
          'Ց',
          'Ր',
          'Տ',
          'Վ',
          'Ս',
          'Ռ',
          'Ջ',
          'Պ',
          'Չ',
          'Ո',
          'Շ',
          'Ն',
          'Յ',
          'Մ',
          'Ճ',
          'Ղ',
          'Ձ',
          'Հ',
          'Կ',
          'Ծ',
          'Խ',
          'Լ',
          'Ի',
          'Ժ',
          'Թ',
          'Ը',
          'Է',
          'Զ',
          'Ե',
          'Դ',
          'Գ',
          'Բ',
          'Ա'
      ]
  };
  var HEBREW = {
      integers: [
          10000, 9000, 8000, 7000, 6000, 5000, 4000, 3000, 2000, 1000, 400, 300, 200, 100, 90, 80, 70, 60, 50, 40, 30, 20,
          19, 18, 17, 16, 15, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1
      ],
      values: [
          'י׳',
          'ט׳',
          'ח׳',
          'ז׳',
          'ו׳',
          'ה׳',
          'ד׳',
          'ג׳',
          'ב׳',
          'א׳',
          'ת',
          'ש',
          'ר',
          'ק',
          'צ',
          'פ',
          'ע',
          'ס',
          'נ',
          'מ',
          'ל',
          'כ',
          'יט',
          'יח',
          'יז',
          'טז',
          'טו',
          'י',
          'ט',
          'ח',
          'ז',
          'ו',
          'ה',
          'ד',
          'ג',
          'ב',
          'א'
      ]
  };
  var GEORGIAN = {
      integers: [
          10000, 9000, 8000, 7000, 6000, 5000, 4000, 3000, 2000, 1000, 900, 800, 700, 600, 500, 400, 300, 200, 100, 90,
          80, 70, 60, 50, 40, 30, 20, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1
      ],
      values: [
          'ჵ',
          'ჰ',
          'ჯ',
          'ჴ',
          'ხ',
          'ჭ',
          'წ',
          'ძ',
          'ც',
          'ჩ',
          'შ',
          'ყ',
          'ღ',
          'ქ',
          'ფ',
          'ჳ',
          'ტ',
          'ს',
          'რ',
          'ჟ',
          'პ',
          'ო',
          'ჲ',
          'ნ',
          'მ',
          'ლ',
          'კ',
          'ი',
          'თ',
          'ჱ',
          'ზ',
          'ვ',
          'ე',
          'დ',
          'გ',
          'ბ',
          'ა'
      ]
  };
  var createAdditiveCounter = function (value, min, max, symbols, fallback, suffix) {
      if (value < min || value > max) {
          return createCounterText(value, fallback, suffix.length > 0);
      }
      return (symbols.integers.reduce(function (string, integer, index) {
          while (value >= integer) {
              value -= integer;
              string += symbols.values[index];
          }
          return string;
      }, '') + suffix);
  };
  var createCounterStyleWithSymbolResolver = function (value, codePointRangeLength, isNumeric, resolver) {
      var string = '';
      do {
          if (!isNumeric) {
              value--;
          }
          string = resolver(value) + string;
          value /= codePointRangeLength;
      } while (value * codePointRangeLength >= codePointRangeLength);
      return string;
  };
  var createCounterStyleFromRange = function (value, codePointRangeStart, codePointRangeEnd, isNumeric, suffix) {
      var codePointRangeLength = codePointRangeEnd - codePointRangeStart + 1;
      return ((value < 0 ? '-' : '') +
          (createCounterStyleWithSymbolResolver(Math.abs(value), codePointRangeLength, isNumeric, function (codePoint) {
              return fromCodePoint$1(Math.floor(codePoint % codePointRangeLength) + codePointRangeStart);
          }) +
              suffix));
  };
  var createCounterStyleFromSymbols = function (value, symbols, suffix) {
      if (suffix === void 0) { suffix = '. '; }
      var codePointRangeLength = symbols.length;
      return (createCounterStyleWithSymbolResolver(Math.abs(value), codePointRangeLength, false, function (codePoint) { return symbols[Math.floor(codePoint % codePointRangeLength)]; }) + suffix);
  };
  var CJK_ZEROS = 1 << 0;
  var CJK_TEN_COEFFICIENTS = 1 << 1;
  var CJK_TEN_HIGH_COEFFICIENTS = 1 << 2;
  var CJK_HUNDRED_COEFFICIENTS = 1 << 3;
  var createCJKCounter = function (value, numbers, multipliers, negativeSign, suffix, flags) {
      if (value < -9999 || value > 9999) {
          return createCounterText(value, 4 /* CJK_DECIMAL */, suffix.length > 0);
      }
      var tmp = Math.abs(value);
      var string = suffix;
      if (tmp === 0) {
          return numbers[0] + string;
      }
      for (var digit = 0; tmp > 0 && digit <= 4; digit++) {
          var coefficient = tmp % 10;
          if (coefficient === 0 && contains(flags, CJK_ZEROS) && string !== '') {
              string = numbers[coefficient] + string;
          }
          else if (coefficient > 1 ||
              (coefficient === 1 && digit === 0) ||
              (coefficient === 1 && digit === 1 && contains(flags, CJK_TEN_COEFFICIENTS)) ||
              (coefficient === 1 && digit === 1 && contains(flags, CJK_TEN_HIGH_COEFFICIENTS) && value > 100) ||
              (coefficient === 1 && digit > 1 && contains(flags, CJK_HUNDRED_COEFFICIENTS))) {
              string = numbers[coefficient] + (digit > 0 ? multipliers[digit - 1] : '') + string;
          }
          else if (coefficient === 1 && digit > 0) {
              string = multipliers[digit - 1] + string;
          }
          tmp = Math.floor(tmp / 10);
      }
      return (value < 0 ? negativeSign : '') + string;
  };
  var CHINESE_INFORMAL_MULTIPLIERS = '十百千萬';
  var CHINESE_FORMAL_MULTIPLIERS = '拾佰仟萬';
  var JAPANESE_NEGATIVE = 'マイナス';
  var KOREAN_NEGATIVE = '마이너스';
  var createCounterText = function (value, type, appendSuffix) {
      var defaultSuffix = appendSuffix ? '. ' : '';
      var cjkSuffix = appendSuffix ? '、' : '';
      var koreanSuffix = appendSuffix ? ', ' : '';
      var spaceSuffix = appendSuffix ? ' ' : '';
      switch (type) {
          case 0 /* DISC */:
              return '•' + spaceSuffix;
          case 1 /* CIRCLE */:
              return '◦' + spaceSuffix;
          case 2 /* SQUARE */:
              return '◾' + spaceSuffix;
          case 5 /* DECIMAL_LEADING_ZERO */:
              var string = createCounterStyleFromRange(value, 48, 57, true, defaultSuffix);
              return string.length < 4 ? "0" + string : string;
          case 4 /* CJK_DECIMAL */:
              return createCounterStyleFromSymbols(value, '〇一二三四五六七八九', cjkSuffix);
          case 6 /* LOWER_ROMAN */:
              return createAdditiveCounter(value, 1, 3999, ROMAN_UPPER, 3 /* DECIMAL */, defaultSuffix).toLowerCase();
          case 7 /* UPPER_ROMAN */:
              return createAdditiveCounter(value, 1, 3999, ROMAN_UPPER, 3 /* DECIMAL */, defaultSuffix);
          case 8 /* LOWER_GREEK */:
              return createCounterStyleFromRange(value, 945, 969, false, defaultSuffix);
          case 9 /* LOWER_ALPHA */:
              return createCounterStyleFromRange(value, 97, 122, false, defaultSuffix);
          case 10 /* UPPER_ALPHA */:
              return createCounterStyleFromRange(value, 65, 90, false, defaultSuffix);
          case 11 /* ARABIC_INDIC */:
              return createCounterStyleFromRange(value, 1632, 1641, true, defaultSuffix);
          case 12 /* ARMENIAN */:
          case 49 /* UPPER_ARMENIAN */:
              return createAdditiveCounter(value, 1, 9999, ARMENIAN, 3 /* DECIMAL */, defaultSuffix);
          case 35 /* LOWER_ARMENIAN */:
              return createAdditiveCounter(value, 1, 9999, ARMENIAN, 3 /* DECIMAL */, defaultSuffix).toLowerCase();
          case 13 /* BENGALI */:
              return createCounterStyleFromRange(value, 2534, 2543, true, defaultSuffix);
          case 14 /* CAMBODIAN */:
          case 30 /* KHMER */:
              return createCounterStyleFromRange(value, 6112, 6121, true, defaultSuffix);
          case 15 /* CJK_EARTHLY_BRANCH */:
              return createCounterStyleFromSymbols(value, '子丑寅卯辰巳午未申酉戌亥', cjkSuffix);
          case 16 /* CJK_HEAVENLY_STEM */:
              return createCounterStyleFromSymbols(value, '甲乙丙丁戊己庚辛壬癸', cjkSuffix);
          case 17 /* CJK_IDEOGRAPHIC */:
          case 48 /* TRAD_CHINESE_INFORMAL */:
              return createCJKCounter(value, '零一二三四五六七八九', CHINESE_INFORMAL_MULTIPLIERS, '負', cjkSuffix, CJK_TEN_COEFFICIENTS | CJK_TEN_HIGH_COEFFICIENTS | CJK_HUNDRED_COEFFICIENTS);
          case 47 /* TRAD_CHINESE_FORMAL */:
              return createCJKCounter(value, '零壹貳參肆伍陸柒捌玖', CHINESE_FORMAL_MULTIPLIERS, '負', cjkSuffix, CJK_ZEROS | CJK_TEN_COEFFICIENTS | CJK_TEN_HIGH_COEFFICIENTS | CJK_HUNDRED_COEFFICIENTS);
          case 42 /* SIMP_CHINESE_INFORMAL */:
              return createCJKCounter(value, '零一二三四五六七八九', CHINESE_INFORMAL_MULTIPLIERS, '负', cjkSuffix, CJK_TEN_COEFFICIENTS | CJK_TEN_HIGH_COEFFICIENTS | CJK_HUNDRED_COEFFICIENTS);
          case 41 /* SIMP_CHINESE_FORMAL */:
              return createCJKCounter(value, '零壹贰叁肆伍陆柒捌玖', CHINESE_FORMAL_MULTIPLIERS, '负', cjkSuffix, CJK_ZEROS | CJK_TEN_COEFFICIENTS | CJK_TEN_HIGH_COEFFICIENTS | CJK_HUNDRED_COEFFICIENTS);
          case 26 /* JAPANESE_INFORMAL */:
              return createCJKCounter(value, '〇一二三四五六七八九', '十百千万', JAPANESE_NEGATIVE, cjkSuffix, 0);
          case 25 /* JAPANESE_FORMAL */:
              return createCJKCounter(value, '零壱弐参四伍六七八九', '拾百千万', JAPANESE_NEGATIVE, cjkSuffix, CJK_ZEROS | CJK_TEN_COEFFICIENTS | CJK_TEN_HIGH_COEFFICIENTS);
          case 31 /* KOREAN_HANGUL_FORMAL */:
              return createCJKCounter(value, '영일이삼사오육칠팔구', '십백천만', KOREAN_NEGATIVE, koreanSuffix, CJK_ZEROS | CJK_TEN_COEFFICIENTS | CJK_TEN_HIGH_COEFFICIENTS);
          case 33 /* KOREAN_HANJA_INFORMAL */:
              return createCJKCounter(value, '零一二三四五六七八九', '十百千萬', KOREAN_NEGATIVE, koreanSuffix, 0);
          case 32 /* KOREAN_HANJA_FORMAL */:
              return createCJKCounter(value, '零壹貳參四五六七八九', '拾百千', KOREAN_NEGATIVE, koreanSuffix, CJK_ZEROS | CJK_TEN_COEFFICIENTS | CJK_TEN_HIGH_COEFFICIENTS);
          case 18 /* DEVANAGARI */:
              return createCounterStyleFromRange(value, 0x966, 0x96f, true, defaultSuffix);
          case 20 /* GEORGIAN */:
              return createAdditiveCounter(value, 1, 19999, GEORGIAN, 3 /* DECIMAL */, defaultSuffix);
          case 21 /* GUJARATI */:
              return createCounterStyleFromRange(value, 0xae6, 0xaef, true, defaultSuffix);
          case 22 /* GURMUKHI */:
              return createCounterStyleFromRange(value, 0xa66, 0xa6f, true, defaultSuffix);
          case 22 /* HEBREW */:
              return createAdditiveCounter(value, 1, 10999, HEBREW, 3 /* DECIMAL */, defaultSuffix);
          case 23 /* HIRAGANA */:
              return createCounterStyleFromSymbols(value, 'あいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほまみむめもやゆよらりるれろわゐゑをん');
          case 24 /* HIRAGANA_IROHA */:
              return createCounterStyleFromSymbols(value, 'いろはにほへとちりぬるをわかよたれそつねならむうゐのおくやまけふこえてあさきゆめみしゑひもせす');
          case 27 /* KANNADA */:
              return createCounterStyleFromRange(value, 0xce6, 0xcef, true, defaultSuffix);
          case 28 /* KATAKANA */:
              return createCounterStyleFromSymbols(value, 'アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヰヱヲン', cjkSuffix);
          case 29 /* KATAKANA_IROHA */:
              return createCounterStyleFromSymbols(value, 'イロハニホヘトチリヌルヲワカヨタレソツネナラムウヰノオクヤマケフコエテアサキユメミシヱヒモセス', cjkSuffix);
          case 34 /* LAO */:
              return createCounterStyleFromRange(value, 0xed0, 0xed9, true, defaultSuffix);
          case 37 /* MONGOLIAN */:
              return createCounterStyleFromRange(value, 0x1810, 0x1819, true, defaultSuffix);
          case 38 /* MYANMAR */:
              return createCounterStyleFromRange(value, 0x1040, 0x1049, true, defaultSuffix);
          case 39 /* ORIYA */:
              return createCounterStyleFromRange(value, 0xb66, 0xb6f, true, defaultSuffix);
          case 40 /* PERSIAN */:
              return createCounterStyleFromRange(value, 0x6f0, 0x6f9, true, defaultSuffix);
          case 43 /* TAMIL */:
              return createCounterStyleFromRange(value, 0xbe6, 0xbef, true, defaultSuffix);
          case 44 /* TELUGU */:
              return createCounterStyleFromRange(value, 0xc66, 0xc6f, true, defaultSuffix);
          case 45 /* THAI */:
              return createCounterStyleFromRange(value, 0xe50, 0xe59, true, defaultSuffix);
          case 46 /* TIBETAN */:
              return createCounterStyleFromRange(value, 0xf20, 0xf29, true, defaultSuffix);
          case 3 /* DECIMAL */:
          default:
              return createCounterStyleFromRange(value, 48, 57, true, defaultSuffix);
      }
  };
  var PseudoElementType;
  (function (PseudoElementType) {
      PseudoElementType[PseudoElementType["BEFORE"] = 0] = "BEFORE";
      PseudoElementType[PseudoElementType["AFTER"] = 1] = "AFTER";
  })(PseudoElementType || (PseudoElementType = {}));

  var CacheStorage = /** @class */ (function () {
      function CacheStorage() {
      }
      CacheStorage.getOrigin = function (url) {
          var link = CacheStorage._link;
          if (!link) {
              return 'about:blank';
          }
          link.href = url;
          link.href = link.href; // IE9, LOL! - http://jsfiddle.net/niklasvh/2e48b/
          return link.protocol + link.hostname + link.port;
      };
      CacheStorage.isSameOrigin = function (src) {
          return CacheStorage.getOrigin(src) === CacheStorage._origin;
      };
      CacheStorage.setContext = function (window) {
          CacheStorage._link = window.document.createElement('a');
          CacheStorage._origin = CacheStorage.getOrigin(window.location.href);
      };
      CacheStorage._origin = 'about:blank';
      return CacheStorage;
  }());

  var Vector = /** @class */ (function () {
      function Vector(x, y) {
          this.type = 0 /* VECTOR */;
          this.x = x;
          this.y = y;
      }
      Vector.prototype.add = function (deltaX, deltaY) {
          return new Vector(this.x + deltaX, this.y + deltaY);
      };
      return Vector;
  }());

  var lerp = function (a, b, t) {
      return new Vector(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t);
  };
  var BezierCurve = /** @class */ (function () {
      function BezierCurve(start, startControl, endControl, end) {
          this.type = 1 /* BEZIER_CURVE */;
          this.start = start;
          this.startControl = startControl;
          this.endControl = endControl;
          this.end = end;
      }
      BezierCurve.prototype.subdivide = function (t, firstHalf) {
          var ab = lerp(this.start, this.startControl, t);
          var bc = lerp(this.startControl, this.endControl, t);
          var cd = lerp(this.endControl, this.end, t);
          var abbc = lerp(ab, bc, t);
          var bccd = lerp(bc, cd, t);
          var dest = lerp(abbc, bccd, t);
          return firstHalf ? new BezierCurve(this.start, ab, abbc, dest) : new BezierCurve(dest, bccd, cd, this.end);
      };
      BezierCurve.prototype.add = function (deltaX, deltaY) {
          return new BezierCurve(this.start.add(deltaX, deltaY), this.startControl.add(deltaX, deltaY), this.endControl.add(deltaX, deltaY), this.end.add(deltaX, deltaY));
      };
      BezierCurve.prototype.reverse = function () {
          return new BezierCurve(this.end, this.endControl, this.startControl, this.start);
      };
      return BezierCurve;
  }());
  var isBezierCurve = function (path) { return path.type === 1 /* BEZIER_CURVE */; };

  var BoundCurves = /** @class */ (function () {
      function BoundCurves(element) {
          var styles = element.styles;
          var bounds = element.bounds;
          var _a = getAbsoluteValueForTuple(styles.borderTopLeftRadius, bounds.width, bounds.height), tlh = _a[0], tlv = _a[1];
          var _b = getAbsoluteValueForTuple(styles.borderTopRightRadius, bounds.width, bounds.height), trh = _b[0], trv = _b[1];
          var _c = getAbsoluteValueForTuple(styles.borderBottomRightRadius, bounds.width, bounds.height), brh = _c[0], brv = _c[1];
          var _d = getAbsoluteValueForTuple(styles.borderBottomLeftRadius, bounds.width, bounds.height), blh = _d[0], blv = _d[1];
          var factors = [];
          factors.push((tlh + trh) / bounds.width);
          factors.push((blh + brh) / bounds.width);
          factors.push((tlv + blv) / bounds.height);
          factors.push((trv + brv) / bounds.height);
          var maxFactor = Math.max.apply(Math, factors);
          if (maxFactor > 1) {
              tlh /= maxFactor;
              tlv /= maxFactor;
              trh /= maxFactor;
              trv /= maxFactor;
              brh /= maxFactor;
              brv /= maxFactor;
              blh /= maxFactor;
              blv /= maxFactor;
          }
          var topWidth = bounds.width - trh;
          var rightHeight = bounds.height - brv;
          var bottomWidth = bounds.width - brh;
          var leftHeight = bounds.height - blv;
          var borderTopWidth = styles.borderTopWidth;
          var borderRightWidth = styles.borderRightWidth;
          var borderBottomWidth = styles.borderBottomWidth;
          var borderLeftWidth = styles.borderLeftWidth;
          var paddingTop = getAbsoluteValue(styles.paddingTop, element.bounds.width);
          var paddingRight = getAbsoluteValue(styles.paddingRight, element.bounds.width);
          var paddingBottom = getAbsoluteValue(styles.paddingBottom, element.bounds.width);
          var paddingLeft = getAbsoluteValue(styles.paddingLeft, element.bounds.width);
          this.topLeftBorderDoubleOuterBox =
              tlh > 0 || tlv > 0
                  ? getCurvePoints(bounds.left + borderLeftWidth / 3, bounds.top + borderTopWidth / 3, tlh - borderLeftWidth / 3, tlv - borderTopWidth / 3, CORNER.TOP_LEFT)
                  : new Vector(bounds.left + borderLeftWidth / 3, bounds.top + borderTopWidth / 3);
          this.topRightBorderDoubleOuterBox =
              tlh > 0 || tlv > 0
                  ? getCurvePoints(bounds.left + topWidth, bounds.top + borderTopWidth / 3, trh - borderRightWidth / 3, trv - borderTopWidth / 3, CORNER.TOP_RIGHT)
                  : new Vector(bounds.left + bounds.width - borderRightWidth / 3, bounds.top + borderTopWidth / 3);
          this.bottomRightBorderDoubleOuterBox =
              brh > 0 || brv > 0
                  ? getCurvePoints(bounds.left + bottomWidth, bounds.top + rightHeight, brh - borderRightWidth / 3, brv - borderBottomWidth / 3, CORNER.BOTTOM_RIGHT)
                  : new Vector(bounds.left + bounds.width - borderRightWidth / 3, bounds.top + bounds.height - borderBottomWidth / 3);
          this.bottomLeftBorderDoubleOuterBox =
              blh > 0 || blv > 0
                  ? getCurvePoints(bounds.left + borderLeftWidth / 3, bounds.top + leftHeight, blh - borderLeftWidth / 3, blv - borderBottomWidth / 3, CORNER.BOTTOM_LEFT)
                  : new Vector(bounds.left + borderLeftWidth / 3, bounds.top + bounds.height - borderBottomWidth / 3);
          this.topLeftBorderDoubleInnerBox =
              tlh > 0 || tlv > 0
                  ? getCurvePoints(bounds.left + (borderLeftWidth * 2) / 3, bounds.top + (borderTopWidth * 2) / 3, tlh - (borderLeftWidth * 2) / 3, tlv - (borderTopWidth * 2) / 3, CORNER.TOP_LEFT)
                  : new Vector(bounds.left + (borderLeftWidth * 2) / 3, bounds.top + (borderTopWidth * 2) / 3);
          this.topRightBorderDoubleInnerBox =
              tlh > 0 || tlv > 0
                  ? getCurvePoints(bounds.left + topWidth, bounds.top + (borderTopWidth * 2) / 3, trh - (borderRightWidth * 2) / 3, trv - (borderTopWidth * 2) / 3, CORNER.TOP_RIGHT)
                  : new Vector(bounds.left + bounds.width - (borderRightWidth * 2) / 3, bounds.top + (borderTopWidth * 2) / 3);
          this.bottomRightBorderDoubleInnerBox =
              brh > 0 || brv > 0
                  ? getCurvePoints(bounds.left + bottomWidth, bounds.top + rightHeight, brh - (borderRightWidth * 2) / 3, brv - (borderBottomWidth * 2) / 3, CORNER.BOTTOM_RIGHT)
                  : new Vector(bounds.left + bounds.width - (borderRightWidth * 2) / 3, bounds.top + bounds.height - (borderBottomWidth * 2) / 3);
          this.bottomLeftBorderDoubleInnerBox =
              blh > 0 || blv > 0
                  ? getCurvePoints(bounds.left + (borderLeftWidth * 2) / 3, bounds.top + leftHeight, blh - (borderLeftWidth * 2) / 3, blv - (borderBottomWidth * 2) / 3, CORNER.BOTTOM_LEFT)
                  : new Vector(bounds.left + (borderLeftWidth * 2) / 3, bounds.top + bounds.height - (borderBottomWidth * 2) / 3);
          this.topLeftBorderStroke =
              tlh > 0 || tlv > 0
                  ? getCurvePoints(bounds.left + borderLeftWidth / 2, bounds.top + borderTopWidth / 2, tlh - borderLeftWidth / 2, tlv - borderTopWidth / 2, CORNER.TOP_LEFT)
                  : new Vector(bounds.left + borderLeftWidth / 2, bounds.top + borderTopWidth / 2);
          this.topRightBorderStroke =
              tlh > 0 || tlv > 0
                  ? getCurvePoints(bounds.left + topWidth, bounds.top + borderTopWidth / 2, trh - borderRightWidth / 2, trv - borderTopWidth / 2, CORNER.TOP_RIGHT)
                  : new Vector(bounds.left + bounds.width - borderRightWidth / 2, bounds.top + borderTopWidth / 2);
          this.bottomRightBorderStroke =
              brh > 0 || brv > 0
                  ? getCurvePoints(bounds.left + bottomWidth, bounds.top + rightHeight, brh - borderRightWidth / 2, brv - borderBottomWidth / 2, CORNER.BOTTOM_RIGHT)
                  : new Vector(bounds.left + bounds.width - borderRightWidth / 2, bounds.top + bounds.height - borderBottomWidth / 2);
          this.bottomLeftBorderStroke =
              blh > 0 || blv > 0
                  ? getCurvePoints(bounds.left + borderLeftWidth / 2, bounds.top + leftHeight, blh - borderLeftWidth / 2, blv - borderBottomWidth / 2, CORNER.BOTTOM_LEFT)
                  : new Vector(bounds.left + borderLeftWidth / 2, bounds.top + bounds.height - borderBottomWidth / 2);
          this.topLeftBorderBox =
              tlh > 0 || tlv > 0
                  ? getCurvePoints(bounds.left, bounds.top, tlh, tlv, CORNER.TOP_LEFT)
                  : new Vector(bounds.left, bounds.top);
          this.topRightBorderBox =
              trh > 0 || trv > 0
                  ? getCurvePoints(bounds.left + topWidth, bounds.top, trh, trv, CORNER.TOP_RIGHT)
                  : new Vector(bounds.left + bounds.width, bounds.top);
          this.bottomRightBorderBox =
              brh > 0 || brv > 0
                  ? getCurvePoints(bounds.left + bottomWidth, bounds.top + rightHeight, brh, brv, CORNER.BOTTOM_RIGHT)
                  : new Vector(bounds.left + bounds.width, bounds.top + bounds.height);
          this.bottomLeftBorderBox =
              blh > 0 || blv > 0
                  ? getCurvePoints(bounds.left, bounds.top + leftHeight, blh, blv, CORNER.BOTTOM_LEFT)
                  : new Vector(bounds.left, bounds.top + bounds.height);
          this.topLeftPaddingBox =
              tlh > 0 || tlv > 0
                  ? getCurvePoints(bounds.left + borderLeftWidth, bounds.top + borderTopWidth, Math.max(0, tlh - borderLeftWidth), Math.max(0, tlv - borderTopWidth), CORNER.TOP_LEFT)
                  : new Vector(bounds.left + borderLeftWidth, bounds.top + borderTopWidth);
          this.topRightPaddingBox =
              trh > 0 || trv > 0
                  ? getCurvePoints(bounds.left + Math.min(topWidth, bounds.width - borderRightWidth), bounds.top + borderTopWidth, topWidth > bounds.width + borderRightWidth ? 0 : Math.max(0, trh - borderRightWidth), Math.max(0, trv - borderTopWidth), CORNER.TOP_RIGHT)
                  : new Vector(bounds.left + bounds.width - borderRightWidth, bounds.top + borderTopWidth);
          this.bottomRightPaddingBox =
              brh > 0 || brv > 0
                  ? getCurvePoints(bounds.left + Math.min(bottomWidth, bounds.width - borderLeftWidth), bounds.top + Math.min(rightHeight, bounds.height - borderBottomWidth), Math.max(0, brh - borderRightWidth), Math.max(0, brv - borderBottomWidth), CORNER.BOTTOM_RIGHT)
                  : new Vector(bounds.left + bounds.width - borderRightWidth, bounds.top + bounds.height - borderBottomWidth);
          this.bottomLeftPaddingBox =
              blh > 0 || blv > 0
                  ? getCurvePoints(bounds.left + borderLeftWidth, bounds.top + Math.min(leftHeight, bounds.height - borderBottomWidth), Math.max(0, blh - borderLeftWidth), Math.max(0, blv - borderBottomWidth), CORNER.BOTTOM_LEFT)
                  : new Vector(bounds.left + borderLeftWidth, bounds.top + bounds.height - borderBottomWidth);
          this.topLeftContentBox =
              tlh > 0 || tlv > 0
                  ? getCurvePoints(bounds.left + borderLeftWidth + paddingLeft, bounds.top + borderTopWidth + paddingTop, Math.max(0, tlh - (borderLeftWidth + paddingLeft)), Math.max(0, tlv - (borderTopWidth + paddingTop)), CORNER.TOP_LEFT)
                  : new Vector(bounds.left + borderLeftWidth + paddingLeft, bounds.top + borderTopWidth + paddingTop);
          this.topRightContentBox =
              trh > 0 || trv > 0
                  ? getCurvePoints(bounds.left + Math.min(topWidth, bounds.width + borderLeftWidth + paddingLeft), bounds.top + borderTopWidth + paddingTop, topWidth > bounds.width + borderLeftWidth + paddingLeft ? 0 : trh - borderLeftWidth + paddingLeft, trv - (borderTopWidth + paddingTop), CORNER.TOP_RIGHT)
                  : new Vector(bounds.left + bounds.width - (borderRightWidth + paddingRight), bounds.top + borderTopWidth + paddingTop);
          this.bottomRightContentBox =
              brh > 0 || brv > 0
                  ? getCurvePoints(bounds.left + Math.min(bottomWidth, bounds.width - (borderLeftWidth + paddingLeft)), bounds.top + Math.min(rightHeight, bounds.height + borderTopWidth + paddingTop), Math.max(0, brh - (borderRightWidth + paddingRight)), brv - (borderBottomWidth + paddingBottom), CORNER.BOTTOM_RIGHT)
                  : new Vector(bounds.left + bounds.width - (borderRightWidth + paddingRight), bounds.top + bounds.height - (borderBottomWidth + paddingBottom));
          this.bottomLeftContentBox =
              blh > 0 || blv > 0
                  ? getCurvePoints(bounds.left + borderLeftWidth + paddingLeft, bounds.top + leftHeight, Math.max(0, blh - (borderLeftWidth + paddingLeft)), blv - (borderBottomWidth + paddingBottom), CORNER.BOTTOM_LEFT)
                  : new Vector(bounds.left + borderLeftWidth + paddingLeft, bounds.top + bounds.height - (borderBottomWidth + paddingBottom));
      }
      return BoundCurves;
  }());
  var CORNER;
  (function (CORNER) {
      CORNER[CORNER["TOP_LEFT"] = 0] = "TOP_LEFT";
      CORNER[CORNER["TOP_RIGHT"] = 1] = "TOP_RIGHT";
      CORNER[CORNER["BOTTOM_RIGHT"] = 2] = "BOTTOM_RIGHT";
      CORNER[CORNER["BOTTOM_LEFT"] = 3] = "BOTTOM_LEFT";
  })(CORNER || (CORNER = {}));
  var getCurvePoints = function (x, y, r1, r2, position) {
      var kappa = 4 * ((Math.sqrt(2) - 1) / 3);
      var ox = r1 * kappa; // control point offset horizontal
      var oy = r2 * kappa; // control point offset vertical
      var xm = x + r1; // x-middle
      var ym = y + r2; // y-middle
      switch (position) {
          case CORNER.TOP_LEFT:
              return new BezierCurve(new Vector(x, ym), new Vector(x, ym - oy), new Vector(xm - ox, y), new Vector(xm, y));
          case CORNER.TOP_RIGHT:
              return new BezierCurve(new Vector(x, y), new Vector(x + ox, y), new Vector(xm, ym - oy), new Vector(xm, ym));
          case CORNER.BOTTOM_RIGHT:
              return new BezierCurve(new Vector(xm, y), new Vector(xm, y + oy), new Vector(x + ox, ym), new Vector(x, ym));
          case CORNER.BOTTOM_LEFT:
          default:
              return new BezierCurve(new Vector(xm, ym), new Vector(xm - ox, ym), new Vector(x, y + oy), new Vector(x, y));
      }
  };
  var calculateBorderBoxPath = function (curves) {
      return [curves.topLeftBorderBox, curves.topRightBorderBox, curves.bottomRightBorderBox, curves.bottomLeftBorderBox];
  };
  var calculateContentBoxPath = function (curves) {
      return [
          curves.topLeftContentBox,
          curves.topRightContentBox,
          curves.bottomRightContentBox,
          curves.bottomLeftContentBox
      ];
  };
  var calculatePaddingBoxPath = function (curves) {
      return [
          curves.topLeftPaddingBox,
          curves.topRightPaddingBox,
          curves.bottomRightPaddingBox,
          curves.bottomLeftPaddingBox
      ];
  };

  var TransformEffect = /** @class */ (function () {
      function TransformEffect(offsetX, offsetY, matrix) {
          this.offsetX = offsetX;
          this.offsetY = offsetY;
          this.matrix = matrix;
          this.type = 0 /* TRANSFORM */;
          this.target = 2 /* BACKGROUND_BORDERS */ | 4 /* CONTENT */;
      }
      return TransformEffect;
  }());
  var ClipEffect = /** @class */ (function () {
      function ClipEffect(path, target) {
          this.path = path;
          this.target = target;
          this.type = 1 /* CLIP */;
      }
      return ClipEffect;
  }());
  var OpacityEffect = /** @class */ (function () {
      function OpacityEffect(opacity) {
          this.opacity = opacity;
          this.type = 2 /* OPACITY */;
          this.target = 2 /* BACKGROUND_BORDERS */ | 4 /* CONTENT */;
      }
      return OpacityEffect;
  }());
  var isTransformEffect = function (effect) {
      return effect.type === 0 /* TRANSFORM */;
  };
  var isClipEffect = function (effect) { return effect.type === 1 /* CLIP */; };
  var isOpacityEffect = function (effect) { return effect.type === 2 /* OPACITY */; };

  var equalPath = function (a, b) {
      if (a.length === b.length) {
          return a.some(function (v, i) { return v === b[i]; });
      }
      return false;
  };
  var transformPath = function (path, deltaX, deltaY, deltaW, deltaH) {
      return path.map(function (point, index) {
          switch (index) {
              case 0:
                  return point.add(deltaX, deltaY);
              case 1:
                  return point.add(deltaX + deltaW, deltaY);
              case 2:
                  return point.add(deltaX + deltaW, deltaY + deltaH);
              case 3:
                  return point.add(deltaX, deltaY + deltaH);
          }
          return point;
      });
  };

  var StackingContext = /** @class */ (function () {
      function StackingContext(container) {
          this.element = container;
          this.inlineLevel = [];
          this.nonInlineLevel = [];
          this.negativeZIndex = [];
          this.zeroOrAutoZIndexOrTransformedOrOpacity = [];
          this.positiveZIndex = [];
          this.nonPositionedFloats = [];
          this.nonPositionedInlineLevel = [];
      }
      return StackingContext;
  }());
  var ElementPaint = /** @class */ (function () {
      function ElementPaint(container, parent) {
          this.container = container;
          this.parent = parent;
          this.effects = [];
          this.curves = new BoundCurves(this.container);
          if (this.container.styles.opacity < 1) {
              this.effects.push(new OpacityEffect(this.container.styles.opacity));
          }
          if (this.container.styles.transform !== null) {
              var offsetX = this.container.bounds.left + this.container.styles.transformOrigin[0].number;
              var offsetY = this.container.bounds.top + this.container.styles.transformOrigin[1].number;
              var matrix = this.container.styles.transform;
              this.effects.push(new TransformEffect(offsetX, offsetY, matrix));
          }
          if (this.container.styles.overflowX !== 0 /* VISIBLE */) {
              var borderBox = calculateBorderBoxPath(this.curves);
              var paddingBox = calculatePaddingBoxPath(this.curves);
              if (equalPath(borderBox, paddingBox)) {
                  this.effects.push(new ClipEffect(borderBox, 2 /* BACKGROUND_BORDERS */ | 4 /* CONTENT */));
              }
              else {
                  this.effects.push(new ClipEffect(borderBox, 2 /* BACKGROUND_BORDERS */));
                  this.effects.push(new ClipEffect(paddingBox, 4 /* CONTENT */));
              }
          }
      }
      ElementPaint.prototype.getEffects = function (target) {
          var inFlow = [2 /* ABSOLUTE */, 3 /* FIXED */].indexOf(this.container.styles.position) === -1;
          var parent = this.parent;
          var effects = this.effects.slice(0);
          while (parent) {
              var croplessEffects = parent.effects.filter(function (effect) { return !isClipEffect(effect); });
              if (inFlow || parent.container.styles.position !== 0 /* STATIC */ || !parent.parent) {
                  effects.unshift.apply(effects, croplessEffects);
                  inFlow = [2 /* ABSOLUTE */, 3 /* FIXED */].indexOf(parent.container.styles.position) === -1;
                  if (parent.container.styles.overflowX !== 0 /* VISIBLE */) {
                      var borderBox = calculateBorderBoxPath(parent.curves);
                      var paddingBox = calculatePaddingBoxPath(parent.curves);
                      if (!equalPath(borderBox, paddingBox)) {
                          effects.unshift(new ClipEffect(paddingBox, 2 /* BACKGROUND_BORDERS */ | 4 /* CONTENT */));
                      }
                  }
              }
              else {
                  effects.unshift.apply(effects, croplessEffects);
              }
              parent = parent.parent;
          }
          return effects.filter(function (effect) { return contains(effect.target, target); });
      };
      return ElementPaint;
  }());
  var parseStackTree = function (parent, stackingContext, realStackingContext, listItems) {
      parent.container.elements.forEach(function (child) {
          var treatAsRealStackingContext = contains(child.flags, 4 /* CREATES_REAL_STACKING_CONTEXT */);
          var createsStackingContext = contains(child.flags, 2 /* CREATES_STACKING_CONTEXT */);
          var paintContainer = new ElementPaint(child, parent);
          if (contains(child.styles.display, 2048 /* LIST_ITEM */)) {
              listItems.push(paintContainer);
          }
          var listOwnerItems = contains(child.flags, 8 /* IS_LIST_OWNER */) ? [] : listItems;
          if (treatAsRealStackingContext || createsStackingContext) {
              var parentStack = treatAsRealStackingContext || child.styles.isPositioned() ? realStackingContext : stackingContext;
              var stack = new StackingContext(paintContainer);
              if (child.styles.isPositioned() || child.styles.opacity < 1 || child.styles.isTransformed()) {
                  var order_1 = child.styles.zIndex.order;
                  if (order_1 < 0) {
                      var index_1 = 0;
                      parentStack.negativeZIndex.some(function (current, i) {
                          if (order_1 > current.element.container.styles.zIndex.order) {
                              index_1 = i;
                              return false;
                          }
                          else if (index_1 > 0) {
                              return true;
                          }
                          return false;
                      });
                      parentStack.negativeZIndex.splice(index_1, 0, stack);
                  }
                  else if (order_1 > 0) {
                      var index_2 = 0;
                      parentStack.positiveZIndex.some(function (current, i) {
                          if (order_1 >= current.element.container.styles.zIndex.order) {
                              index_2 = i + 1;
                              return false;
                          }
                          else if (index_2 > 0) {
                              return true;
                          }
                          return false;
                      });
                      parentStack.positiveZIndex.splice(index_2, 0, stack);
                  }
                  else {
                      parentStack.zeroOrAutoZIndexOrTransformedOrOpacity.push(stack);
                  }
              }
              else {
                  if (child.styles.isFloating()) {
                      parentStack.nonPositionedFloats.push(stack);
                  }
                  else {
                      parentStack.nonPositionedInlineLevel.push(stack);
                  }
              }
              parseStackTree(paintContainer, stack, treatAsRealStackingContext ? stack : realStackingContext, listOwnerItems);
          }
          else {
              if (child.styles.isInlineLevel()) {
                  stackingContext.inlineLevel.push(paintContainer);
              }
              else {
                  stackingContext.nonInlineLevel.push(paintContainer);
              }
              parseStackTree(paintContainer, stackingContext, realStackingContext, listOwnerItems);
          }
          if (contains(child.flags, 8 /* IS_LIST_OWNER */)) {
              processListItems(child, listOwnerItems);
          }
      });
  };
  var processListItems = function (owner, elements) {
      var numbering = owner instanceof OLElementContainer ? owner.start : 1;
      var reversed = owner instanceof OLElementContainer ? owner.reversed : false;
      for (var i = 0; i < elements.length; i++) {
          var item = elements[i];
          if (item.container instanceof LIElementContainer &&
              typeof item.container.value === 'number' &&
              item.container.value !== 0) {
              numbering = item.container.value;
          }
          item.listValue = createCounterText(numbering, item.container.styles.listStyleType, true);
          numbering += reversed ? -1 : 1;
      }
  };
  var parseStackingContexts = function (container) {
      var paintContainer = new ElementPaint(container, null);
      var root = new StackingContext(paintContainer);
      var listItems = [];
      parseStackTree(paintContainer, root, root, listItems);
      processListItems(paintContainer.container, listItems);
      return root;
  };

  var parsePathForBorder = function (curves, borderSide) {
      switch (borderSide) {
          case 0:
              return createPathFromCurves(curves.topLeftBorderBox, curves.topLeftPaddingBox, curves.topRightBorderBox, curves.topRightPaddingBox);
          case 1:
              return createPathFromCurves(curves.topRightBorderBox, curves.topRightPaddingBox, curves.bottomRightBorderBox, curves.bottomRightPaddingBox);
          case 2:
              return createPathFromCurves(curves.bottomRightBorderBox, curves.bottomRightPaddingBox, curves.bottomLeftBorderBox, curves.bottomLeftPaddingBox);
          case 3:
          default:
              return createPathFromCurves(curves.bottomLeftBorderBox, curves.bottomLeftPaddingBox, curves.topLeftBorderBox, curves.topLeftPaddingBox);
      }
  };
  var parsePathForBorderDoubleOuter = function (curves, borderSide) {
      switch (borderSide) {
          case 0:
              return createPathFromCurves(curves.topLeftBorderBox, curves.topLeftBorderDoubleOuterBox, curves.topRightBorderBox, curves.topRightBorderDoubleOuterBox);
          case 1:
              return createPathFromCurves(curves.topRightBorderBox, curves.topRightBorderDoubleOuterBox, curves.bottomRightBorderBox, curves.bottomRightBorderDoubleOuterBox);
          case 2:
              return createPathFromCurves(curves.bottomRightBorderBox, curves.bottomRightBorderDoubleOuterBox, curves.bottomLeftBorderBox, curves.bottomLeftBorderDoubleOuterBox);
          case 3:
          default:
              return createPathFromCurves(curves.bottomLeftBorderBox, curves.bottomLeftBorderDoubleOuterBox, curves.topLeftBorderBox, curves.topLeftBorderDoubleOuterBox);
      }
  };
  var parsePathForBorderDoubleInner = function (curves, borderSide) {
      switch (borderSide) {
          case 0:
              return createPathFromCurves(curves.topLeftBorderDoubleInnerBox, curves.topLeftPaddingBox, curves.topRightBorderDoubleInnerBox, curves.topRightPaddingBox);
          case 1:
              return createPathFromCurves(curves.topRightBorderDoubleInnerBox, curves.topRightPaddingBox, curves.bottomRightBorderDoubleInnerBox, curves.bottomRightPaddingBox);
          case 2:
              return createPathFromCurves(curves.bottomRightBorderDoubleInnerBox, curves.bottomRightPaddingBox, curves.bottomLeftBorderDoubleInnerBox, curves.bottomLeftPaddingBox);
          case 3:
          default:
              return createPathFromCurves(curves.bottomLeftBorderDoubleInnerBox, curves.bottomLeftPaddingBox, curves.topLeftBorderDoubleInnerBox, curves.topLeftPaddingBox);
      }
  };
  var parsePathForBorderStroke = function (curves, borderSide) {
      switch (borderSide) {
          case 0:
              return createStrokePathFromCurves(curves.topLeftBorderStroke, curves.topRightBorderStroke);
          case 1:
              return createStrokePathFromCurves(curves.topRightBorderStroke, curves.bottomRightBorderStroke);
          case 2:
              return createStrokePathFromCurves(curves.bottomRightBorderStroke, curves.bottomLeftBorderStroke);
          case 3:
          default:
              return createStrokePathFromCurves(curves.bottomLeftBorderStroke, curves.topLeftBorderStroke);
      }
  };
  var createStrokePathFromCurves = function (outer1, outer2) {
      var path = [];
      if (isBezierCurve(outer1)) {
          path.push(outer1.subdivide(0.5, false));
      }
      else {
          path.push(outer1);
      }
      if (isBezierCurve(outer2)) {
          path.push(outer2.subdivide(0.5, true));
      }
      else {
          path.push(outer2);
      }
      return path;
  };
  var createPathFromCurves = function (outer1, inner1, outer2, inner2) {
      var path = [];
      if (isBezierCurve(outer1)) {
          path.push(outer1.subdivide(0.5, false));
      }
      else {
          path.push(outer1);
      }
      if (isBezierCurve(outer2)) {
          path.push(outer2.subdivide(0.5, true));
      }
      else {
          path.push(outer2);
      }
      if (isBezierCurve(inner2)) {
          path.push(inner2.subdivide(0.5, true).reverse());
      }
      else {
          path.push(inner2);
      }
      if (isBezierCurve(inner1)) {
          path.push(inner1.subdivide(0.5, false).reverse());
      }
      else {
          path.push(inner1);
      }
      return path;
  };

  var paddingBox = function (element) {
      var bounds = element.bounds;
      var styles = element.styles;
      return bounds.add(styles.borderLeftWidth, styles.borderTopWidth, -(styles.borderRightWidth + styles.borderLeftWidth), -(styles.borderTopWidth + styles.borderBottomWidth));
  };
  var contentBox = function (element) {
      var styles = element.styles;
      var bounds = element.bounds;
      var paddingLeft = getAbsoluteValue(styles.paddingLeft, bounds.width);
      var paddingRight = getAbsoluteValue(styles.paddingRight, bounds.width);
      var paddingTop = getAbsoluteValue(styles.paddingTop, bounds.width);
      var paddingBottom = getAbsoluteValue(styles.paddingBottom, bounds.width);
      return bounds.add(paddingLeft + styles.borderLeftWidth, paddingTop + styles.borderTopWidth, -(styles.borderRightWidth + styles.borderLeftWidth + paddingLeft + paddingRight), -(styles.borderTopWidth + styles.borderBottomWidth + paddingTop + paddingBottom));
  };

  var calculateBackgroundPositioningArea = function (backgroundOrigin, element) {
      if (backgroundOrigin === 0 /* BORDER_BOX */) {
          return element.bounds;
      }
      if (backgroundOrigin === 2 /* CONTENT_BOX */) {
          return contentBox(element);
      }
      return paddingBox(element);
  };
  var calculateBackgroundPaintingArea = function (backgroundClip, element) {
      if (backgroundClip === 0 /* BORDER_BOX */) {
          return element.bounds;
      }
      if (backgroundClip === 2 /* CONTENT_BOX */) {
          return contentBox(element);
      }
      return paddingBox(element);
  };
  var calculateBackgroundRendering = function (container, index, intrinsicSize) {
      var backgroundPositioningArea = calculateBackgroundPositioningArea(getBackgroundValueForIndex(container.styles.backgroundOrigin, index), container);
      var backgroundPaintingArea = calculateBackgroundPaintingArea(getBackgroundValueForIndex(container.styles.backgroundClip, index), container);
      var backgroundImageSize = calculateBackgroundSize(getBackgroundValueForIndex(container.styles.backgroundSize, index), intrinsicSize, backgroundPositioningArea);
      var sizeWidth = backgroundImageSize[0], sizeHeight = backgroundImageSize[1];
      var position = getAbsoluteValueForTuple(getBackgroundValueForIndex(container.styles.backgroundPosition, index), backgroundPositioningArea.width - sizeWidth, backgroundPositioningArea.height - sizeHeight);
      var path = calculateBackgroundRepeatPath(getBackgroundValueForIndex(container.styles.backgroundRepeat, index), position, backgroundImageSize, backgroundPositioningArea, backgroundPaintingArea);
      var offsetX = Math.round(backgroundPositioningArea.left + position[0]);
      var offsetY = Math.round(backgroundPositioningArea.top + position[1]);
      return [path, offsetX, offsetY, sizeWidth, sizeHeight];
  };
  var isAuto = function (token) { return isIdentToken(token) && token.value === BACKGROUND_SIZE.AUTO; };
  var hasIntrinsicValue = function (value) { return typeof value === 'number'; };
  var calculateBackgroundSize = function (size, _a, bounds) {
      var intrinsicWidth = _a[0], intrinsicHeight = _a[1], intrinsicProportion = _a[2];
      var first = size[0], second = size[1];
      if (!first) {
          return [0, 0];
      }
      if (isLengthPercentage(first) && second && isLengthPercentage(second)) {
          return [getAbsoluteValue(first, bounds.width), getAbsoluteValue(second, bounds.height)];
      }
      var hasIntrinsicProportion = hasIntrinsicValue(intrinsicProportion);
      if (isIdentToken(first) && (first.value === BACKGROUND_SIZE.CONTAIN || first.value === BACKGROUND_SIZE.COVER)) {
          if (hasIntrinsicValue(intrinsicProportion)) {
              var targetRatio = bounds.width / bounds.height;
              return targetRatio < intrinsicProportion !== (first.value === BACKGROUND_SIZE.COVER)
                  ? [bounds.width, bounds.width / intrinsicProportion]
                  : [bounds.height * intrinsicProportion, bounds.height];
          }
          return [bounds.width, bounds.height];
      }
      var hasIntrinsicWidth = hasIntrinsicValue(intrinsicWidth);
      var hasIntrinsicHeight = hasIntrinsicValue(intrinsicHeight);
      var hasIntrinsicDimensions = hasIntrinsicWidth || hasIntrinsicHeight;
      // If the background-size is auto or auto auto:
      if (isAuto(first) && (!second || isAuto(second))) {
          // If the image has both horizontal and vertical intrinsic dimensions, it's rendered at that size.
          if (hasIntrinsicWidth && hasIntrinsicHeight) {
              return [intrinsicWidth, intrinsicHeight];
          }
          // If the image has no intrinsic dimensions and has no intrinsic proportions,
          // it's rendered at the size of the background positioning area.
          if (!hasIntrinsicProportion && !hasIntrinsicDimensions) {
              return [bounds.width, bounds.height];
          }
          // TODO If the image has no intrinsic dimensions but has intrinsic proportions, it's rendered as if contain had been specified instead.
          // If the image has only one intrinsic dimension and has intrinsic proportions, it's rendered at the size corresponding to that one dimension.
          // The other dimension is computed using the specified dimension and the intrinsic proportions.
          if (hasIntrinsicDimensions && hasIntrinsicProportion) {
              var width_1 = hasIntrinsicWidth
                  ? intrinsicWidth
                  : intrinsicHeight * intrinsicProportion;
              var height_1 = hasIntrinsicHeight
                  ? intrinsicHeight
                  : intrinsicWidth / intrinsicProportion;
              return [width_1, height_1];
          }
          // If the image has only one intrinsic dimension but has no intrinsic proportions,
          // it's rendered using the specified dimension and the other dimension of the background positioning area.
          var width_2 = hasIntrinsicWidth ? intrinsicWidth : bounds.width;
          var height_2 = hasIntrinsicHeight ? intrinsicHeight : bounds.height;
          return [width_2, height_2];
      }
      // If the image has intrinsic proportions, it's stretched to the specified dimension.
      // The unspecified dimension is computed using the specified dimension and the intrinsic proportions.
      if (hasIntrinsicProportion) {
          var width_3 = 0;
          var height_3 = 0;
          if (isLengthPercentage(first)) {
              width_3 = getAbsoluteValue(first, bounds.width);
          }
          else if (isLengthPercentage(second)) {
              height_3 = getAbsoluteValue(second, bounds.height);
          }
          if (isAuto(first)) {
              width_3 = height_3 * intrinsicProportion;
          }
          else if (!second || isAuto(second)) {
              height_3 = width_3 / intrinsicProportion;
          }
          return [width_3, height_3];
      }
      // If the image has no intrinsic proportions, it's stretched to the specified dimension.
      // The unspecified dimension is computed using the image's corresponding intrinsic dimension,
      // if there is one. If there is no such intrinsic dimension,
      // it becomes the corresponding dimension of the background positioning area.
      var width = null;
      var height = null;
      if (isLengthPercentage(first)) {
          width = getAbsoluteValue(first, bounds.width);
      }
      else if (second && isLengthPercentage(second)) {
          height = getAbsoluteValue(second, bounds.height);
      }
      if (width !== null && (!second || isAuto(second))) {
          height =
              hasIntrinsicWidth && hasIntrinsicHeight
                  ? (width / intrinsicWidth) * intrinsicHeight
                  : bounds.height;
      }
      if (height !== null && isAuto(first)) {
          width =
              hasIntrinsicWidth && hasIntrinsicHeight
                  ? (height / intrinsicHeight) * intrinsicWidth
                  : bounds.width;
      }
      if (width !== null && height !== null) {
          return [width, height];
      }
      throw new Error("Unable to calculate background-size for element");
  };
  var getBackgroundValueForIndex = function (values, index) {
      var value = values[index];
      if (typeof value === 'undefined') {
          return values[0];
      }
      return value;
  };
  var calculateBackgroundRepeatPath = function (repeat, _a, _b, backgroundPositioningArea, backgroundPaintingArea) {
      var x = _a[0], y = _a[1];
      var width = _b[0], height = _b[1];
      switch (repeat) {
          case 2 /* REPEAT_X */:
              return [
                  new Vector(Math.round(backgroundPositioningArea.left), Math.round(backgroundPositioningArea.top + y)),
                  new Vector(Math.round(backgroundPositioningArea.left + backgroundPositioningArea.width), Math.round(backgroundPositioningArea.top + y)),
                  new Vector(Math.round(backgroundPositioningArea.left + backgroundPositioningArea.width), Math.round(height + backgroundPositioningArea.top + y)),
                  new Vector(Math.round(backgroundPositioningArea.left), Math.round(height + backgroundPositioningArea.top + y))
              ];
          case 3 /* REPEAT_Y */:
              return [
                  new Vector(Math.round(backgroundPositioningArea.left + x), Math.round(backgroundPositioningArea.top)),
                  new Vector(Math.round(backgroundPositioningArea.left + x + width), Math.round(backgroundPositioningArea.top)),
                  new Vector(Math.round(backgroundPositioningArea.left + x + width), Math.round(backgroundPositioningArea.height + backgroundPositioningArea.top)),
                  new Vector(Math.round(backgroundPositioningArea.left + x), Math.round(backgroundPositioningArea.height + backgroundPositioningArea.top))
              ];
          case 1 /* NO_REPEAT */:
              return [
                  new Vector(Math.round(backgroundPositioningArea.left + x), Math.round(backgroundPositioningArea.top + y)),
                  new Vector(Math.round(backgroundPositioningArea.left + x + width), Math.round(backgroundPositioningArea.top + y)),
                  new Vector(Math.round(backgroundPositioningArea.left + x + width), Math.round(backgroundPositioningArea.top + y + height)),
                  new Vector(Math.round(backgroundPositioningArea.left + x), Math.round(backgroundPositioningArea.top + y + height))
              ];
          default:
              return [
                  new Vector(Math.round(backgroundPaintingArea.left), Math.round(backgroundPaintingArea.top)),
                  new Vector(Math.round(backgroundPaintingArea.left + backgroundPaintingArea.width), Math.round(backgroundPaintingArea.top)),
                  new Vector(Math.round(backgroundPaintingArea.left + backgroundPaintingArea.width), Math.round(backgroundPaintingArea.height + backgroundPaintingArea.top)),
                  new Vector(Math.round(backgroundPaintingArea.left), Math.round(backgroundPaintingArea.height + backgroundPaintingArea.top))
              ];
      }
  };

  var SMALL_IMAGE = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';

  var SAMPLE_TEXT = 'Hidden Text';
  var FontMetrics = /** @class */ (function () {
      function FontMetrics(document) {
          this._data = {};
          this._document = document;
      }
      FontMetrics.prototype.parseMetrics = function (fontFamily, fontSize) {
          var container = this._document.createElement('div');
          var img = this._document.createElement('img');
          var span = this._document.createElement('span');
          var body = this._document.body;
          container.style.visibility = 'hidden';
          container.style.fontFamily = fontFamily;
          container.style.fontSize = fontSize;
          container.style.margin = '0';
          container.style.padding = '0';
          container.style.whiteSpace = 'nowrap';
          body.appendChild(container);
          img.src = SMALL_IMAGE;
          img.width = 1;
          img.height = 1;
          img.style.margin = '0';
          img.style.padding = '0';
          img.style.verticalAlign = 'baseline';
          span.style.fontFamily = fontFamily;
          span.style.fontSize = fontSize;
          span.style.margin = '0';
          span.style.padding = '0';
          span.appendChild(this._document.createTextNode(SAMPLE_TEXT));
          container.appendChild(span);
          container.appendChild(img);
          var baseline = img.offsetTop - span.offsetTop + 2;
          container.removeChild(span);
          container.appendChild(this._document.createTextNode(SAMPLE_TEXT));
          container.style.lineHeight = 'normal';
          img.style.verticalAlign = 'super';
          var middle = img.offsetTop - container.offsetTop + 2;
          body.removeChild(container);
          return { baseline: baseline, middle: middle };
      };
      FontMetrics.prototype.getMetrics = function (fontFamily, fontSize) {
          var key = fontFamily + " " + fontSize;
          if (typeof this._data[key] === 'undefined') {
              this._data[key] = this.parseMetrics(fontFamily, fontSize);
          }
          return this._data[key];
      };
      return FontMetrics;
  }());

  var Renderer = /** @class */ (function () {
      function Renderer(context, options) {
          this.context = context;
          this.options = options;
      }
      return Renderer;
  }());

  var MASK_OFFSET = 10000;
  /** @class */ ((function (_super) {
      __extends(CanvasRenderer, _super);
      function CanvasRenderer(context, options) {
          var _this = _super.call(this, context, options) || this;
          _this._activeEffects = [];
          _this.canvas = options.canvas ? options.canvas : document.createElement('canvas');
          _this.ctx = _this.canvas.getContext('2d');
          if (!options.canvas) {
              _this.canvas.width = Math.floor(options.width * options.scale);
              _this.canvas.height = Math.floor(options.height * options.scale);
              _this.canvas.style.width = options.width + "px";
              _this.canvas.style.height = options.height + "px";
          }
          _this.fontMetrics = new FontMetrics(document);
          _this.ctx.scale(_this.options.scale, _this.options.scale);
          _this.ctx.translate(-options.x, -options.y);
          _this.ctx.textBaseline = 'bottom';
          _this._activeEffects = [];
          _this.context.logger.debug("Canvas renderer initialized (" + options.width + "x" + options.height + ") with scale " + options.scale);
          return _this;
      }
      CanvasRenderer.prototype.applyEffects = function (effects) {
          var _this = this;
          while (this._activeEffects.length) {
              this.popEffect();
          }
          effects.forEach(function (effect) { return _this.applyEffect(effect); });
      };
      CanvasRenderer.prototype.applyEffect = function (effect) {
          this.ctx.save();
          if (isOpacityEffect(effect)) {
              this.ctx.globalAlpha = effect.opacity;
          }
          if (isTransformEffect(effect)) {
              this.ctx.translate(effect.offsetX, effect.offsetY);
              this.ctx.transform(effect.matrix[0], effect.matrix[1], effect.matrix[2], effect.matrix[3], effect.matrix[4], effect.matrix[5]);
              this.ctx.translate(-effect.offsetX, -effect.offsetY);
          }
          if (isClipEffect(effect)) {
              this.path(effect.path);
              this.ctx.clip();
          }
          this._activeEffects.push(effect);
      };
      CanvasRenderer.prototype.popEffect = function () {
          this._activeEffects.pop();
          this.ctx.restore();
      };
      CanvasRenderer.prototype.renderStack = function (stack) {
          return __awaiter(this, void 0, void 0, function () {
              var styles;
              return __generator(this, function (_a) {
                  switch (_a.label) {
                      case 0:
                          styles = stack.element.container.styles;
                          if (!styles.isVisible()) return [3 /*break*/, 2];
                          return [4 /*yield*/, this.renderStackContent(stack)];
                      case 1:
                          _a.sent();
                          _a.label = 2;
                      case 2: return [2 /*return*/];
                  }
              });
          });
      };
      CanvasRenderer.prototype.renderNode = function (paint) {
          return __awaiter(this, void 0, void 0, function () {
              return __generator(this, function (_a) {
                  switch (_a.label) {
                      case 0:
                          if (contains(paint.container.flags, 16 /* DEBUG_RENDER */)) {
                              debugger;
                          }
                          if (!paint.container.styles.isVisible()) return [3 /*break*/, 3];
                          return [4 /*yield*/, this.renderNodeBackgroundAndBorders(paint)];
                      case 1:
                          _a.sent();
                          return [4 /*yield*/, this.renderNodeContent(paint)];
                      case 2:
                          _a.sent();
                          _a.label = 3;
                      case 3: return [2 /*return*/];
                  }
              });
          });
      };
      CanvasRenderer.prototype.renderTextWithLetterSpacing = function (text, letterSpacing, baseline) {
          var _this = this;
          if (letterSpacing === 0) {
              this.ctx.fillText(text.text, text.bounds.left, text.bounds.top + baseline);
          }
          else {
              var letters = segmentGraphemes(text.text);
              letters.reduce(function (left, letter) {
                  _this.ctx.fillText(letter, left, text.bounds.top + baseline);
                  return left + _this.ctx.measureText(letter).width;
              }, text.bounds.left);
          }
      };
      CanvasRenderer.prototype.createFontStyle = function (styles) {
          var fontVariant = styles.fontVariant
              .filter(function (variant) { return variant === 'normal' || variant === 'small-caps'; })
              .join('');
          var fontFamily = fixIOSSystemFonts(styles.fontFamily).join(', ');
          var fontSize = isDimensionToken(styles.fontSize)
              ? "" + styles.fontSize.number + styles.fontSize.unit
              : styles.fontSize.number + "px";
          return [
              [styles.fontStyle, fontVariant, styles.fontWeight, fontSize, fontFamily].join(' '),
              fontFamily,
              fontSize
          ];
      };
      CanvasRenderer.prototype.renderTextNode = function (text, styles) {
          return __awaiter(this, void 0, void 0, function () {
              var _a, font, fontFamily, fontSize, _b, baseline, middle, paintOrder;
              var _this = this;
              return __generator(this, function (_c) {
                  _a = this.createFontStyle(styles), font = _a[0], fontFamily = _a[1], fontSize = _a[2];
                  this.ctx.font = font;
                  this.ctx.direction = styles.direction === 1 /* RTL */ ? 'rtl' : 'ltr';
                  this.ctx.textAlign = 'left';
                  this.ctx.textBaseline = 'alphabetic';
                  _b = this.fontMetrics.getMetrics(fontFamily, fontSize), baseline = _b.baseline, middle = _b.middle;
                  paintOrder = styles.paintOrder;
                  text.textBounds.forEach(function (text) {
                      paintOrder.forEach(function (paintOrderLayer) {
                          switch (paintOrderLayer) {
                              case 0 /* FILL */:
                                  _this.ctx.fillStyle = asString(styles.color);
                                  _this.renderTextWithLetterSpacing(text, styles.letterSpacing, baseline);
                                  var textShadows = styles.textShadow;
                                  if (textShadows.length && text.text.trim().length) {
                                      textShadows
                                          .slice(0)
                                          .reverse()
                                          .forEach(function (textShadow) {
                                          _this.ctx.shadowColor = asString(textShadow.color);
                                          _this.ctx.shadowOffsetX = textShadow.offsetX.number * _this.options.scale;
                                          _this.ctx.shadowOffsetY = textShadow.offsetY.number * _this.options.scale;
                                          _this.ctx.shadowBlur = textShadow.blur.number;
                                          _this.renderTextWithLetterSpacing(text, styles.letterSpacing, baseline);
                                      });
                                      _this.ctx.shadowColor = '';
                                      _this.ctx.shadowOffsetX = 0;
                                      _this.ctx.shadowOffsetY = 0;
                                      _this.ctx.shadowBlur = 0;
                                  }
                                  if (styles.textDecorationLine.length) {
                                      _this.ctx.fillStyle = asString(styles.textDecorationColor || styles.color);
                                      styles.textDecorationLine.forEach(function (textDecorationLine) {
                                          switch (textDecorationLine) {
                                              case 1 /* UNDERLINE */:
                                                  // Draws a line at the baseline of the font
                                                  // TODO As some browsers display the line as more than 1px if the font-size is big,
                                                  // need to take that into account both in position and size
                                                  _this.ctx.fillRect(text.bounds.left, Math.round(text.bounds.top + baseline), text.bounds.width, 1);
                                                  break;
                                              case 2 /* OVERLINE */:
                                                  _this.ctx.fillRect(text.bounds.left, Math.round(text.bounds.top), text.bounds.width, 1);
                                                  break;
                                              case 3 /* LINE_THROUGH */:
                                                  // TODO try and find exact position for line-through
                                                  _this.ctx.fillRect(text.bounds.left, Math.ceil(text.bounds.top + middle), text.bounds.width, 1);
                                                  break;
                                          }
                                      });
                                  }
                                  break;
                              case 1 /* STROKE */:
                                  if (styles.webkitTextStrokeWidth && text.text.trim().length) {
                                      _this.ctx.strokeStyle = asString(styles.webkitTextStrokeColor);
                                      _this.ctx.lineWidth = styles.webkitTextStrokeWidth;
                                      // eslint-disable-next-line @typescript-eslint/no-explicit-any
                                      _this.ctx.lineJoin = !!window.chrome ? 'miter' : 'round';
                                      _this.ctx.strokeText(text.text, text.bounds.left, text.bounds.top + baseline);
                                  }
                                  _this.ctx.strokeStyle = '';
                                  _this.ctx.lineWidth = 0;
                                  _this.ctx.lineJoin = 'miter';
                                  break;
                          }
                      });
                  });
                  return [2 /*return*/];
              });
          });
      };
      CanvasRenderer.prototype.renderReplacedElement = function (container, curves, image) {
          if (image && container.intrinsicWidth > 0 && container.intrinsicHeight > 0) {
              var box = contentBox(container);
              var path = calculatePaddingBoxPath(curves);
              this.path(path);
              this.ctx.save();
              this.ctx.clip();
              this.ctx.drawImage(image, 0, 0, container.intrinsicWidth, container.intrinsicHeight, box.left, box.top, box.width, box.height);
              this.ctx.restore();
          }
      };
      CanvasRenderer.prototype.renderNodeContent = function (paint) {
          return __awaiter(this, void 0, void 0, function () {
              var container, curves, styles, _i, _a, child, image, image, iframeRenderer, canvas, size, _b, fontFamily, fontSize, baseline, bounds, x, textBounds, img, image, url, fontFamily, bounds;
              return __generator(this, function (_c) {
                  switch (_c.label) {
                      case 0:
                          this.applyEffects(paint.getEffects(4 /* CONTENT */));
                          container = paint.container;
                          curves = paint.curves;
                          styles = container.styles;
                          _i = 0, _a = container.textNodes;
                          _c.label = 1;
                      case 1:
                          if (!(_i < _a.length)) return [3 /*break*/, 4];
                          child = _a[_i];
                          return [4 /*yield*/, this.renderTextNode(child, styles)];
                      case 2:
                          _c.sent();
                          _c.label = 3;
                      case 3:
                          _i++;
                          return [3 /*break*/, 1];
                      case 4:
                          if (!(container instanceof ImageElementContainer)) return [3 /*break*/, 8];
                          _c.label = 5;
                      case 5:
                          _c.trys.push([5, 7, , 8]);
                          return [4 /*yield*/, this.context.cache.match(container.src)];
                      case 6:
                          image = _c.sent();
                          this.renderReplacedElement(container, curves, image);
                          return [3 /*break*/, 8];
                      case 7:
                          _c.sent();
                          this.context.logger.error("Error loading image " + container.src);
                          return [3 /*break*/, 8];
                      case 8:
                          if (container instanceof CanvasElementContainer) {
                              this.renderReplacedElement(container, curves, container.canvas);
                          }
                          if (!(container instanceof SVGElementContainer)) return [3 /*break*/, 12];
                          _c.label = 9;
                      case 9:
                          _c.trys.push([9, 11, , 12]);
                          return [4 /*yield*/, this.context.cache.match(container.svg)];
                      case 10:
                          image = _c.sent();
                          this.renderReplacedElement(container, curves, image);
                          return [3 /*break*/, 12];
                      case 11:
                          _c.sent();
                          this.context.logger.error("Error loading svg " + container.svg.substring(0, 255));
                          return [3 /*break*/, 12];
                      case 12:
                          if (!(container instanceof IFrameElementContainer && container.tree)) return [3 /*break*/, 14];
                          iframeRenderer = new CanvasRenderer(this.context, {
                              scale: this.options.scale,
                              backgroundColor: container.backgroundColor,
                              x: 0,
                              y: 0,
                              width: container.width,
                              height: container.height
                          });
                          return [4 /*yield*/, iframeRenderer.render(container.tree)];
                      case 13:
                          canvas = _c.sent();
                          if (container.width && container.height) {
                              this.ctx.drawImage(canvas, 0, 0, container.width, container.height, container.bounds.left, container.bounds.top, container.bounds.width, container.bounds.height);
                          }
                          _c.label = 14;
                      case 14:
                          if (container instanceof InputElementContainer) {
                              size = Math.min(container.bounds.width, container.bounds.height);
                              if (container.type === CHECKBOX) {
                                  if (container.checked) {
                                      this.ctx.save();
                                      this.path([
                                          new Vector(container.bounds.left + size * 0.39363, container.bounds.top + size * 0.79),
                                          new Vector(container.bounds.left + size * 0.16, container.bounds.top + size * 0.5549),
                                          new Vector(container.bounds.left + size * 0.27347, container.bounds.top + size * 0.44071),
                                          new Vector(container.bounds.left + size * 0.39694, container.bounds.top + size * 0.5649),
                                          new Vector(container.bounds.left + size * 0.72983, container.bounds.top + size * 0.23),
                                          new Vector(container.bounds.left + size * 0.84, container.bounds.top + size * 0.34085),
                                          new Vector(container.bounds.left + size * 0.39363, container.bounds.top + size * 0.79)
                                      ]);
                                      this.ctx.fillStyle = asString(INPUT_COLOR);
                                      this.ctx.fill();
                                      this.ctx.restore();
                                  }
                              }
                              else if (container.type === RADIO) {
                                  if (container.checked) {
                                      this.ctx.save();
                                      this.ctx.beginPath();
                                      this.ctx.arc(container.bounds.left + size / 2, container.bounds.top + size / 2, size / 4, 0, Math.PI * 2, true);
                                      this.ctx.fillStyle = asString(INPUT_COLOR);
                                      this.ctx.fill();
                                      this.ctx.restore();
                                  }
                              }
                          }
                          if (isTextInputElement(container) && container.value.length) {
                              _b = this.createFontStyle(styles), fontFamily = _b[0], fontSize = _b[1];
                              baseline = this.fontMetrics.getMetrics(fontFamily, fontSize).baseline;
                              this.ctx.font = fontFamily;
                              this.ctx.fillStyle = asString(styles.color);
                              this.ctx.textBaseline = 'alphabetic';
                              this.ctx.textAlign = canvasTextAlign(container.styles.textAlign);
                              bounds = contentBox(container);
                              x = 0;
                              switch (container.styles.textAlign) {
                                  case 1 /* CENTER */:
                                      x += bounds.width / 2;
                                      break;
                                  case 2 /* RIGHT */:
                                      x += bounds.width;
                                      break;
                              }
                              textBounds = bounds.add(x, 0, 0, -bounds.height / 2 + 1);
                              this.ctx.save();
                              this.path([
                                  new Vector(bounds.left, bounds.top),
                                  new Vector(bounds.left + bounds.width, bounds.top),
                                  new Vector(bounds.left + bounds.width, bounds.top + bounds.height),
                                  new Vector(bounds.left, bounds.top + bounds.height)
                              ]);
                              this.ctx.clip();
                              this.renderTextWithLetterSpacing(new TextBounds(container.value, textBounds), styles.letterSpacing, baseline);
                              this.ctx.restore();
                              this.ctx.textBaseline = 'alphabetic';
                              this.ctx.textAlign = 'left';
                          }
                          if (!contains(container.styles.display, 2048 /* LIST_ITEM */)) return [3 /*break*/, 20];
                          if (!(container.styles.listStyleImage !== null)) return [3 /*break*/, 19];
                          img = container.styles.listStyleImage;
                          if (!(img.type === 0 /* URL */)) return [3 /*break*/, 18];
                          image = void 0;
                          url = img.url;
                          _c.label = 15;
                      case 15:
                          _c.trys.push([15, 17, , 18]);
                          return [4 /*yield*/, this.context.cache.match(url)];
                      case 16:
                          image = _c.sent();
                          this.ctx.drawImage(image, container.bounds.left - (image.width + 10), container.bounds.top);
                          return [3 /*break*/, 18];
                      case 17:
                          _c.sent();
                          this.context.logger.error("Error loading list-style-image " + url);
                          return [3 /*break*/, 18];
                      case 18: return [3 /*break*/, 20];
                      case 19:
                          if (paint.listValue && container.styles.listStyleType !== -1 /* NONE */) {
                              fontFamily = this.createFontStyle(styles)[0];
                              this.ctx.font = fontFamily;
                              this.ctx.fillStyle = asString(styles.color);
                              this.ctx.textBaseline = 'middle';
                              this.ctx.textAlign = 'right';
                              bounds = new Bounds(container.bounds.left, container.bounds.top + getAbsoluteValue(container.styles.paddingTop, container.bounds.width), container.bounds.width, computeLineHeight(styles.lineHeight, styles.fontSize.number) / 2 + 1);
                              this.renderTextWithLetterSpacing(new TextBounds(paint.listValue, bounds), styles.letterSpacing, computeLineHeight(styles.lineHeight, styles.fontSize.number) / 2 + 2);
                              this.ctx.textBaseline = 'bottom';
                              this.ctx.textAlign = 'left';
                          }
                          _c.label = 20;
                      case 20: return [2 /*return*/];
                  }
              });
          });
      };
      CanvasRenderer.prototype.renderStackContent = function (stack) {
          return __awaiter(this, void 0, void 0, function () {
              var _i, _a, child, _b, _c, child, _d, _e, child, _f, _g, child, _h, _j, child, _k, _l, child, _m, _o, child;
              return __generator(this, function (_p) {
                  switch (_p.label) {
                      case 0:
                          if (contains(stack.element.container.flags, 16 /* DEBUG_RENDER */)) {
                              debugger;
                          }
                          // https://www.w3.org/TR/css-position-3/#painting-order
                          // 1. the background and borders of the element forming the stacking context.
                          return [4 /*yield*/, this.renderNodeBackgroundAndBorders(stack.element)];
                      case 1:
                          // https://www.w3.org/TR/css-position-3/#painting-order
                          // 1. the background and borders of the element forming the stacking context.
                          _p.sent();
                          _i = 0, _a = stack.negativeZIndex;
                          _p.label = 2;
                      case 2:
                          if (!(_i < _a.length)) return [3 /*break*/, 5];
                          child = _a[_i];
                          return [4 /*yield*/, this.renderStack(child)];
                      case 3:
                          _p.sent();
                          _p.label = 4;
                      case 4:
                          _i++;
                          return [3 /*break*/, 2];
                      case 5: 
                      // 3. For all its in-flow, non-positioned, block-level descendants in tree order:
                      return [4 /*yield*/, this.renderNodeContent(stack.element)];
                      case 6:
                          // 3. For all its in-flow, non-positioned, block-level descendants in tree order:
                          _p.sent();
                          _b = 0, _c = stack.nonInlineLevel;
                          _p.label = 7;
                      case 7:
                          if (!(_b < _c.length)) return [3 /*break*/, 10];
                          child = _c[_b];
                          return [4 /*yield*/, this.renderNode(child)];
                      case 8:
                          _p.sent();
                          _p.label = 9;
                      case 9:
                          _b++;
                          return [3 /*break*/, 7];
                      case 10:
                          _d = 0, _e = stack.nonPositionedFloats;
                          _p.label = 11;
                      case 11:
                          if (!(_d < _e.length)) return [3 /*break*/, 14];
                          child = _e[_d];
                          return [4 /*yield*/, this.renderStack(child)];
                      case 12:
                          _p.sent();
                          _p.label = 13;
                      case 13:
                          _d++;
                          return [3 /*break*/, 11];
                      case 14:
                          _f = 0, _g = stack.nonPositionedInlineLevel;
                          _p.label = 15;
                      case 15:
                          if (!(_f < _g.length)) return [3 /*break*/, 18];
                          child = _g[_f];
                          return [4 /*yield*/, this.renderStack(child)];
                      case 16:
                          _p.sent();
                          _p.label = 17;
                      case 17:
                          _f++;
                          return [3 /*break*/, 15];
                      case 18:
                          _h = 0, _j = stack.inlineLevel;
                          _p.label = 19;
                      case 19:
                          if (!(_h < _j.length)) return [3 /*break*/, 22];
                          child = _j[_h];
                          return [4 /*yield*/, this.renderNode(child)];
                      case 20:
                          _p.sent();
                          _p.label = 21;
                      case 21:
                          _h++;
                          return [3 /*break*/, 19];
                      case 22:
                          _k = 0, _l = stack.zeroOrAutoZIndexOrTransformedOrOpacity;
                          _p.label = 23;
                      case 23:
                          if (!(_k < _l.length)) return [3 /*break*/, 26];
                          child = _l[_k];
                          return [4 /*yield*/, this.renderStack(child)];
                      case 24:
                          _p.sent();
                          _p.label = 25;
                      case 25:
                          _k++;
                          return [3 /*break*/, 23];
                      case 26:
                          _m = 0, _o = stack.positiveZIndex;
                          _p.label = 27;
                      case 27:
                          if (!(_m < _o.length)) return [3 /*break*/, 30];
                          child = _o[_m];
                          return [4 /*yield*/, this.renderStack(child)];
                      case 28:
                          _p.sent();
                          _p.label = 29;
                      case 29:
                          _m++;
                          return [3 /*break*/, 27];
                      case 30: return [2 /*return*/];
                  }
              });
          });
      };
      CanvasRenderer.prototype.mask = function (paths) {
          this.ctx.beginPath();
          this.ctx.moveTo(0, 0);
          this.ctx.lineTo(this.canvas.width, 0);
          this.ctx.lineTo(this.canvas.width, this.canvas.height);
          this.ctx.lineTo(0, this.canvas.height);
          this.ctx.lineTo(0, 0);
          this.formatPath(paths.slice(0).reverse());
          this.ctx.closePath();
      };
      CanvasRenderer.prototype.path = function (paths) {
          this.ctx.beginPath();
          this.formatPath(paths);
          this.ctx.closePath();
      };
      CanvasRenderer.prototype.formatPath = function (paths) {
          var _this = this;
          paths.forEach(function (point, index) {
              var start = isBezierCurve(point) ? point.start : point;
              if (index === 0) {
                  _this.ctx.moveTo(start.x, start.y);
              }
              else {
                  _this.ctx.lineTo(start.x, start.y);
              }
              if (isBezierCurve(point)) {
                  _this.ctx.bezierCurveTo(point.startControl.x, point.startControl.y, point.endControl.x, point.endControl.y, point.end.x, point.end.y);
              }
          });
      };
      CanvasRenderer.prototype.renderRepeat = function (path, pattern, offsetX, offsetY) {
          this.path(path);
          this.ctx.fillStyle = pattern;
          this.ctx.translate(offsetX, offsetY);
          this.ctx.fill();
          this.ctx.translate(-offsetX, -offsetY);
      };
      CanvasRenderer.prototype.resizeImage = function (image, width, height) {
          var _a;
          if (image.width === width && image.height === height) {
              return image;
          }
          var ownerDocument = (_a = this.canvas.ownerDocument) !== null && _a !== void 0 ? _a : document;
          var canvas = ownerDocument.createElement('canvas');
          canvas.width = Math.max(1, width);
          canvas.height = Math.max(1, height);
          var ctx = canvas.getContext('2d');
          ctx.drawImage(image, 0, 0, image.width, image.height, 0, 0, width, height);
          return canvas;
      };
      CanvasRenderer.prototype.renderBackgroundImage = function (container) {
          return __awaiter(this, void 0, void 0, function () {
              var index, _loop_1, this_1, _i, _a, backgroundImage;
              return __generator(this, function (_b) {
                  switch (_b.label) {
                      case 0:
                          index = container.styles.backgroundImage.length - 1;
                          _loop_1 = function (backgroundImage) {
                              var image, url, _c, path, x, y, width, height, pattern, _d, path, x, y, width, height, _e, lineLength, x0, x1, y0, y1, canvas, ctx, gradient_1, pattern, _f, path, left, top_1, width, height, position, x, y, _g, rx, ry, radialGradient_1, midX, midY, f, invF;
                              return __generator(this, function (_h) {
                                  switch (_h.label) {
                                      case 0:
                                          if (!(backgroundImage.type === 0 /* URL */)) return [3 /*break*/, 5];
                                          image = void 0;
                                          url = backgroundImage.url;
                                          _h.label = 1;
                                      case 1:
                                          _h.trys.push([1, 3, , 4]);
                                          return [4 /*yield*/, this_1.context.cache.match(url)];
                                      case 2:
                                          image = _h.sent();
                                          return [3 /*break*/, 4];
                                      case 3:
                                          _h.sent();
                                          this_1.context.logger.error("Error loading background-image " + url);
                                          return [3 /*break*/, 4];
                                      case 4:
                                          if (image) {
                                              _c = calculateBackgroundRendering(container, index, [
                                                  image.width,
                                                  image.height,
                                                  image.width / image.height
                                              ]), path = _c[0], x = _c[1], y = _c[2], width = _c[3], height = _c[4];
                                              pattern = this_1.ctx.createPattern(this_1.resizeImage(image, width, height), 'repeat');
                                              this_1.renderRepeat(path, pattern, x, y);
                                          }
                                          return [3 /*break*/, 6];
                                      case 5:
                                          if (isLinearGradient(backgroundImage)) {
                                              _d = calculateBackgroundRendering(container, index, [null, null, null]), path = _d[0], x = _d[1], y = _d[2], width = _d[3], height = _d[4];
                                              _e = calculateGradientDirection(backgroundImage.angle, width, height), lineLength = _e[0], x0 = _e[1], x1 = _e[2], y0 = _e[3], y1 = _e[4];
                                              canvas = document.createElement('canvas');
                                              canvas.width = width;
                                              canvas.height = height;
                                              ctx = canvas.getContext('2d');
                                              gradient_1 = ctx.createLinearGradient(x0, y0, x1, y1);
                                              processColorStops(backgroundImage.stops, lineLength).forEach(function (colorStop) {
                                                  return gradient_1.addColorStop(colorStop.stop, asString(colorStop.color));
                                              });
                                              ctx.fillStyle = gradient_1;
                                              ctx.fillRect(0, 0, width, height);
                                              if (width > 0 && height > 0) {
                                                  pattern = this_1.ctx.createPattern(canvas, 'repeat');
                                                  this_1.renderRepeat(path, pattern, x, y);
                                              }
                                          }
                                          else if (isRadialGradient(backgroundImage)) {
                                              _f = calculateBackgroundRendering(container, index, [
                                                  null,
                                                  null,
                                                  null
                                              ]), path = _f[0], left = _f[1], top_1 = _f[2], width = _f[3], height = _f[4];
                                              position = backgroundImage.position.length === 0 ? [FIFTY_PERCENT] : backgroundImage.position;
                                              x = getAbsoluteValue(position[0], width);
                                              y = getAbsoluteValue(position[position.length - 1], height);
                                              _g = calculateRadius(backgroundImage, x, y, width, height), rx = _g[0], ry = _g[1];
                                              if (rx > 0 && ry > 0) {
                                                  radialGradient_1 = this_1.ctx.createRadialGradient(left + x, top_1 + y, 0, left + x, top_1 + y, rx);
                                                  processColorStops(backgroundImage.stops, rx * 2).forEach(function (colorStop) {
                                                      return radialGradient_1.addColorStop(colorStop.stop, asString(colorStop.color));
                                                  });
                                                  this_1.path(path);
                                                  this_1.ctx.fillStyle = radialGradient_1;
                                                  if (rx !== ry) {
                                                      midX = container.bounds.left + 0.5 * container.bounds.width;
                                                      midY = container.bounds.top + 0.5 * container.bounds.height;
                                                      f = ry / rx;
                                                      invF = 1 / f;
                                                      this_1.ctx.save();
                                                      this_1.ctx.translate(midX, midY);
                                                      this_1.ctx.transform(1, 0, 0, f, 0, 0);
                                                      this_1.ctx.translate(-midX, -midY);
                                                      this_1.ctx.fillRect(left, invF * (top_1 - midY) + midY, width, height * invF);
                                                      this_1.ctx.restore();
                                                  }
                                                  else {
                                                      this_1.ctx.fill();
                                                  }
                                              }
                                          }
                                          _h.label = 6;
                                      case 6:
                                          index--;
                                          return [2 /*return*/];
                                  }
                              });
                          };
                          this_1 = this;
                          _i = 0, _a = container.styles.backgroundImage.slice(0).reverse();
                          _b.label = 1;
                      case 1:
                          if (!(_i < _a.length)) return [3 /*break*/, 4];
                          backgroundImage = _a[_i];
                          return [5 /*yield**/, _loop_1(backgroundImage)];
                      case 2:
                          _b.sent();
                          _b.label = 3;
                      case 3:
                          _i++;
                          return [3 /*break*/, 1];
                      case 4: return [2 /*return*/];
                  }
              });
          });
      };
      CanvasRenderer.prototype.renderSolidBorder = function (color, side, curvePoints) {
          return __awaiter(this, void 0, void 0, function () {
              return __generator(this, function (_a) {
                  this.path(parsePathForBorder(curvePoints, side));
                  this.ctx.fillStyle = asString(color);
                  this.ctx.fill();
                  return [2 /*return*/];
              });
          });
      };
      CanvasRenderer.prototype.renderDoubleBorder = function (color, width, side, curvePoints) {
          return __awaiter(this, void 0, void 0, function () {
              var outerPaths, innerPaths;
              return __generator(this, function (_a) {
                  switch (_a.label) {
                      case 0:
                          if (!(width < 3)) return [3 /*break*/, 2];
                          return [4 /*yield*/, this.renderSolidBorder(color, side, curvePoints)];
                      case 1:
                          _a.sent();
                          return [2 /*return*/];
                      case 2:
                          outerPaths = parsePathForBorderDoubleOuter(curvePoints, side);
                          this.path(outerPaths);
                          this.ctx.fillStyle = asString(color);
                          this.ctx.fill();
                          innerPaths = parsePathForBorderDoubleInner(curvePoints, side);
                          this.path(innerPaths);
                          this.ctx.fill();
                          return [2 /*return*/];
                  }
              });
          });
      };
      CanvasRenderer.prototype.renderNodeBackgroundAndBorders = function (paint) {
          return __awaiter(this, void 0, void 0, function () {
              var styles, hasBackground, borders, backgroundPaintingArea, side, _i, borders_1, border;
              var _this = this;
              return __generator(this, function (_a) {
                  switch (_a.label) {
                      case 0:
                          this.applyEffects(paint.getEffects(2 /* BACKGROUND_BORDERS */));
                          styles = paint.container.styles;
                          hasBackground = !isTransparent(styles.backgroundColor) || styles.backgroundImage.length;
                          borders = [
                              { style: styles.borderTopStyle, color: styles.borderTopColor, width: styles.borderTopWidth },
                              { style: styles.borderRightStyle, color: styles.borderRightColor, width: styles.borderRightWidth },
                              { style: styles.borderBottomStyle, color: styles.borderBottomColor, width: styles.borderBottomWidth },
                              { style: styles.borderLeftStyle, color: styles.borderLeftColor, width: styles.borderLeftWidth }
                          ];
                          backgroundPaintingArea = calculateBackgroundCurvedPaintingArea(getBackgroundValueForIndex(styles.backgroundClip, 0), paint.curves);
                          if (!(hasBackground || styles.boxShadow.length)) return [3 /*break*/, 2];
                          this.ctx.save();
                          this.path(backgroundPaintingArea);
                          this.ctx.clip();
                          if (!isTransparent(styles.backgroundColor)) {
                              this.ctx.fillStyle = asString(styles.backgroundColor);
                              this.ctx.fill();
                          }
                          return [4 /*yield*/, this.renderBackgroundImage(paint.container)];
                      case 1:
                          _a.sent();
                          this.ctx.restore();
                          styles.boxShadow
                              .slice(0)
                              .reverse()
                              .forEach(function (shadow) {
                              _this.ctx.save();
                              var borderBoxArea = calculateBorderBoxPath(paint.curves);
                              var maskOffset = shadow.inset ? 0 : MASK_OFFSET;
                              var shadowPaintingArea = transformPath(borderBoxArea, -maskOffset + (shadow.inset ? 1 : -1) * shadow.spread.number, (shadow.inset ? 1 : -1) * shadow.spread.number, shadow.spread.number * (shadow.inset ? -2 : 2), shadow.spread.number * (shadow.inset ? -2 : 2));
                              if (shadow.inset) {
                                  _this.path(borderBoxArea);
                                  _this.ctx.clip();
                                  _this.mask(shadowPaintingArea);
                              }
                              else {
                                  _this.mask(borderBoxArea);
                                  _this.ctx.clip();
                                  _this.path(shadowPaintingArea);
                              }
                              _this.ctx.shadowOffsetX = shadow.offsetX.number + maskOffset;
                              _this.ctx.shadowOffsetY = shadow.offsetY.number;
                              _this.ctx.shadowColor = asString(shadow.color);
                              _this.ctx.shadowBlur = shadow.blur.number;
                              _this.ctx.fillStyle = shadow.inset ? asString(shadow.color) : 'rgba(0,0,0,1)';
                              _this.ctx.fill();
                              _this.ctx.restore();
                          });
                          _a.label = 2;
                      case 2:
                          side = 0;
                          _i = 0, borders_1 = borders;
                          _a.label = 3;
                      case 3:
                          if (!(_i < borders_1.length)) return [3 /*break*/, 13];
                          border = borders_1[_i];
                          if (!(border.style !== 0 /* NONE */ && !isTransparent(border.color) && border.width > 0)) return [3 /*break*/, 11];
                          if (!(border.style === 2 /* DASHED */)) return [3 /*break*/, 5];
                          return [4 /*yield*/, this.renderDashedDottedBorder(border.color, border.width, side, paint.curves, 2 /* DASHED */)];
                      case 4:
                          _a.sent();
                          return [3 /*break*/, 11];
                      case 5:
                          if (!(border.style === 3 /* DOTTED */)) return [3 /*break*/, 7];
                          return [4 /*yield*/, this.renderDashedDottedBorder(border.color, border.width, side, paint.curves, 3 /* DOTTED */)];
                      case 6:
                          _a.sent();
                          return [3 /*break*/, 11];
                      case 7:
                          if (!(border.style === 4 /* DOUBLE */)) return [3 /*break*/, 9];
                          return [4 /*yield*/, this.renderDoubleBorder(border.color, border.width, side, paint.curves)];
                      case 8:
                          _a.sent();
                          return [3 /*break*/, 11];
                      case 9: return [4 /*yield*/, this.renderSolidBorder(border.color, side, paint.curves)];
                      case 10:
                          _a.sent();
                          _a.label = 11;
                      case 11:
                          side++;
                          _a.label = 12;
                      case 12:
                          _i++;
                          return [3 /*break*/, 3];
                      case 13: return [2 /*return*/];
                  }
              });
          });
      };
      CanvasRenderer.prototype.renderDashedDottedBorder = function (color, width, side, curvePoints, style) {
          return __awaiter(this, void 0, void 0, function () {
              var strokePaths, boxPaths, startX, startY, endX, endY, length, dashLength, spaceLength, useLineDash, multiplier, numberOfDashes, minSpace, maxSpace, path1, path2, path1, path2;
              return __generator(this, function (_a) {
                  this.ctx.save();
                  strokePaths = parsePathForBorderStroke(curvePoints, side);
                  boxPaths = parsePathForBorder(curvePoints, side);
                  if (style === 2 /* DASHED */) {
                      this.path(boxPaths);
                      this.ctx.clip();
                  }
                  if (isBezierCurve(boxPaths[0])) {
                      startX = boxPaths[0].start.x;
                      startY = boxPaths[0].start.y;
                  }
                  else {
                      startX = boxPaths[0].x;
                      startY = boxPaths[0].y;
                  }
                  if (isBezierCurve(boxPaths[1])) {
                      endX = boxPaths[1].end.x;
                      endY = boxPaths[1].end.y;
                  }
                  else {
                      endX = boxPaths[1].x;
                      endY = boxPaths[1].y;
                  }
                  if (side === 0 || side === 2) {
                      length = Math.abs(startX - endX);
                  }
                  else {
                      length = Math.abs(startY - endY);
                  }
                  this.ctx.beginPath();
                  if (style === 3 /* DOTTED */) {
                      this.formatPath(strokePaths);
                  }
                  else {
                      this.formatPath(boxPaths.slice(0, 2));
                  }
                  dashLength = width < 3 ? width * 3 : width * 2;
                  spaceLength = width < 3 ? width * 2 : width;
                  if (style === 3 /* DOTTED */) {
                      dashLength = width;
                      spaceLength = width;
                  }
                  useLineDash = true;
                  if (length <= dashLength * 2) {
                      useLineDash = false;
                  }
                  else if (length <= dashLength * 2 + spaceLength) {
                      multiplier = length / (2 * dashLength + spaceLength);
                      dashLength *= multiplier;
                      spaceLength *= multiplier;
                  }
                  else {
                      numberOfDashes = Math.floor((length + spaceLength) / (dashLength + spaceLength));
                      minSpace = (length - numberOfDashes * dashLength) / (numberOfDashes - 1);
                      maxSpace = (length - (numberOfDashes + 1) * dashLength) / numberOfDashes;
                      spaceLength =
                          maxSpace <= 0 || Math.abs(spaceLength - minSpace) < Math.abs(spaceLength - maxSpace)
                              ? minSpace
                              : maxSpace;
                  }
                  if (useLineDash) {
                      if (style === 3 /* DOTTED */) {
                          this.ctx.setLineDash([0, dashLength + spaceLength]);
                      }
                      else {
                          this.ctx.setLineDash([dashLength, spaceLength]);
                      }
                  }
                  if (style === 3 /* DOTTED */) {
                      this.ctx.lineCap = 'round';
                      this.ctx.lineWidth = width;
                  }
                  else {
                      this.ctx.lineWidth = width * 2 + 1.1;
                  }
                  this.ctx.strokeStyle = asString(color);
                  this.ctx.stroke();
                  this.ctx.setLineDash([]);
                  // dashed round edge gap
                  if (style === 2 /* DASHED */) {
                      if (isBezierCurve(boxPaths[0])) {
                          path1 = boxPaths[3];
                          path2 = boxPaths[0];
                          this.ctx.beginPath();
                          this.formatPath([new Vector(path1.end.x, path1.end.y), new Vector(path2.start.x, path2.start.y)]);
                          this.ctx.stroke();
                      }
                      if (isBezierCurve(boxPaths[1])) {
                          path1 = boxPaths[1];
                          path2 = boxPaths[2];
                          this.ctx.beginPath();
                          this.formatPath([new Vector(path1.end.x, path1.end.y), new Vector(path2.start.x, path2.start.y)]);
                          this.ctx.stroke();
                      }
                  }
                  this.ctx.restore();
                  return [2 /*return*/];
              });
          });
      };
      CanvasRenderer.prototype.render = function (element) {
          return __awaiter(this, void 0, void 0, function () {
              var stack;
              return __generator(this, function (_a) {
                  switch (_a.label) {
                      case 0:
                          if (this.options.backgroundColor) {
                              this.ctx.fillStyle = asString(this.options.backgroundColor);
                              this.ctx.fillRect(this.options.x, this.options.y, this.options.width, this.options.height);
                          }
                          stack = parseStackingContexts(element);
                          return [4 /*yield*/, this.renderStack(stack)];
                      case 1:
                          _a.sent();
                          this.applyEffects([]);
                          return [2 /*return*/, this.canvas];
                  }
              });
          });
      };
      return CanvasRenderer;
  })(Renderer));
  var isTextInputElement = function (container) {
      if (container instanceof TextareaElementContainer) {
          return true;
      }
      else if (container instanceof SelectElementContainer) {
          return true;
      }
      else if (container instanceof InputElementContainer && container.type !== RADIO && container.type !== CHECKBOX) {
          return true;
      }
      return false;
  };
  var calculateBackgroundCurvedPaintingArea = function (clip, curves) {
      switch (clip) {
          case 0 /* BORDER_BOX */:
              return calculateBorderBoxPath(curves);
          case 2 /* CONTENT_BOX */:
              return calculateContentBoxPath(curves);
          case 1 /* PADDING_BOX */:
          default:
              return calculatePaddingBoxPath(curves);
      }
  };
  var canvasTextAlign = function (textAlign) {
      switch (textAlign) {
          case 1 /* CENTER */:
              return 'center';
          case 2 /* RIGHT */:
              return 'right';
          case 0 /* LEFT */:
          default:
              return 'left';
      }
  };
  // see https://github.com/niklasvh/html2canvas/pull/2645
  var iOSBrokenFonts = ['-apple-system', 'system-ui'];
  var fixIOSSystemFonts = function (fontFamilies) {
      return /iPhone OS 15_(0|1)/.test(window.navigator.userAgent)
          ? fontFamilies.filter(function (fontFamily) { return iOSBrokenFonts.indexOf(fontFamily) === -1; })
          : fontFamilies;
  };

  /** @class */ ((function (_super) {
      __extends(ForeignObjectRenderer, _super);
      function ForeignObjectRenderer(context, options) {
          var _this = _super.call(this, context, options) || this;
          _this.canvas = options.canvas ? options.canvas : document.createElement('canvas');
          _this.ctx = _this.canvas.getContext('2d');
          _this.options = options;
          _this.canvas.width = Math.floor(options.width * options.scale);
          _this.canvas.height = Math.floor(options.height * options.scale);
          _this.canvas.style.width = options.width + "px";
          _this.canvas.style.height = options.height + "px";
          _this.ctx.scale(_this.options.scale, _this.options.scale);
          _this.ctx.translate(-options.x, -options.y);
          _this.context.logger.debug("EXPERIMENTAL ForeignObject renderer initialized (" + options.width + "x" + options.height + " at " + options.x + "," + options.y + ") with scale " + options.scale);
          return _this;
      }
      ForeignObjectRenderer.prototype.render = function (element) {
          return __awaiter(this, void 0, void 0, function () {
              var svg, img;
              return __generator(this, function (_a) {
                  switch (_a.label) {
                      case 0:
                          svg = createForeignObjectSVG(this.options.width * this.options.scale, this.options.height * this.options.scale, this.options.scale, this.options.scale, element);
                          return [4 /*yield*/, loadSerializedSVG(svg)];
                      case 1:
                          img = _a.sent();
                          if (this.options.backgroundColor) {
                              this.ctx.fillStyle = asString(this.options.backgroundColor);
                              this.ctx.fillRect(0, 0, this.options.width * this.options.scale, this.options.height * this.options.scale);
                          }
                          this.ctx.drawImage(img, -this.options.x * this.options.scale, -this.options.y * this.options.scale);
                          return [2 /*return*/, this.canvas];
                  }
              });
          });
      };
      return ForeignObjectRenderer;
  })(Renderer));
  var loadSerializedSVG = function (svg) {
      return new Promise(function (resolve, reject) {
          var img = new Image();
          img.onload = function () {
              resolve(img);
          };
          img.onerror = reject;
          img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(new XMLSerializer().serializeToString(svg));
      });
  };
  if (typeof window !== 'undefined') {
      CacheStorage.setContext(window);
  }

  // import { has } from 'core-js/core/dict';

  var Plugin = function Plugin() {
    var ieVersion = function () {
      var browser = /(msie) ([\w.]+)/.exec(window.navigator.userAgent.toLowerCase());
      if (browser && browser[1] === 'msie') {
        return parseFloat(browser[2]);
      }
      return null;
    }();
    var deck;
    var config;
    var options;
    var initialised = false;
    function scriptPath() {
      // obtain plugin path from the script element
      var path;
      var script = document.querySelector('script[src$="menu.js"]');
      if (script) {
        var sel = document.querySelector('script[src$="menu.js"]');
        if (sel) {
          path = sel.src.slice(0, -7);
        }
      } else {
        path = (typeof document === 'undefined' && typeof location === 'undefined' ? new (require('u' + 'rl').URL)('file:' + __filename).href : typeof document === 'undefined' ? location.href : (document.currentScript && document.currentScript.src || new URL('menu.js', document.baseURI).href)).slice(0, (typeof document === 'undefined' && typeof location === 'undefined' ? new (require('u' + 'rl').URL)('file:' + __filename).href : typeof document === 'undefined' ? location.href : (document.currentScript && document.currentScript.src || new URL('menu.js', document.baseURI).href)).lastIndexOf('/') + 1);
      }
      return path;
    }
    function initOptions(config) {
      options = config.menu || {};
      options.path = options.path || scriptPath() || 'plugin/menu/';
      if (!options.path.endsWith('/')) {
        options.path += '/';
      }

      // Set defaults
      if (options.side === undefined) options.side = 'left';
      if (options.numbers === undefined) options.numbers = false;
      if (typeof options.titleSelector !== 'string') options.titleSelector = 'h1, h2, h3, h4, h5';
      if (options.hideMissingTitles === undefined) options.hideMissingTitles = false;
      if (options.useTextContentForMissingTitles === undefined) options.useTextContentForMissingTitles = false;
      if (options.markers === undefined) options.markers = true;
      if (typeof options.themesPath !== 'string') options.themesPath = 'dist/theme/';
      if (!options.themesPath.endsWith('/')) options.themesPath += '/';
      if (!select('link#theme')) options.themes = false;
      if (options.themes === true) {
        options.themes = [{
          name: 'Black',
          theme: options.themesPath + 'black.css'
        }, {
          name: 'White',
          theme: options.themesPath + 'white.css'
        }, {
          name: 'League',
          theme: options.themesPath + 'league.css'
        }, {
          name: 'Sky',
          theme: options.themesPath + 'sky.css'
        }, {
          name: 'Beige',
          theme: options.themesPath + 'beige.css'
        }, {
          name: 'Simple',
          theme: options.themesPath + 'simple.css'
        }, {
          name: 'Serif',
          theme: options.themesPath + 'serif.css'
        }, {
          name: 'Blood',
          theme: options.themesPath + 'blood.css'
        }, {
          name: 'Night',
          theme: options.themesPath + 'night.css'
        }, {
          name: 'Moon',
          theme: options.themesPath + 'moon.css'
        }, {
          name: 'Solarized',
          theme: options.themesPath + 'solarized.css'
        }];
      } else if (!Array.isArray(options.themes)) {
        options.themes = false;
      }
      if (options.transitions === undefined) options.transitions = false;
      if (options.transitions === true) {
        options.transitions = ['None', 'Fade', 'Slide', 'Convex', 'Concave', 'Zoom'];
      } else if (options.transitions !== false && (!Array.isArray(options.transitions) || !options.transitions.every(function (e) {
        return typeof e === 'string';
      }))) {
        console.error("reveal.js-menu error: transitions config value must be 'true' or an array of strings, eg ['None', 'Fade', 'Slide')");
        options.transitions = false;
      }
      if (ieVersion && ieVersion <= 9) {
        // transitions aren't support in IE9 anyway, so no point in showing them
        options.transitions = false;
      }
      if (typeof options.openButton === 'undefined') options.openButton = true;
      if (typeof options.openSlideNumber === 'undefined') options.openSlideNumber = false;
      if (typeof options.keyboard === 'undefined') options.keyboard = true;
      if (typeof options.sticky === 'undefined') options.sticky = false;
      if (typeof options.autoOpen === 'undefined') options.autoOpen = true;
      if (typeof options.delayInit === 'undefined') options.delayInit = false;
      if (typeof options.openOnInit === 'undefined') options.openOnInit = false;
    }
    var mouseSelectionEnabled = true;
    function disableMouseSelection() {
      mouseSelectionEnabled = false;
    }
    function reenableMouseSelection() {
      // wait until the mouse has moved before re-enabling mouse selection
      // to avoid selections on scroll
      select('nav.slide-menu').addEventListener('mousemove', function fn(e) {
        select('nav.slide-menu').removeEventListener('mousemove', fn);
        //XXX this should select the item under the mouse
        mouseSelectionEnabled = true;
      });
    }

    //
    // Keyboard handling
    //
    function getOffset(el) {
      var _x = 0;
      var _y = 0;
      while (el && !isNaN(el.offsetLeft) && !isNaN(el.offsetTop)) {
        _x += el.offsetLeft - el.scrollLeft;
        _y += el.offsetTop - el.scrollTop;
        el = el.offsetParent;
      }
      return {
        top: _y,
        left: _x
      };
    }
    function visibleOffset(el) {
      var offsetFromTop = getOffset(el).top - el.offsetParent.offsetTop;
      if (offsetFromTop < 0) return -offsetFromTop;
      var offsetFromBottom = el.offsetParent.offsetHeight - (el.offsetTop - el.offsetParent.scrollTop + el.offsetHeight);
      if (offsetFromBottom < 0) return offsetFromBottom;
      return 0;
    }
    function keepVisible(el) {
      var offset = visibleOffset(el);
      if (offset) {
        disableMouseSelection();
        el.scrollIntoView(offset > 0);
        reenableMouseSelection();
      }
    }
    function scrollItemToTop(el) {
      disableMouseSelection();
      el.offsetParent.scrollTop = el.offsetTop;
      reenableMouseSelection();
    }
    function scrollItemToBottom(el) {
      disableMouseSelection();
      el.offsetParent.scrollTop = el.offsetTop - el.offsetParent.offsetHeight + el.offsetHeight;
      reenableMouseSelection();
    }
    function selectItem(el) {
      el.classList.add('selected');
      keepVisible(el);
      if (options.sticky && options.autoOpen) openItem(el);
    }
    function onDocumentKeyDown(event) {
      // opening menu is handled by registering key binding with Reveal below
      if (isOpen()) {
        event.stopImmediatePropagation();
        switch (event.keyCode) {
          // case 77:
          // 	closeMenu();
          // 	break;
          // h, left - change panel
          case 72:
          case 37:
            prevPanel();
            break;
          // l, right - change panel
          case 76:
          case 39:
            nextPanel();
            break;
          // k, up
          case 75:
          case 38:
            var currItem = select('.active-menu-panel .slide-menu-items li.selected') || select('.active-menu-panel .slide-menu-items li.active');
            if (currItem) {
              selectAll('.active-menu-panel .slide-menu-items li').forEach(function (item) {
                item.classList.remove('selected');
              });
              var nextItem = select('.active-menu-panel .slide-menu-items li[data-item="' + (parseInt(currItem.getAttribute('data-item')) - 1) + '"]') || currItem;
              selectItem(nextItem);
            } else {
              var item = select('.active-menu-panel .slide-menu-items li.slide-menu-item');
              if (item) selectItem(item);
            }
            break;
          // j, down
          case 74:
          case 40:
            var currItem = select('.active-menu-panel .slide-menu-items li.selected') || select('.active-menu-panel .slide-menu-items li.active');
            if (currItem) {
              selectAll('.active-menu-panel .slide-menu-items li').forEach(function (item) {
                item.classList.remove('selected');
              });
              var nextItem = select('.active-menu-panel .slide-menu-items li[data-item="' + (parseInt(currItem.getAttribute('data-item')) + 1) + '"]') || currItem;
              selectItem(nextItem);
            } else {
              var item = select('.active-menu-panel .slide-menu-items li.slide-menu-item');
              if (item) selectItem(item);
            }
            break;
          // pageup, u
          case 33:
          case 85:
            var itemsAbove = selectAll('.active-menu-panel .slide-menu-items li').filter(function (item) {
              return visibleOffset(item) > 0;
            });
            var visibleItems = selectAll('.active-menu-panel .slide-menu-items li').filter(function (item) {
              return visibleOffset(item) === 0;
            });
            var firstVisible = itemsAbove.length > 0 && Math.abs(visibleOffset(itemsAbove[itemsAbove.length - 1])) < itemsAbove[itemsAbove.length - 1].clientHeight ? itemsAbove[itemsAbove.length - 1] : visibleItems[0];
            if (firstVisible) {
              if (firstVisible.classList.contains('selected') && itemsAbove.length > 0) {
                // at top of viewport already, page scroll (if not at start)
                // ...move selected item to bottom, and change selection to last fully visible item at top
                scrollItemToBottom(firstVisible);
                visibleItems = selectAll('.active-menu-panel .slide-menu-items li').filter(function (item) {
                  return visibleOffset(item) === 0;
                });
                if (visibleItems[0] === firstVisible) {
                  // prev item is still beyond the viewport (for custom panels)
                  firstVisible = itemsAbove[itemsAbove.length - 1];
                } else {
                  firstVisible = visibleItems[0];
                }
              }
              selectAll('.active-menu-panel .slide-menu-items li').forEach(function (item) {
                item.classList.remove('selected');
              });
              selectItem(firstVisible);
              // ensure selected item is positioned at the top of the viewport
              scrollItemToTop(firstVisible);
            }
            break;
          // pagedown, d
          case 34:
          case 68:
            var visibleItems = selectAll('.active-menu-panel .slide-menu-items li').filter(function (item) {
              return visibleOffset(item) === 0;
            });
            var itemsBelow = selectAll('.active-menu-panel .slide-menu-items li').filter(function (item) {
              return visibleOffset(item) < 0;
            });
            var lastVisible = itemsBelow.length > 0 && Math.abs(visibleOffset(itemsBelow[0])) < itemsBelow[0].clientHeight ? itemsBelow[0] : visibleItems[visibleItems.length - 1];
            if (lastVisible) {
              if (lastVisible.classList.contains('selected') && itemsBelow.length > 0) {
                // at bottom of viewport already, page scroll (if not at end)
                // ...move selected item to top, and change selection to last fully visible item at bottom
                scrollItemToTop(lastVisible);
                visibleItems = selectAll('.active-menu-panel .slide-menu-items li').filter(function (item) {
                  return visibleOffset(item) === 0;
                });
                if (visibleItems[visibleItems.length - 1] === lastVisible) {
                  // next item is still beyond the viewport (for custom panels)
                  lastVisible = itemsBelow[0];
                } else {
                  lastVisible = visibleItems[visibleItems.length - 1];
                }
              }
              selectAll('.active-menu-panel .slide-menu-items li').forEach(function (item) {
                item.classList.remove('selected');
              });
              selectItem(lastVisible);
              // ensure selected item is positioned at the bottom of the viewport
              scrollItemToBottom(lastVisible);
            }
            break;
          // home
          case 36:
            selectAll('.active-menu-panel .slide-menu-items li').forEach(function (item) {
              item.classList.remove('selected');
            });
            var item = select('.active-menu-panel .slide-menu-items li:first-of-type');
            if (item) {
              item.classList.add('selected');
              keepVisible(item);
            }
            break;
          // end
          case 35:
            selectAll('.active-menu-panel .slide-menu-items li').forEach(function (item) {
              item.classList.remove('selected');
            });
            var item = select('.active-menu-panel .slide-menu-items:last-of-type li:last-of-type');
            if (item) {
              item.classList.add('selected');
              keepVisible(item);
            }
            break;
          // space, return
          case 32:
          case 13:
            var currItem = select('.active-menu-panel .slide-menu-items li.selected');
            if (currItem) {
              openItem(currItem, true);
            }
            break;
          // esc
          case 27:
            closeMenu(null, true);
            break;
        }
      }
    }

    //
    // Utilty functions
    //

    function openMenu(event) {
      if (event) event.preventDefault();
      if (!isOpen()) {
        select('body').classList.add('slide-menu-active');
        select('.reveal').classList.add('has-' + options.effect + '-' + options.side);
        select('.slide-menu').classList.add('active');
        select('.slide-menu-overlay').classList.add('active');

        // identify active theme
        if (options.themes) {
          selectAll('div[data-panel="Themes"] li').forEach(function (i) {
            i.classList.remove('active');
          });
          selectAll('li[data-theme="' + select('link#theme').getAttribute('href') + '"]').forEach(function (i) {
            i.classList.add('active');
          });
        }

        // identify active transition
        if (options.transitions) {
          selectAll('div[data-panel="Transitions"] li').forEach(function (i) {
            i.classList.remove('active');
          });
          selectAll('li[data-transition="' + config.transition + '"]').forEach(function (i) {
            i.classList.add('active');
          });
        }

        // set item selections to match active items
        var items = selectAll('.slide-menu-panel li.active');
        items.forEach(function (i) {
          i.classList.add('selected');
          keepVisible(i);
        });
      }
    }
    function closeMenu(event, force) {
      if (event) event.preventDefault();
      if (!options.sticky || force) {
        select('body').classList.remove('slide-menu-active');
        select('.reveal').classList.remove('has-' + options.effect + '-' + options.side);
        select('.slide-menu').classList.remove('active');
        select('.slide-menu-overlay').classList.remove('active');
        selectAll('.slide-menu-panel li.selected').forEach(function (i) {
          i.classList.remove('selected');
        });
      }
    }
    function toggleMenu(event) {
      if (isOpen()) {
        closeMenu(event, true);
      } else {
        openMenu(event);
      }
    }
    function isOpen() {
      return select('body').classList.contains('slide-menu-active');
    }
    function openPanel(event, ref) {
      openMenu(event);
      var panel = ref;
      if (typeof ref !== 'string') {
        panel = event.currentTarget.getAttribute('data-panel');
      }
      select('.slide-menu-toolbar > li.active-toolbar-button').classList.remove('active-toolbar-button');
      select('li[data-panel="' + panel + '"]').classList.add('active-toolbar-button');
      select('.slide-menu-panel.active-menu-panel').classList.remove('active-menu-panel');
      select('div[data-panel="' + panel + '"]').classList.add('active-menu-panel');
    }
    function nextPanel() {
      var next = (parseInt(select('.active-toolbar-button').getAttribute('data-button')) + 1) % buttons;
      openPanel(null, select('.toolbar-panel-button[data-button="' + next + '"]').getAttribute('data-panel'));
    }
    function prevPanel() {
      var next = parseInt(select('.active-toolbar-button').getAttribute('data-button')) - 1;
      if (next < 0) {
        next = buttons - 1;
      }
      openPanel(null, select('.toolbar-panel-button[data-button="' + next + '"]').getAttribute('data-panel'));
    }
    function openItem(item, force) {
      var h = parseInt(item.getAttribute('data-slide-h'));
      var v = parseInt(item.getAttribute('data-slide-v'));
      var theme = item.getAttribute('data-theme');
      var highlightTheme = item.getAttribute('data-highlight-theme');
      var transition = item.getAttribute('data-transition');
      if (!isNaN(h) && !isNaN(v)) {
        deck.slide(h, v);
      }
      if (theme) {
        changeStylesheet('theme', theme);
      }
      if (highlightTheme) {
        changeStylesheet('highlight-theme', highlightTheme);
      }
      if (transition) {
        deck.configure({
          transition: transition
        });
      }
      var link = select('a', item);
      if (link) {
        if (force || !options.sticky || options.autoOpen && link.href.startsWith('#') || link.href.startsWith(window.location.origin + window.location.pathname + '#')) {
          link.click();
        }
      }
      closeMenu();
    }
    function clicked(event) {
      if (event.target.nodeName !== 'A') {
        event.preventDefault();
      }
      openItem(event.currentTarget);
    }
    function highlightCurrentSlide() {
      var state = deck.getState();
      selectAll('li.slide-menu-item, li.slide-menu-item-vertical').forEach(function (item) {
        item.classList.remove('past');
        item.classList.remove('active');
        item.classList.remove('future');
        var h = parseInt(item.getAttribute('data-slide-h'));
        var v = parseInt(item.getAttribute('data-slide-v'));
        if (h < state.indexh || h === state.indexh && v < state.indexv) {
          item.classList.add('past');
        } else if (h === state.indexh && v === state.indexv) {
          item.classList.add('active');
        } else {
          item.classList.add('future');
        }
      });
    }
    function matchRevealStyle() {
      var revealStyle = window.getComputedStyle(select('.reveal'));
      var element = select('.slide-menu');
      element.style.fontFamily = revealStyle.fontFamily;
      //XXX could adjust the complete menu style to match the theme, ie colors, etc
    }

    var slideMenuFooterLinks = [{
      "title": "Terms & Conditions",
      "url": "https://mslide.bod.nu/terms-conditions/"
    }, {
      "title": "Cookie policy",
      "url": "https://mslide.bod.nu/cookie-policy/"
    }, {
      "title": "Feedback",
      "url": "https://www.trustpilot.com/review/bod.nu?utm_medium=trustbox&utm_source=TrustBoxReviewCollector"
    }, {
      "title": "Instagram",
      "url": "https://www.instagram.com/"
    }, {
      "title": "Whatsapp",
      "url": "#"
    }, {
      "title": "Facebook",
      "url": "#"
    }, {
      "title": "Email this page",
      "url": "#"
    }, {
      "title": "Blastoff",
      "url": "https://blastoffdigital.net/wordpress-moodle-webapp-scalabale-solutions-mobile-agency/"
    }];
    window.onload = /*#__PURE__*/_asyncToGenerator( /*#__PURE__*/regenerator.mark(function _callee4() {
      var generateThumbails, _generateThumbails, createMenuFooter, _createMenuFooter;
      return regenerator.wrap(function _callee4$(_context4) {
        while (1) switch (_context4.prev = _context4.next) {
          case 0:
            _createMenuFooter = function _createMenuFooter3() {
              _createMenuFooter = _asyncToGenerator( /*#__PURE__*/regenerator.mark(function _callee3() {
                var divElement, newUl, i, newLi, anchor, existingUl, slideDownloadButton;
                return regenerator.wrap(function _callee3$(_context3) {
                  while (1) switch (_context3.prev = _context3.next) {
                    case 0:
                      // Select the existing div element
                      divElement = document.querySelector('div[data-panel="Slides"]'); // Create a new ul element
                      newUl = document.createElement('ul');
                      newUl.classList.add('slide-menu-footer');

                      // Create and append li elements (links) to the new ul
                      for (i = 0; i < slideMenuFooterLinks.length; i++) {
                        newLi = document.createElement('li');
                        anchor = document.createElement('a');
                        anchor.href = slideMenuFooterLinks[i].url;
                        anchor.textContent = slideMenuFooterLinks[i].title;
                        newLi.appendChild(anchor);
                        newUl.appendChild(newLi);
                      }

                      // Append the new ul below the existing ul
                      existingUl = divElement.querySelector('.slide-menu-items');
                      existingUl.insertAdjacentElement('afterend', newUl);

                      // check the device width and device orientation and if it is smaller than 881px then skip this function
                      if (!pwaInstalled) {
                        if (window.innerWidth <= 881 && window.matchMedia("(orientation: landscape)").matches === true || window.innerWidth < 481) {
                          // Create the download button
                          slideDownloadButton = document.createElement('button'); // add fa fa-download icon and Download text
                          slideDownloadButton.innerHTML = '<i class="iconoir-download-square-solid"></i> Download';
                          // Add title to the button
                          slideDownloadButton.title = 'Add this app on your home screen for easy access and native like feel';
                          slideDownloadButton.classList.add('slide-menu-download-button');
                          slideDownloadButton.addEventListener('click', /*#__PURE__*/_asyncToGenerator( /*#__PURE__*/regenerator.mark(function _callee2() {
                            var _yield$deferredPrompt, outcome;
                            return regenerator.wrap(function _callee2$(_context2) {
                              while (1) switch (_context2.prev = _context2.next) {
                                case 0:
                                  // on the button click show defferedPrompt
                                  deferredPrompt.prompt();
                                  // Wait for the user to respond to the prompt
                                  _context2.next = 3;
                                  return deferredPrompt.userChoice;
                                case 3:
                                  _yield$deferredPrompt = _context2.sent;
                                  outcome = _yield$deferredPrompt.outcome;
                                  // if the user accepted the prompt, hide the button
                                  if (outcome === 'accepted') {
                                    slideDownloadButton.style.display = 'none';
                                  }
                                case 6:
                                case "end":
                                  return _context2.stop();
                              }
                            }, _callee2);
                          })));

                          // Append the download button after the new ul
                          newUl.insertAdjacentElement('afterend', slideDownloadButton);
                        }
                      } else {
                        slideDownloadButton ? slideDownloadButton.style.display = 'none' : null;
                        pwaDownloadButton ? pwaDownloadButton.style.display = 'none' : null;
                      }
                    case 7:
                    case "end":
                      return _context3.stop();
                  }
                }, _callee3);
              }));
              return _createMenuFooter.apply(this, arguments);
            };
            createMenuFooter = function _createMenuFooter2() {
              return _createMenuFooter.apply(this, arguments);
            };
            _generateThumbails = function _generateThumbails3() {
              _generateThumbails = _asyncToGenerator( /*#__PURE__*/regenerator.mark(function _callee() {
                var div, sections, menuImages, h, subsections, v, subsection, customThumb, imagePath, ulList;
                return regenerator.wrap(function _callee$(_context) {
                  while (1) switch (_context.prev = _context.next) {
                    case 0:
                      if (!(window.innerWidth <= 881 && window.matchMedia("(orientation: landscape)").matches === true || window.innerWidth < 481)) {
                        _context.next = 2;
                        break;
                      }
                      return _context.abrupt("return");
                    case 2:
                      // Get elements
                      div = document.querySelector('div[data-panel="Slides"]');
                      sections = selectAll('.slides > section');
                      menuImages = []; // Array to store image paths
                      // Loop through sections and subsections
                      for (h = 0; h < sections.length; h++) {
                        subsections = selectAll('section', sections[h]);
                        for (v = 0; v < subsections.length; v++) {
                          subsection = subsections[v];
                          customThumb = subsection.getAttribute('data-menu-img');
                          imagePath = customThumb && customThumb.trim() ? customThumb : "assets/thumbnails/thumb-dummy.webp"; // Store image path
                          menuImages.push(imagePath);

                          // Set a generated thumbnail only when the slide has no explicit thumbnail.
                          if (!customThumb || !customThumb.trim()) {
                            subsection.setAttribute('data-menu-img', imagePath);
                          }
                        }
                      }

                      // Get slide menu items
                      if (div) {
                        ulList = div.querySelectorAll('ul.slide-menu-items');
                        if (ulList.length > 0) {
                          ulList.forEach(function (ul) {
                            var liList = ul.querySelectorAll('li.slide-menu-item, li.slide-menu-item-vertical');

                            // Loop through li elements and set image src
                            for (var i = 0; i < liList.length && i < menuImages.length; i++) {
                              var li = liList[i];
                              var img = li.querySelector('img');
                              if (img) {
                                img.src = menuImages[i];
                              }
                            }
                          });
                        }
                      }
                    case 7:
                    case "end":
                      return _context.stop();
                  }
                }, _callee);
              }));
              return _generateThumbails.apply(this, arguments);
            };
            generateThumbails = function _generateThumbails2() {
              return _generateThumbails.apply(this, arguments);
            }; // give the current URL
            // alert(window.location.href);
            _context4.next = 6;
            return generateThumbails();
          case 6:
            _context4.next = 8;
            return createMenuFooter();
          case 8:
          case "end":
            return _context4.stop();
        }
      }, _callee4);
    }));
    var buttons = 0;
    function initMenu() {
      if (!initialised) {
        var addToolbarButton = function addToolbarButton(title, ref, icon, style, fn, active) {
          var attrs = {
            'data-button': '' + buttons++,
            class: 'toolbar-panel-button' + (active ? ' active-toolbar-button' : '')
          };
          if (ref) {
            attrs['data-panel'] = ref;
          }
          var button = create('li', attrs);
          if (icon.startsWith('fa-')) {
            button.appendChild(create('i', {
              class: style + ' ' + icon
            }));
          } else {
            button.innerHTML = icon + '</i>';
          }
          button.appendChild(create('br'), select('i', button));
          button.appendChild(create('span', {
            class: 'slide-menu-toolbar-label'
          }, title), select('i', button));
          button.onclick = fn;
          toolbar.appendChild(button);
          return button;
        };
        var generateItem = function generateItem(type, section, i, h, v) {
          function text(selector, parent) {
            if (selector === '') return null;
            var el = parent ? select(selector, section) : select(selector);
            if (el) return el.textContent;
            return null;
          }
          var title = section.getAttribute('data-menu-title') || text('.menu-title', section) || text(options.titleSelector, section);
          if (!title && options.useTextContentForMissingTitles) {
            // attempt to figure out a title based on the text in the slide
            title = section.textContent.trim();
            if (title) {
              title = title.split('\n').map(function (t) {
                return t.trim();
              }).join(' ').trim().replace(/^(.{16}[^\s]*).*/, '$1') // limit to 16 chars plus any consecutive non-whitespace chars (to avoid breaking words)
              .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;') + '...';
            }
          }
          if (!title) {
            if (options.hideMissingTitles) return '';
            type += ' no-title';
            title = 'Slide ' + (i + 1);
          }
          var item = create('li', {
            class: type,
            'data-item': i,
            'data-slide-h': h,
            'data-slide-v': v === undefined ? 0 : v
          });
          var img = section.getAttribute('data-menu-img');
          if (!img || !img.trim()) {
            img = "assets/thumbnails/thumb-dummy.webp";
          }
          if (img) {
            var h2c = function h2c() {
              //   hasRun = true
              //   var fetchCounter = 0;
              // selectAll('.slides > section').forEach(function (section, h) {
              //   var subsections = selectAll('section', section);
              //   if (subsections.length > 0) {
              //     subsections.forEach(function (subsection, v) {
              //       let url = null
              //       // url = window.location.href
              //       url = 'https://slides.com/d/ZIOLzA8/live'
              //       url += `#/${h}/${v}`

              //       // encode url
              //       url = encodeURIComponent(url)

              //       fetch(`https://shot.screenshotapi.net/screenshot?token=CMHH0WK-RFE4Z94-G8QZ054-MEAVZY3&url=${url}&output=json&file_type=webp&wait_for_event=domcontentloaded&lazy_load=true&delay=1000`)
              //     .then(response => response.json())
              //     .then(data => {
              //     // document.querySelector('section[data-menu-img]').style.backgroundImage = `url(${data.screenshot})`
              //     canvas.src = data.screenshot
              //     fetchCounter++;

              //     if (fetchCounter === subsections.length) {
              //     // All fetch requests are completed, do something
              //     console.log('All fetch requests completed');
              //   }

              //     // document.querySelectorAll('.slides section section').forEach((sec, index) => {

              //     // document.querySelectorAll('.slides section section').forEach((sec, index) => {
              //     //   sec.setAttribute('data-menu-img', `${data.screenshot}`)
              //     // })

              //     // sec.setAttribute('data-menu-img', `${data.screenshot}`)
              //     //   console.log(sec)
              //     // })
              //   })
              //  .catch(error => console.error(error))
              //     });
              //   }
              // });
            };
            item.classList.add("img-item");
            var canvas = create('img', {
              class: 'slide-menu-item-img'
            });
            canvas.src = img;
            canvas.alt = title;
            item.appendChild(canvas);
            select('.reveal').querySelector('.reveal');
            setTimeout(function () {
              if (!hasRun) {
                h2c();
              }
            }, 1000);
            var _config = {
              characterData: true,
              childList: true,
              subtree: true
            };
            var timer = null;
            var callback = function callback(mutationsList, observer) {
              clearTimeout(timer);
              setTimeout(function () {
                if (!hasRun) {
                  h2c();
                }
              }, 300);
            };
            var observer = new MutationObserver(callback);
            observer.observe(section, _config);
          }
          if (options.markers) {
            item.appendChild(create('i', {
              class: 'fas iconoir-check-circle-solid fa-fw past'
            }));
            item.appendChild(create('i', {
              class: 'fas iconoir-arrow-right fa-fw active'
            }));
            item.appendChild(create('i', {
              class: 'far iconoir-circle fa-fw future'
            }));
          }
          if (options.numbers) {
            // Number formatting taken from reveal.js
            var value = [];
            var format = 'h.v';

            // Check if a custom number format is available
            if (typeof options.numbers === 'string') {
              format = options.numbers;
            } else if (typeof config.slideNumber === 'string') {
              // Take user defined number format for slides
              format = config.slideNumber;
            }
            switch (format) {
              case 'c':
                value.push(i + 1);
                break;
              case 'c/t':
                value.push(i + 1, '/', deck.getTotalSlides());
                break;
              case 'h/v':
                value.push(h + 1);
                if (typeof v === 'number' && !isNaN(v)) value.push('/', v + 1);
                break;
              default:
                value.push(h + 1);
                if (typeof v === 'number' && !isNaN(v)) value.push('.', v + 1);
            }
            item.appendChild(create('span', {
              class: 'slide-menu-item-number'
            }, value.join('') + '. '));
          }
          item.appendChild(create('span', {
            class: 'slide-menu-item-title'
          }, title));
          return item;
        };
        var createSlideMenu = function createSlideMenu() {
          if (!document.querySelector('section[data-markdown]:not([data-markdown-parsed])')) {
            var panel = create('div', {
              'data-panel': 'Slides',
              class: 'slide-menu-panel active-menu-panel'
            });
            panel.appendChild(create('ul', {
              class: 'slide-menu-items'
            }));
            panels.appendChild(panel);
            var items = select('.slide-menu-panel[data-panel="Slides"] > .slide-menu-items');
            var slideCount = 0;
            selectAll('.slides > section').forEach(function (section, h) {
              var subsections = selectAll('section', section);
              if (subsections.length > 0) {
                subsections.forEach(function (subsection, v) {
                  var type = v === 0 ? 'slide-menu-item' : 'slide-menu-item-vertical';
                  var item = generateItem(type, subsection, slideCount, h, v);
                  if (item) {
                    items.appendChild(item);
                  }
                  slideCount++;
                });
              } else {
                var item = generateItem('slide-menu-item', section, slideCount, h);
                if (item) {
                  items.appendChild(item);
                }
                slideCount++;
              }
            });
            selectAll('.slide-menu-item, .slide-menu-item-vertical').forEach(function (i) {
              i.onclick = clicked;
            });
            highlightCurrentSlide();
          } else {
            // wait for markdown to be loaded and parsed
            setTimeout(createSlideMenu, 100);
          }
        };
        var handleMouseHighlight = function handleMouseHighlight(event) {
          if (mouseSelectionEnabled) {
            selectAll('.active-menu-panel .slide-menu-items li.selected').forEach(function (i) {
              i.classList.remove('selected');
            });
            event.currentTarget.classList.add('selected');
          }
        };
        var parent = select('.reveal').parentElement;
        var top = create('div', {
          class: 'slide-menu-wrapper'
        });
        parent.appendChild(top);
        var panels = create('nav', {
          class: 'slide-menu slide-menu--' + options.side
        });
        if (typeof options.width === 'string') {
          if (['normal', 'wide', 'third', 'half', 'full'].indexOf(options.width) !== -1) {
            panels.classList.add('slide-menu--' + options.width);
          } else {
            panels.classList.add('slide-menu--custom');
            panels.style.width = options.width;
          }
        }
        top.appendChild(panels);
        matchRevealStyle();
        var overlay = create('div', {
          class: 'slide-menu-overlay'
        });
        top.appendChild(overlay);
        overlay.onclick = function () {
          closeMenu(null, true);
        };
        var toolbar = create('ol', {
          class: 'slide-menu-toolbar'
        });
        select('.slide-menu').appendChild(toolbar);
        addToolbarButton('Slides', 'Slides', 'fa-images', 'fas', openPanel, true);
        if (options.custom) {
          options.custom.forEach(function (element, index, array) {
            addToolbarButton(element.title, 'Custom' + index, element.icon, null, openPanel);
          });
        }
        if (options.themes) {
          addToolbarButton('Themes', 'Themes', 'fa-adjust', 'fas', openPanel);
        }
        if (options.transitions) {
          addToolbarButton('Transitions', 'Transitions', 'fa-sticky-note', 'fas', openPanel);
        }
        var button = create('li', {
          id: 'close',
          class: 'toolbar-panel-button'
        });
        button.appendChild(create('i', {
          class: 'iconoir-xmark'
        }));
        button.appendChild(create('br'));
        button.appendChild(create('span', {
          class: 'slide-menu-toolbar-label'
        }, 'Close'));
        button.onclick = function () {
          closeMenu(null, true);
        };
        toolbar.appendChild(button);

        //
        // Slide links
        //
        var hasRun = false;
        createSlideMenu();
        deck.addEventListener('slidechanged', highlightCurrentSlide);

        //
        // Custom menu panels
        //
        if (options.custom) {
          var xhrSuccess = function xhrSuccess() {
            if (this.status >= 200 && this.status < 300) {
              this.panel.innerHTML = this.responseText;
              enableCustomLinks(this.panel);
            } else {
              showErrorMsg(this);
            }
          };
          var xhrError = function xhrError() {
            showErrorMsg(this);
          };
          var loadCustomPanelContent = function loadCustomPanelContent(panel, sURL) {
            var oReq = new XMLHttpRequest();
            oReq.panel = panel;
            oReq.arguments = Array.prototype.slice.call(arguments, 2);
            oReq.onload = xhrSuccess;
            oReq.onerror = xhrError;
            oReq.open('get', sURL, true);
            oReq.send(null);
          };
          var enableCustomLinks = function enableCustomLinks(panel) {
            selectAll('ul.slide-menu-items li.slide-menu-item', panel).forEach(function (item, i) {
              item.setAttribute('data-item', i + 1);
              item.onclick = clicked;
              item.addEventListener('mouseenter', handleMouseHighlight);
            });
          };
          var showErrorMsg = function showErrorMsg(response) {
            var msg = '<p>ERROR: The attempt to fetch ' + response.responseURL + ' failed with HTTP status ' + response.status + ' (' + response.statusText + ').</p>' + '<p>Remember that you need to serve the presentation HTML from a HTTP server.</p>';
            response.panel.innerHTML = msg;
          };
          options.custom.forEach(function (element, index, array) {
            var panel = create('div', {
              'data-panel': 'Custom' + index,
              class: 'slide-menu-panel slide-menu-custom-panel'
            });
            if (element.content) {
              panel.innerHTML = element.content;
              enableCustomLinks(panel);
            } else if (element.src) {
              loadCustomPanelContent(panel, element.src);
            }
            panels.appendChild(panel);
          });
        }

        //
        // Themes
        //
        if (options.themes) {
          var panel = create('div', {
            class: 'slide-menu-panel',
            'data-panel': 'Themes'
          });
          panels.appendChild(panel);
          var menu = create('ul', {
            class: 'slide-menu-items'
          });
          panel.appendChild(menu);
          options.themes.forEach(function (t, i) {
            var attrs = {
              class: 'slide-menu-item',
              'data-item': '' + (i + 1)
            };
            if (t.theme) {
              attrs['data-theme'] = t.theme;
            }
            if (t.highlightTheme) {
              attrs['data-highlight-theme'] = t.highlightTheme;
            }
            var item = create('li', attrs, t.name);
            menu.appendChild(item);
            item.onclick = clicked;
          });
        }

        //
        // Transitions
        //
        if (options.transitions) {
          var panel = create('div', {
            class: 'slide-menu-panel',
            'data-panel': 'Transitions'
          });
          panels.appendChild(panel);
          var menu = create('ul', {
            class: 'slide-menu-items'
          });
          panel.appendChild(menu);
          options.transitions.forEach(function (name, i) {
            var item = create('li', {
              class: 'slide-menu-item',
              'data-transition': name.toLowerCase(),
              'data-item': '' + (i + 1)
            }, name);
            menu.appendChild(item);
            item.onclick = clicked;
          });
        }

        //
        // Open menu options
        //
        if (options.openButton) {
          // add menu button
          var div = create('div', {
            class: 'slide-menu-button'
          });
          var link = create('a', {
            href: '#'
          });
          link.appendChild(create('i', {
            class: 'iconoir-multiple-pages-empty'
          }));
          div.appendChild(link);
          select('.reveal').appendChild(div);
          div.onclick = openMenu;
        }
        if (options.openSlideNumber) {
          var slideNumber = select('div.slide-number');
          slideNumber.onclick = openMenu;
        }

        //
        // Handle mouse overs
        //
        selectAll('.slide-menu-panel .slide-menu-items li').forEach(function (item) {
          item.addEventListener('mouseenter', handleMouseHighlight);
        });
      }
      if (options.keyboard) {
        //XXX add keyboard option for custom key codes, etc.

        document.addEventListener('keydown', onDocumentKeyDown, false);

        // handle key presses within speaker notes
        window.addEventListener('message', function (event) {
          var data;
          try {
            data = JSON.parse(event.data);
          } catch (e) {}
          if (data && data.method === 'triggerKey') {
            onDocumentKeyDown({
              keyCode: data.args[0],
              stopImmediatePropagation: function stopImmediatePropagation() {}
            });
          }
        });

        // Prevent reveal from processing keyboard events when the menu is open
        if (config.keyboardCondition && typeof config.keyboardCondition === 'function') {
          // combine user defined keyboard condition with the menu's own condition
          var userCondition = config.keyboardCondition;
          config.keyboardCondition = function (event) {
            return userCondition(event) && (!isOpen() || event.keyCode === 77);
          };
        } else {
          config.keyboardCondition = function (event) {
            return !isOpen() || event.keyCode === 77;
          };
        }
        deck.addKeyBinding({
          keyCode: 77,
          key: 'M',
          description: 'Toggle menu'
        }, toggleMenu);
      }
      if (options.openOnInit) {
        openMenu();
      }
      initialised = true;
    }

    /**
     * Extend object a with the properties of object b.
     * If there's a conflict, object b takes precedence.
     */
    function extend(a, b) {
      for (var i in b) {
        a[i] = b[i];
      }
    }

    /**
     * Dispatches an event of the specified type from the
     * reveal DOM element.
     */
    function dispatchEvent(type, args) {
      var event = document.createEvent('HTMLEvents', 1, 2);
      event.initEvent(type, true, true);
      extend(event, args);
      document.querySelector('.reveal').dispatchEvent(event);

      // If we're in an iframe, post each reveal.js event to the
      // parent window. Used by the notes plugin
      if (config.postMessageEvents && window.parent !== window.self) {
        window.parent.postMessage(JSON.stringify({
          namespace: 'reveal',
          eventName: type,
          state: deck.getState()
        }), '*');
      }
    }
    function select(selector, el) {
      if (!el) {
        el = document;
      }
      return el.querySelector(selector);
    }
    function selectAll(selector, el) {
      if (!el) {
        el = document;
      }
      return Array.prototype.slice.call(el.querySelectorAll(selector));
    }
    function create(tagName, attrs, content) {
      var el = document.createElement(tagName);
      if (attrs) {
        Object.getOwnPropertyNames(attrs).forEach(function (n) {
          el.setAttribute(n, attrs[n]);
        });
      }
      if (content) el.innerHTML = content;
      return el;
    }
    function changeStylesheet(id, href) {
      // take note of the previous theme and remove it, then create a new stylesheet reference and insert it
      // this is required to force a load event so we can change the menu style to match the new style
      var stylesheet = select('link#' + id);
      var parent = stylesheet.parentElement;
      var sibling = stylesheet.nextElementSibling;
      stylesheet.remove();
      var newStylesheet = stylesheet.cloneNode();
      newStylesheet.setAttribute('href', href);
      newStylesheet.onload = function () {
        matchRevealStyle();
      };
      parent.insertBefore(newStylesheet, sibling);
    }

    // modified from math plugin
    function loadResource(url, type, callback) {
      var head = document.querySelector('head');
      var resource;
      if (type === 'script') {
        resource = document.createElement('script');
        resource.type = 'text/javascript';
        resource.src = url;
      } else if (type === 'stylesheet') {
        resource = document.createElement('link');
        resource.rel = 'stylesheet';
        resource.href = url;
      }

      // Wrapper for callback to make sure it only fires once
      var finish = function finish() {
        if (typeof callback === 'function') {
          callback.call();
          callback = null;
        }
      };
      resource.onload = finish;

      // IE
      resource.onreadystatechange = function () {
        if (this.readyState === 'loaded') {
          finish();
        }
      };

      // Normal browsers
      head.appendChild(resource);
    }
    function loadPlugin() {
      // does not support IE8 or below
      var supported = !ieVersion || ieVersion >= 9;

      // do not load the menu in the upcoming slide panel in the speaker notes
      if (deck.isSpeakerNotes() && window.location.search.endsWith('controls=false')) {
        supported = false;
      }
      if (supported) {
        if (!options.delayInit) initMenu();
        dispatchEvent('menu-ready');
      }
    }
    return {
      id: 'menu',
      init: function init(reveal) {
        deck = reveal;
        config = deck.getConfig();
        initOptions(config);
        loadResource(options.path + 'menu.css', 'stylesheet', function () {
          if (options.loadIcons === undefined || options.loadIcons) {
            loadResource(options.path + 'font-awesome/css/all.css', 'stylesheet', loadPlugin);
          } else {
            loadPlugin();
          }
        });
      },
      toggle: toggleMenu,
      openMenu: openMenu,
      closeMenu: closeMenu,
      openPanel: openPanel,
      isOpen: isOpen,
      initialiseMenu: initMenu,
      isMenuInitialised: function isMenuInitialised() {
        return initialised;
      }
    };
  };

  // polyfill
  if (!String.prototype.startsWith) {
    String.prototype.startsWith = function (searchString, position) {
      return this.substr(position || 0, searchString.length) === searchString;
    };
  }
  if (!String.prototype.endsWith) {
    String.prototype.endsWith = function (search, this_len) {
      if (this_len === undefined || this_len > this.length) {
        this_len = this.length;
      }
      return this.substring(this_len - search.length, this_len) === search;
    };
  }

  return Plugin;

}));
